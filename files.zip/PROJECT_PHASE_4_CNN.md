# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 4: CONVOLUTIONAL NEURAL NETWORKS (CNN)
# Movie Review Sentiment Analyzer - Implementation Guide
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Apply 1D CNN for text classification. Understand convolution, pooling, and feature extraction.

## 📚 CONCEPTS COVERED
- ANN vs CNN
- CNN Architecture
- 1D Convolution for Text
- Pooling Layers
- Backpropagation in CNN
- Transfer Learning
- Data Augmentation (ImageDataGenerator concept)

## 📊 EXPECTED ACCURACY
- 1D CNN: ~78-82%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: ANN VS CNN (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
ANN VS CNN (from repository)
═══════════════════════════════════════════════════════════════════════════════

In ANN:
- Calculate dot product of input with weights
- DEPENDENT on input (more computational)
- Used for TABULAR type data

In CNN:
- Calculate dot product by SLIDING FILTER on input
- INDEPENDENT of input (less computational)
- Used for GRID type data (images, text sequences)

┌──────────────────┬─────────────────────┬──────────────────────┐
│ Aspect           │ ANN                 │ CNN                  │
├──────────────────┼─────────────────────┼──────────────────────┤
│ Calculation      │ Dot product with    │ Dot product by       │
│                  │ weights             │ sliding filter       │
├──────────────────┼─────────────────────┼──────────────────────┤
│ Dependency       │ DEPENDENT on input  │ INDEPENDENT of input │
├──────────────────┼─────────────────────┼──────────────────────┤
│ Computation      │ More computational  │ Less computational   │
├──────────────────┼─────────────────────┼──────────────────────┤
│ Data Type        │ Tabular data        │ Grid data (images)   │
├──────────────────┼─────────────────────┼──────────────────────┤
│ Use Case         │ General purpose     │ Image/Text patterns  │
└──────────────────┴─────────────────────┴──────────────────────┘

KEY INSIGHT:
- ANN: Every input connected to every neuron (fully connected)
       → Computation grows with input size
- CNN: Filter SLIDES across input → Same filter REUSED
       → Computation independent of input size
       → Captures LOCAL patterns (edges, n-grams)
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: CNN ARCHITECTURE (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
CNN ARCHITECTURE - Three Ways to Represent (from repo)
═══════════════════════════════════════════════════════════════════════════════

1️⃣ DIAGRAMS OF LAYERS (Visual representation)

   Input → [Conv] → [ReLU] → [Pool] → [Conv] → [ReLU] → [Pool] → [Flatten] → [Dense] → Output
   
2️⃣ LOGICAL FLOW

   Input Text/Image
        ↓
   Convolution Layer (extract features using filters)
        ↓
   Activation Function (ReLU - introduce non-linearity)
        ↓
   Pooling Layer (reduce dimensions, keep important features)
        ↓
   [Repeat Convolution + Pooling for deeper features]
        ↓
   Flatten Layer (convert to 1D)
        ↓
   Dense/Fully Connected Layer (classification)
        ↓
   Output Layer (sigmoid/softmax)

3️⃣ EQUATIONS

   Convolution: (Input * Filter) + Bias
   Where * is the convolution operation (not multiplication)
   
   For 1D text:
   Output[i] = Σ(Input[i:i+k] · Filter) + bias
   Where k = kernel/filter size

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: 1D CNN CONCEPTS FOR TEXT
# ═══════════════════════════════════════════════════════════════════════════════

```python
import numpy as np
import matplotlib.pyplot as plt

# ============================================
# 1D CONVOLUTION VISUALIZATION
# ============================================

# Sample sentence embedding (simplified)
# Each word is represented by a 4-dimensional vector
sentence = np.array([
    [0.1, 0.2, 0.3, 0.4],  # word 1: "this"
    [0.5, 0.6, 0.7, 0.8],  # word 2: "movie"
    [0.2, 0.3, 0.4, 0.5],  # word 3: "is"
    [0.8, 0.9, 0.7, 0.6],  # word 4: "great"
    [0.1, 0.1, 0.2, 0.2],  # word 5: "!"
])

print("Sentence shape: (seq_length=5, embedding_dim=4)")
print(sentence)

# 1D Convolution with filter size 2 (bigram detector)
# Filter looks at 2 consecutive words at a time
filter_size = 2
n_filters = 3

# Random filters (in practice, these are learned)
np.random.seed(42)
filters = np.random.randn(n_filters, filter_size, 4) * 0.1  # (n_filters, kernel_size, embedding_dim)

print(f"\nFilter shape: (n_filters={n_filters}, kernel_size={filter_size}, embedding_dim=4)")

# Manual 1D convolution
def conv1d_manual(input_seq, kernel, bias=0):
    """
    Manual 1D convolution
    
    input_seq: (seq_length, embedding_dim)
    kernel: (kernel_size, embedding_dim)
    """
    seq_length = input_seq.shape[0]
    kernel_size = kernel.shape[0]
    output_length = seq_length - kernel_size + 1
    
    output = []
    for i in range(output_length):
        # Extract window
        window = input_seq[i:i+kernel_size]
        # Element-wise multiply and sum
        conv_result = np.sum(window * kernel) + bias
        output.append(conv_result)
    
    return np.array(output)

# Apply convolution with first filter
conv_output = conv1d_manual(sentence, filters[0])
print(f"\nConvolution output (1 filter): {conv_output}")
print(f"Output length: {len(conv_output)} (original 5 - kernel 2 + 1 = 4)")

# Apply ReLU
relu_output = np.maximum(0, conv_output)
print(f"After ReLU: {relu_output}")

# Apply Max Pooling (global)
max_pool_output = np.max(relu_output)
print(f"After Max Pooling: {max_pool_output}")

# Visualize
fig, axes = plt.subplots(1, 4, figsize=(16, 4))

# Input
axes[0].imshow(sentence, cmap='RdBu', aspect='auto')
axes[0].set_title('Input Sentence\n(5 words × 4 dims)')
axes[0].set_ylabel('Word Position')
axes[0].set_xlabel('Embedding Dimension')

# Convolution output
axes[1].bar(range(len(conv_output)), conv_output, color='blue')
axes[1].set_title('After Convolution\n(filter size=2)')
axes[1].set_xlabel('Position')

# ReLU output
axes[2].bar(range(len(relu_output)), relu_output, color='green')
axes[2].set_title('After ReLU')
axes[2].set_xlabel('Position')

# Max Pool output
axes[3].bar([0], [max_pool_output], color='red')
axes[3].set_title('After Max Pool\n(single value)')
axes[3].set_xlim(-0.5, 0.5)

plt.tight_layout()
plt.savefig('models/cnn_1d_visualization.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: BUILD 1D CNN FOR SENTIMENT ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

```python
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pandas as pd
import re

# ============================================
# LOAD AND PREPARE DATA
# ============================================

# Load data
train_df = pd.read_csv('data/processed/train.csv')
test_df = pd.read_csv('data/processed/test.csv')

# Simple preprocessing
def preprocess(text):
    text = str(text).lower()
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'[^a-z\s]', '', text)
    return ' '.join(text.split())

X_train = train_df['review'].apply(preprocess)
y_train = train_df['label'].values
X_test = test_df['review'].apply(preprocess)
y_test = test_df['label'].values

# ============================================
# TOKENIZATION AND PADDING
# ============================================

# Tokenize text
vocab_size = 20000  # Keep top 20,000 words
max_length = 200    # Pad/truncate to 200 words

tokenizer = Tokenizer(num_words=vocab_size, oov_token='<OOV>')
tokenizer.fit_on_texts(X_train)

# Convert text to sequences
X_train_seq = tokenizer.texts_to_sequences(X_train)
X_test_seq = tokenizer.texts_to_sequences(X_test)

# Pad sequences
X_train_pad = pad_sequences(X_train_seq, maxlen=max_length, padding='post', truncating='post')
X_test_pad = pad_sequences(X_test_seq, maxlen=max_length, padding='post', truncating='post')

print(f"Vocabulary size: {min(vocab_size, len(tokenizer.word_index))}")
print(f"Training shape: {X_train_pad.shape}")
print(f"Testing shape: {X_test_pad.shape}")
print(f"Sample padded sequence: {X_train_pad[0][:20]}...")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: SIMPLE 1D CNN MODEL
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# 1D CNN MODEL
# ============================================

embedding_dim = 128

model_cnn = keras.Sequential([
    # Embedding Layer: Convert word indices to dense vectors
    layers.Embedding(
        input_dim=vocab_size,
        output_dim=embedding_dim,
        input_length=max_length
    ),
    
    # Convolutional Layer 1 (like detecting bigrams/trigrams)
    layers.Conv1D(
        filters=128,       # Number of filters (feature detectors)
        kernel_size=5,     # Window size (5-gram detector)
        activation='relu',
        padding='same'     # Keep same length
    ),
    
    # Max Pooling (reduce dimensions by half)
    layers.MaxPooling1D(pool_size=2),
    
    # Convolutional Layer 2 (deeper features)
    layers.Conv1D(
        filters=64,
        kernel_size=5,
        activation='relu',
        padding='same'
    ),
    
    # Global Max Pooling (take max from entire sequence)
    layers.GlobalMaxPooling1D(),
    
    # Dense layers (classification head)
    layers.Dense(64, activation='relu'),
    layers.Dropout(0.5),
    
    # Output layer
    layers.Dense(1, activation='sigmoid')
])

model_cnn.summary()

# Compile
model_cnn.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# Train
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint

callbacks = [
    EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True),
    ModelCheckpoint('models/cnn_best.h5', save_best_only=True)
]

history_cnn = model_cnn.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=20,
    batch_size=128,
    callbacks=callbacks,
    verbose=1
)

# Evaluate
test_loss, test_acc = model_cnn.evaluate(X_test_pad, y_test)
print(f"\n1D CNN Test Accuracy: {test_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: MULTI-KERNEL SIZE CNN (Kim's TextCNN)
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# TEXTCNN WITH MULTIPLE KERNEL SIZES
# ============================================

# This architecture uses multiple kernel sizes to capture
# different n-gram features simultaneously

# Input
inputs = keras.Input(shape=(max_length,))

# Embedding
embedding = layers.Embedding(vocab_size, embedding_dim)(inputs)

# Multiple kernel sizes (like detecting bigrams, trigrams, 4-grams, 5-grams)
kernel_sizes = [2, 3, 4, 5]
conv_outputs = []

for kernel_size in kernel_sizes:
    # Convolution
    conv = layers.Conv1D(
        filters=64,
        kernel_size=kernel_size,
        activation='relu',
        padding='valid'
    )(embedding)
    
    # Global Max Pooling
    pool = layers.GlobalMaxPooling1D()(conv)
    
    conv_outputs.append(pool)

# Concatenate all kernel outputs
merged = layers.Concatenate()(conv_outputs)

# Dense layers
x = layers.Dense(128, activation='relu')(merged)
x = layers.Dropout(0.5)(x)

# Output
outputs = layers.Dense(1, activation='sigmoid')(x)

# Create model
model_textcnn = keras.Model(inputs=inputs, outputs=outputs, name='TextCNN')
model_textcnn.summary()

# Compile
model_textcnn.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# Train
history_textcnn = model_textcnn.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=20,
    batch_size=128,
    callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
    verbose=1
)

# Evaluate
test_loss, test_acc = model_textcnn.evaluate(X_test_pad, y_test)
print(f"\nTextCNN Test Accuracy: {test_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: BACKPROPAGATION IN CNN (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
BACKPROPAGATION IN CNN (from repository)
═══════════════════════════════════════════════════════════════════════════════

From repo: "backpropagation in (flatten, maxpooling, convolution)"

The last part of CNN is basically ANN (fully connected).
We understand backprop till maxpooling (part of CNN).
But from maxpooling to activation to input - how does propagation occur?

SPLIT CNN ARCHITECTURE:
┌───────────────────────────────────────────────────────────────────────────────┐
│  CNN PART                           │  ANN PART                               │
│  (Feature Extractor)                │  (Classifier)                           │
├─────────────────────────────────────┼─────────────────────────────────────────┤
│  Input → Conv → ReLU → Pool         │  Flatten → Dense → Output               │
└─────────────────────────────────────┴─────────────────────────────────────────┘

BACKPROPAGATION FLOW (Going Backward):

Loss
  ↓ depends on
ŷ (predicted value from output layer)
  ↓ depends on
Flatten Layer (2x2 matrix → becomes 4x4 in backprop)
  ↓ depends on
MaxPooling (4x4 matrix)
  ↓ depends on
Activation Function (ReLU)
  ↓ depends on
Convolution Layer
  ↓ depends on
Input

KEY POINTS:

1️⃣ FLATTEN LAYER BACKPROP:
   - Forward: 4x4 → flatten to 16x1
   - Backward: 16x1 → reshape to 4x4 (UNFLATTEN)

2️⃣ MAXPOOLING BACKPROP:
   - Forward: Keep only MAX value in each window
   - Backward: Gradient flows ONLY to the position that had MAX value
              Other positions get ZERO gradient

3️⃣ CONVOLUTION BACKPROP:
   - ∂L/∂Filter = Conv(Input, ∂L/∂Output)
   - ∂L/∂Input = FullConv(∂L/∂Output, Flipped_Filter)

EXAMPLE - MaxPool Backprop:

Forward:
┌───┬───┐         ┌───┐
│ 1 │ 3 │   →     │ 4 │  (max of 2x2 = 4)
├───┼───┤         └───┘
│ 4 │ 2 │
└───┴───┘

Backward (gradient = 0.5):
┌───┬───┐
│ 0 │ 0 │   ← gradient goes only to position where 4 was
├───┼───┤
│0.5│ 0 │
└───┴───┘

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8: TRANSFER LEARNING (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
TRANSFER LEARNING (from repository)
═══════════════════════════════════════════════════════════════════════════════

"Transfer learning means keeping the CNN part as-is (since it already knows 
how to 'see'), and replacing the ANN part so the model can make predictions 
for your specific labels."

┌─────────────────────────────────────────────────────────────────────────────┐
│                        PRETRAINED MODEL                                     │
├─────────────────────────────────┬───────────────────────────────────────────┤
│  CNN PART (Feature Extractor)   │  ANN PART (Classifier)                    │
│  ✓ Already learned:             │  ✗ REMOVE these layers                    │
│    - Edges                      │                                           │
│    - Textures                   │  ✓ ADD NEW layers for YOUR task           │
│    - Shapes                     │                                           │
│  ✓ FREEZE these layers          │                                           │
└─────────────────────────────────┴───────────────────────────────────────────┘

TWO WAYS TO APPLY TRANSFER LEARNING:

1️⃣ FEATURE EXTRACTION
   - When: Labels are SIMILAR to pretrained model's training data
   - How: Keep ALL CNN layers FROZEN, only train new FC layers
   - Example: Pretrained on ImageNet (1000 classes) → Your task: dog breeds

2️⃣ FINE TUNING
   - When: Labels are DIFFERENT from pretrained model's training data
   - How: UNFREEZE some convolutional layers + train FC layers
   - Example: Pretrained on ImageNet → Your task: medical X-ray classification

BENEFITS:
- Saves time (don't train from scratch)
- Avoids overfitting (especially with small datasets)
- Better performance (starts with strong base)

═══════════════════════════════════════════════════════════════════════════════
""")

# ============================================
# TRANSFER LEARNING WITH PRETRAINED EMBEDDINGS
# ============================================

# For text, we use pretrained word embeddings (like GloVe)
# This is the text equivalent of pretrained image models

# Download GloVe: https://nlp.stanford.edu/projects/glove/
# We'll use GloVe 100d

import os

def load_glove_embeddings(glove_path, word_index, embedding_dim=100):
    """
    Load pretrained GloVe embeddings
    """
    embeddings_index = {}
    
    with open(glove_path, encoding='utf-8') as f:
        for line in f:
            values = line.split()
            word = values[0]
            coefs = np.asarray(values[1:], dtype='float32')
            embeddings_index[word] = coefs
    
    print(f"Loaded {len(embeddings_index)} word vectors")
    
    # Create embedding matrix
    num_words = min(vocab_size, len(word_index) + 1)
    embedding_matrix = np.zeros((num_words, embedding_dim))
    
    found = 0
    for word, i in word_index.items():
        if i >= vocab_size:
            continue
        embedding_vector = embeddings_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
            found += 1
    
    print(f"Found {found}/{num_words} words in GloVe")
    return embedding_matrix

# If you have GloVe downloaded:
# glove_path = 'data/glove.6B.100d.txt'
# embedding_matrix = load_glove_embeddings(glove_path, tokenizer.word_index, embedding_dim=100)

# Model with pretrained embeddings (frozen)
def create_model_with_pretrained_embeddings(embedding_matrix, trainable=False):
    """
    Create CNN model with pretrained embeddings
    
    trainable=False: Feature Extraction (freeze embeddings)
    trainable=True: Fine-tuning (allow embedding updates)
    """
    model = keras.Sequential([
        # Pretrained Embedding Layer
        layers.Embedding(
            input_dim=embedding_matrix.shape[0],
            output_dim=embedding_matrix.shape[1],
            weights=[embedding_matrix],
            input_length=max_length,
            trainable=trainable  # FREEZE or UNFREEZE
        ),
        
        # CNN layers
        layers.Conv1D(128, 5, activation='relu'),
        layers.GlobalMaxPooling1D(),
        
        # Dense layers (always trainable)
        layers.Dense(64, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(1, activation='sigmoid')
    ])
    
    return model

print("\nTransfer Learning for Text:")
print("- Feature Extraction: trainable=False (freeze embeddings)")
print("- Fine-Tuning: trainable=True (update embeddings)")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 9: DATA AUGMENTATION CONCEPTS
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
KERAS IMAGEDATAGENERATOR (from repository)
═══════════════════════════════════════════════════════════════════════════════

"The Keras ImageDataGenerator is a powerful tool that generates transformed 
images in REAL-TIME, enabling data augmentation to combat overfitting."

For IMAGES:
┌────────────────────────────────────────────────────────────────┐
│ Transformation      │ What it does                            │
├─────────────────────┼─────────────────────────────────────────┤
│ Rotation            │ Rotate image by degrees                 │
│ Width Shift         │ Move image horizontally                 │
│ Height Shift        │ Move image vertically                   │
│ Zoom                │ Zoom in or out                          │
│ Horizontal Flip     │ Mirror image horizontally               │
│ Vertical Flip       │ Mirror image vertically                 │
│ Shear               │ Slant the image                         │
└─────────────────────┴─────────────────────────────────────────┘

BENEFITS:
- Creates MORE training data from existing data
- Model sees DIFFERENT versions of same data
- Learns more ROBUST features
- Combats OVERFITTING

For TEXT (similar concepts):
┌────────────────────────────────────────────────────────────────┐
│ Technique           │ What it does                            │
├─────────────────────┼─────────────────────────────────────────┤
│ Synonym Replacement │ Replace words with synonyms             │
│ Random Insertion    │ Insert random synonyms                  │
│ Random Swap         │ Swap positions of words                 │
│ Random Deletion     │ Randomly delete words                   │
│ Back-translation    │ Translate to another language and back  │
└─────────────────────┴─────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════
""")

# ============================================
# TEXT AUGMENTATION EXAMPLE
# ============================================

import random
from collections import defaultdict

# Simple synonym dictionary (in practice, use WordNet)
synonyms = {
    'good': ['great', 'excellent', 'nice', 'wonderful'],
    'bad': ['terrible', 'awful', 'poor', 'horrible'],
    'movie': ['film', 'picture', 'show'],
    'love': ['adore', 'enjoy', 'like'],
    'hate': ['dislike', 'despise', 'loathe']
}

def synonym_replacement(text, n=2):
    """Replace n random words with synonyms"""
    words = text.split()
    new_words = words.copy()
    
    # Find words that have synonyms
    replaceable = [i for i, w in enumerate(words) if w in synonyms]
    
    # Replace up to n words
    random.shuffle(replaceable)
    for i in replaceable[:n]:
        word = words[i]
        new_words[i] = random.choice(synonyms[word])
    
    return ' '.join(new_words)

def random_deletion(text, p=0.1):
    """Randomly delete words with probability p"""
    words = text.split()
    if len(words) == 1:
        return text
    
    new_words = [w for w in words if random.random() > p]
    
    # Don't delete everything
    if len(new_words) == 0:
        return random.choice(words)
    
    return ' '.join(new_words)

def random_swap(text, n=2):
    """Randomly swap n pairs of words"""
    words = text.split()
    new_words = words.copy()
    
    for _ in range(n):
        if len(new_words) < 2:
            break
        i, j = random.sample(range(len(new_words)), 2)
        new_words[i], new_words[j] = new_words[j], new_words[i]
    
    return ' '.join(new_words)

# Example
original = "this movie is good i love it"
print(f"Original: {original}")
print(f"Synonym Replacement: {synonym_replacement(original)}")
print(f"Random Deletion: {random_deletion(original)}")
print(f"Random Swap: {random_swap(original)}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 10: PLOT RESULTS AND COMPARE
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# TRAINING VISUALIZATION
# ============================================

fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Simple CNN Loss
ax1 = axes[0, 0]
ax1.plot(history_cnn.history['loss'], label='Train')
ax1.plot(history_cnn.history['val_loss'], label='Validation')
ax1.set_title('Simple CNN - Loss')
ax1.set_xlabel('Epoch')
ax1.set_ylabel('Loss')
ax1.legend()
ax1.grid(True)

# Simple CNN Accuracy
ax2 = axes[0, 1]
ax2.plot(history_cnn.history['accuracy'], label='Train')
ax2.plot(history_cnn.history['val_accuracy'], label='Validation')
ax2.set_title('Simple CNN - Accuracy')
ax2.set_xlabel('Epoch')
ax2.set_ylabel('Accuracy')
ax2.legend()
ax2.grid(True)

# TextCNN Loss
ax3 = axes[1, 0]
ax3.plot(history_textcnn.history['loss'], label='Train')
ax3.plot(history_textcnn.history['val_loss'], label='Validation')
ax3.set_title('TextCNN (Multi-kernel) - Loss')
ax3.set_xlabel('Epoch')
ax3.set_ylabel('Loss')
ax3.legend()
ax3.grid(True)

# TextCNN Accuracy
ax4 = axes[1, 1]
ax4.plot(history_textcnn.history['accuracy'], label='Train')
ax4.plot(history_textcnn.history['val_accuracy'], label='Validation')
ax4.set_title('TextCNN (Multi-kernel) - Accuracy')
ax4.set_xlabel('Epoch')
ax4.set_ylabel('Accuracy')
ax4.legend()
ax4.grid(True)

plt.tight_layout()
plt.savefig('models/cnn_training_history.png', dpi=150)
plt.show()

# ============================================
# SAVE MODELS
# ============================================

model_cnn.save('models/simple_cnn.h5')
model_textcnn.save('models/textcnn.h5')

# Save tokenizer
import pickle
with open('models/tokenizer.pkl', 'wb') as f:
    pickle.dump(tokenizer, f)

print("Models and tokenizer saved!")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 4 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ ANN vs CNN
   └── CNN is independent of input size
   └── Uses sliding filter
   └── For grid/sequential data

✅ CNN Architecture
   └── Three ways: diagrams, logical flow, equations
   └── Conv → ReLU → Pool → Flatten → Dense

✅ 1D Convolution for Text
   └── Filter slides over word embeddings
   └── Detects n-gram patterns

✅ Simple 1D CNN
   └── Embedding → Conv1D → MaxPool → Dense

✅ TextCNN (Kim's model)
   └── Multiple kernel sizes (2,3,4,5)
   └── Captures different n-gram features

✅ Backpropagation in CNN
   └── Flatten: Reshape gradient
   └── MaxPool: Gradient to max position only
   └── Conv: Convolution of gradients

✅ Transfer Learning
   └── Feature Extraction: Freeze CNN
   └── Fine-Tuning: Unfreeze some layers

✅ Data Augmentation
   └── ImageDataGenerator for images
   └── Synonym replacement, back-translation for text
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY ACHIEVED
# ═══════════════════════════════════════════════════════════════════════════════

```
📊 PHASE 4 RESULTS:

Model                          | Accuracy
-------------------------------|----------
Simple 1D CNN                  | ~78-80%
TextCNN (Multi-kernel)         | ~80-82%

📈 Progress:
   ML Best (XGBoost): ~88%
   DL MLP: ~75-80%
   CNN: ~80-82%

✓ CNN improves over MLP by capturing local patterns (n-grams)
✗ Still not matching ML models with TF-IDF

❓ Why?
   - Text has SEQUENTIAL dependencies (word order matters)
   - CNN captures LOCAL patterns but misses LONG-RANGE dependencies
   - Need models that process SEQUENCES → RNN!

🚀 NEXT: PHASE 5 - RNN/LSTM/GRU
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# READY FOR PHASE 5: RNN FAMILY
# ═══════════════════════════════════════════════════════════════════════════════

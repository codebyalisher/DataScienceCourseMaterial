# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 10: NLP APPLICATIONS & DEPLOYMENT
# Movie Review Sentiment Analyzer - FINAL PHASE
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Build a complete end-to-end sentiment analysis application and deploy it.

## 📚 CONCEPTS COVERED
- Text Classification (Compare ALL models)
- End-to-End NLP Pipeline
- Flask API
- Heroku Deployment
- Model Comparison Dashboard

## 🎉 FINAL DELIVERABLE
A deployed web application that analyzes movie review sentiment!

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: FINAL MODEL COMPARISON
# ═══════════════════════════════════════════════════════════════════════════════

```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ============================================
# ALL MODEL RESULTS FROM PHASES 2-9
# ============================================

results = {
    # Phase 2: Machine Learning
    'Logistic Regression': {'phase': 2, 'accuracy': 0.85, 'type': 'ML'},
    'Random Forest': {'phase': 2, 'accuracy': 0.87, 'type': 'ML'},
    'XGBoost': {'phase': 2, 'accuracy': 0.88, 'type': 'ML'},
    'SVM': {'phase': 2, 'accuracy': 0.88, 'type': 'ML'},
    
    # Phase 3: Deep Learning Foundations
    'Perceptron': {'phase': 3, 'accuracy': 0.65, 'type': 'DL'},
    'MLP': {'phase': 3, 'accuracy': 0.75, 'type': 'DL'},
    
    # Phase 4: CNN
    'Simple CNN': {'phase': 4, 'accuracy': 0.80, 'type': 'DL'},
    'TextCNN': {'phase': 4, 'accuracy': 0.82, 'type': 'DL'},
    
    # Phase 5: RNN Family
    'Simple RNN': {'phase': 5, 'accuracy': 0.78, 'type': 'DL'},
    'LSTM': {'phase': 5, 'accuracy': 0.87, 'type': 'DL'},
    'GRU': {'phase': 5, 'accuracy': 0.86, 'type': 'DL'},
    'Stacked LSTM': {'phase': 5, 'accuracy': 0.88, 'type': 'DL'},
    'Bidirectional LSTM': {'phase': 5, 'accuracy': 0.89, 'type': 'DL'},
    
    # Phase 6: Attention
    'LSTM + Attention': {'phase': 6, 'accuracy': 0.91, 'type': 'DL'},
    'Self-Attention': {'phase': 6, 'accuracy': 0.90, 'type': 'DL'},
    
    # Phase 7: Transformers
    'DistilBERT': {'phase': 7, 'accuracy': 0.92, 'type': 'Transformer'},
    'BERT': {'phase': 7, 'accuracy': 0.94, 'type': 'Transformer'},
    
    # Phase 9: Text Representations
    'BoW + LogReg': {'phase': 9, 'accuracy': 0.84, 'type': 'ML'},
    'TF-IDF + LogReg': {'phase': 9, 'accuracy': 0.86, 'type': 'ML'},
}

# Create DataFrame
results_df = pd.DataFrame(results).T
results_df.index.name = 'Model'
results_df = results_df.reset_index()
results_df = results_df.sort_values('accuracy', ascending=False)

print("=" * 60)
print("COMPLETE MODEL COMPARISON")
print("=" * 60)
print(results_df.to_string(index=False))

# ============================================
# VISUALIZATION
# ============================================

plt.figure(figsize=(14, 8))

# Color by type
colors = {'ML': '#3498db', 'DL': '#2ecc71', 'Transformer': '#e74c3c'}
bar_colors = [colors[t] for t in results_df['type']]

bars = plt.barh(results_df['Model'], results_df['accuracy'], color=bar_colors)

plt.xlabel('Accuracy', fontsize=12)
plt.ylabel('Model', fontsize=12)
plt.title('Sentiment Analysis - Model Comparison', fontsize=14, fontweight='bold')
plt.xlim(0.6, 1.0)

# Add accuracy labels
for bar, acc in zip(bars, results_df['accuracy']):
    plt.text(acc + 0.005, bar.get_y() + bar.get_height()/2, 
             f'{acc:.0%}', va='center', fontsize=10)

# Legend
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor='#3498db', label='Machine Learning'),
    Patch(facecolor='#2ecc71', label='Deep Learning'),
    Patch(facecolor='#e74c3c', label='Transformer')
]
plt.legend(handles=legend_elements, loc='lower right')

plt.tight_layout()
plt.savefig('models/final_model_comparison.png', dpi=300)
plt.show()

print(f"\n🏆 BEST MODEL: {results_df.iloc[0]['Model']} with {results_df.iloc[0]['accuracy']:.0%} accuracy!")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: PROJECT STRUCTURE
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
PROJECT STRUCTURE FOR DEPLOYMENT
═══════════════════════════════════════════════════════════════════════════════

movie_sentiment_analyzer/
│
├── app/
│   ├── __init__.py
│   ├── app.py                 # Flask application
│   ├── model.py               # Model loading and prediction
│   ├── preprocessing.py       # Text preprocessing
│   ├── templates/
│   │   └── index.html         # Frontend template
│   └── static/
│       ├── css/
│       │   └── style.css
│       └── js/
│           └── main.js
│
├── models/
│   ├── bert_sentiment/        # BERT model files
│   ├── tfidf_vectorizer.pkl   # TF-IDF for fallback
│   └── logistic_model.pkl     # Logistic Regression fallback
│
├── data/
│   ├── raw/
│   └── processed/
│
├── notebooks/
│   ├── phase1_data_fundamentals.ipynb
│   ├── phase2_machine_learning.ipynb
│   └── ... (all 10 phases)
│
├── requirements.txt           # Dependencies
├── Procfile                   # Heroku config
├── runtime.txt                # Python version
└── README.md                  # Documentation

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: FLASK APPLICATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# app/app.py
# ============================================

from flask import Flask, render_template, request, jsonify
import pickle
import re
from transformers import pipeline

app = Flask(__name__)

# ============================================
# LOAD MODELS
# ============================================

# Option 1: Use BERT (best accuracy)
try:
    sentiment_model = pipeline(
        "sentiment-analysis",
        model="distilbert-base-uncased-finetuned-sst-2-english"
    )
    MODEL_TYPE = "BERT"
except:
    # Option 2: Fallback to TF-IDF + LogReg
    with open('models/tfidf_vectorizer.pkl', 'rb') as f:
        tfidf = pickle.load(f)
    with open('models/logistic_model.pkl', 'rb') as f:
        logistic_model = pickle.load(f)
    MODEL_TYPE = "TF-IDF"

print(f"Loaded model: {MODEL_TYPE}")

# ============================================
# PREPROCESSING
# ============================================

def preprocess_text(text):
    """Clean text for model input"""
    text = text.lower()
    text = re.sub(r'<[^>]+>', '', text)  # Remove HTML
    text = re.sub(r'https?://\S+', '', text)  # Remove URLs
    text = re.sub(r'[^a-z\s]', '', text)  # Remove special chars
    return ' '.join(text.split())

# ============================================
# PREDICTION
# ============================================

def predict_sentiment(text):
    """Predict sentiment of given text"""
    
    if MODEL_TYPE == "BERT":
        result = sentiment_model(text)[0]
        label = result['label']
        confidence = result['score']
        
        # Convert label format
        if label == 'POSITIVE':
            sentiment = 'Positive 😊'
        else:
            sentiment = 'Negative 😞'
    
    else:  # TF-IDF fallback
        cleaned = preprocess_text(text)
        vectorized = tfidf.transform([cleaned])
        prediction = logistic_model.predict(vectorized)[0]
        probability = logistic_model.predict_proba(vectorized)[0]
        
        if prediction == 1:
            sentiment = 'Positive 😊'
            confidence = probability[1]
        else:
            sentiment = 'Negative 😞'
            confidence = probability[0]
    
    return {
        'sentiment': sentiment,
        'confidence': f'{confidence:.1%}',
        'model': MODEL_TYPE
    }

# ============================================
# ROUTES
# ============================================

@app.route('/')
def home():
    """Render home page"""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    """API endpoint for predictions"""
    data = request.get_json()
    text = data.get('text', '')
    
    if not text.strip():
        return jsonify({'error': 'Please enter some text'}), 400
    
    result = predict_sentiment(text)
    return jsonify(result)

@app.route('/api/analyze', methods=['POST'])
def api_analyze():
    """REST API endpoint"""
    data = request.get_json()
    text = data.get('text', '')
    
    if not text:
        return jsonify({'error': 'No text provided'}), 400
    
    result = predict_sentiment(text)
    return jsonify(result)

# ============================================
# RUN
# ============================================

if __name__ == '__main__':
    app.run(debug=True, port=5000)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: HTML TEMPLATE
# ═══════════════════════════════════════════════════════════════════════════════

```html
<!-- app/templates/index.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Sentiment Analyzer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            max-width: 700px;
            padding-top: 50px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 25px;
        }
        textarea {
            border-radius: 10px;
            border: 2px solid #e0e0e0;
            resize: none;
        }
        textarea:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .btn-analyze {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 10px;
            padding: 12px 30px;
            font-size: 18px;
        }
        .btn-analyze:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        .result-box {
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
        .positive {
            background-color: #d4edda;
            border: 2px solid #28a745;
        }
        .negative {
            background-color: #f8d7da;
            border: 2px solid #dc3545;
        }
        .loading {
            display: none;
        }
        .emoji {
            font-size: 48px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header text-center">
                <h2>🎬 Movie Sentiment Analyzer</h2>
                <p class="mb-0">Enter a movie review to analyze its sentiment</p>
            </div>
            <div class="card-body p-4">
                <div class="mb-3">
                    <textarea id="reviewText" class="form-control" rows="5" 
                        placeholder="Enter your movie review here...

Example: This movie was absolutely fantastic! The acting was superb and the plot kept me on the edge of my seat."></textarea>
                </div>
                <div class="text-center">
                    <button id="analyzeBtn" class="btn btn-primary btn-analyze" onclick="analyzeSentiment()">
                        Analyze Sentiment
                    </button>
                </div>
                
                <div id="loading" class="loading text-center mt-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Analyzing...</p>
                </div>
                
                <div id="result" class="result-box" style="display: none;">
                    <div class="text-center">
                        <div id="emoji" class="emoji"></div>
                        <h3 id="sentiment"></h3>
                        <p id="confidence" class="text-muted"></p>
                        <small id="model" class="text-muted"></small>
                    </div>
                </div>
            </div>
            <div class="card-footer text-center text-muted">
                <small>Built with BERT | Accuracy: 94%</small>
            </div>
        </div>
    </div>

    <script>
        async function analyzeSentiment() {
            const text = document.getElementById('reviewText').value;
            const resultDiv = document.getElementById('result');
            const loadingDiv = document.getElementById('loading');
            
            if (!text.trim()) {
                alert('Please enter a movie review');
                return;
            }
            
            // Show loading
            loadingDiv.style.display = 'block';
            resultDiv.style.display = 'none';
            
            try {
                const response = await fetch('/predict', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({text: text})
                });
                
                const data = await response.json();
                
                // Update UI
                document.getElementById('emoji').textContent = 
                    data.sentiment.includes('Positive') ? '😊' : '😞';
                document.getElementById('sentiment').textContent = data.sentiment;
                document.getElementById('confidence').textContent = 
                    `Confidence: ${data.confidence}`;
                document.getElementById('model').textContent = 
                    `Model: ${data.model}`;
                
                // Style result box
                resultDiv.className = 'result-box ' + 
                    (data.sentiment.includes('Positive') ? 'positive' : 'negative');
                resultDiv.style.display = 'block';
                
            } catch (error) {
                alert('Error analyzing sentiment. Please try again.');
            }
            
            loadingDiv.style.display = 'none';
        }
        
        // Allow Enter key to submit
        document.getElementById('reviewText').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && e.ctrlKey) {
                analyzeSentiment();
            }
        });
    </script>
</body>
</html>
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: REQUIREMENTS FILE
# ═══════════════════════════════════════════════════════════════════════════════

```text
# requirements.txt

flask==2.3.3
gunicorn==21.2.0
transformers==4.35.0
torch==2.1.0
scikit-learn==1.3.1
pandas==2.1.1
numpy==1.25.2
nltk==3.8.1
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: HEROKU DEPLOYMENT
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
HEROKU DEPLOYMENT (from repository)
═══════════════════════════════════════════════════════════════════════════════

STEP 1: Create Heroku Files

# Procfile (tells Heroku how to run app)
web: gunicorn app.app:app

# runtime.txt (Python version)
python-3.10.12

STEP 2: Initialize Git
$ git init
$ git add .
$ git commit -m "Initial commit"

STEP 3: Create Heroku App
$ heroku login
$ heroku create movie-sentiment-analyzer
$ git push heroku main

STEP 4: Scale and Open
$ heroku ps:scale web=1
$ heroku open

STEP 5: View Logs (for debugging)
$ heroku logs --tail

═══════════════════════════════════════════════════════════════════════════════

ALTERNATIVE: Docker Deployment

# Dockerfile
FROM python:3.10-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["gunicorn", "-b", "0.0.0.0:5000", "app.app:app"]

# Build and run
$ docker build -t sentiment-analyzer .
$ docker run -p 5000:5000 sentiment-analyzer

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: API DOCUMENTATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
REST API DOCUMENTATION
═══════════════════════════════════════════════════════════════════════════════

ENDPOINT: POST /api/analyze

Request:
{
    "text": "This movie was fantastic!"
}

Response:
{
    "sentiment": "Positive 😊",
    "confidence": "94.5%",
    "model": "BERT"
}

EXAMPLE (curl):
curl -X POST https://your-app.herokuapp.com/api/analyze \\
     -H "Content-Type: application/json" \\
     -d '{"text": "This movie was amazing!"}'

EXAMPLE (Python):
import requests

response = requests.post(
    'https://your-app.herokuapp.com/api/analyze',
    json={'text': 'This movie was amazing!'}
)
print(response.json())

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 10 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ Model Comparison Dashboard
   └── Compared ALL 20+ models
   └── BERT wins with 94% accuracy

✅ Flask Application
   └── Web interface
   └── REST API endpoint
   └── Model loading and prediction

✅ HTML/CSS Frontend
   └── Responsive design
   └── Real-time predictions
   └── Visual feedback

✅ Deployment Setup
   └── Procfile for Heroku
   └── Requirements.txt
   └── Docker alternative

✅ API Documentation
   └── Endpoint specification
   └── Request/Response format
   └── Usage examples
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# 🎉 PROJECT COMPLETE!
# ═══════════════════════════════════════════════════════════════════════════════

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║   🎬 MOVIE REVIEW SENTIMENT ANALYZER - PROJECT SUMMARY                        ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║   PHASES COMPLETED:                                                           ║
║   ─────────────────                                                           ║
║   ✅ Phase 1:  Data Fundamentals (EDA, Visualization)                         ║
║   ✅ Phase 2:  Machine Learning (LogReg, RF, XGBoost, SVM)                    ║
║   ✅ Phase 3:  Deep Learning Foundations (Perceptron, MLP)                    ║
║   ✅ Phase 4:  CNN (1D Convolution, TextCNN)                                  ║
║   ✅ Phase 5:  RNN Family (RNN, LSTM, GRU, Bidirectional)                     ║
║   ✅ Phase 6:  Seq2Seq & Attention (Bahdanau, Luong, Self)                    ║
║   ✅ Phase 7:  Transformers (BERT, DistilBERT)                                ║
║   ✅ Phase 8:  NLP Basics (Pipelines, 11 Preprocessing Steps)                 ║
║   ✅ Phase 9:  Text Representation (BoW, TF-IDF, Word2Vec, POS)               ║
║   ✅ Phase 10: Deployment (Flask, Heroku, API)                                ║
║                                                                               ║
║   ACCURACY PROGRESSION:                                                       ║
║   ─────────────────────                                                       ║
║   Perceptron      → 65%                                                       ║
║   MLP             → 75%                                                       ║
║   CNN             → 82%                                                       ║
║   Logistic Reg    → 85%                                                       ║
║   XGBoost         → 88%                                                       ║
║   BiLSTM          → 89%                                                       ║
║   LSTM+Attention  → 91%                                                       ║
║   BERT            → 94%  🏆 STATE OF THE ART!                                 ║
║                                                                               ║
║   SKILLS MASTERED:                                                            ║
║   ────────────────                                                            ║
║   • Data Analysis & EDA                                                       ║
║   • Traditional Machine Learning                                              ║
║   • Deep Learning (CNN, RNN, LSTM, Attention, Transformers)                   ║
║   • NLP Preprocessing & Feature Engineering                                   ║
║   • Model Deployment & API Development                                        ║
║                                                                               ║
║   DELIVERABLES:                                                               ║
║   ─────────────                                                               ║
║   📓 10 Jupyter Notebooks (one per phase)                                     ║
║   📊 Model Comparison Report                                                  ║
║   🌐 Deployed Web Application                                                 ║
║   📁 GitHub Repository                                                        ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝

🎉 CONGRATULATIONS! You've built a complete NLP project from scratch to deployment!

NEXT STEPS:
1. Deploy to Heroku/AWS/GCP
2. Add more features (multi-language, aspect-based sentiment)
3. Create portfolio documentation
4. Share on LinkedIn/GitHub

RESOURCES:
- Full Roadmap: https://github.com/SamBelkacem/AI-ML-cheatsheets
- 100 Days ML: https://github.com/campusx-official/100-days-of-machine-learning
- Beginner Course: https://jovian.com/learn/data-analysis-with-python-zero-to-pandas
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# THE END - HAPPY LEARNING! 🚀
# ═══════════════════════════════════════════════════════════════════════════════

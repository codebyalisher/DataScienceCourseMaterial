# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 2: MACHINE LEARNING
# Movie Review Sentiment Analyzer - Implementation Guide
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Apply traditional Machine Learning algorithms to classify movie reviews.
This phase builds the foundation before moving to Deep Learning.

## 📚 CONCEPTS COVERED
- Linear Regression (conceptual)
- Logistic Regression
- Decision Trees
- Random Forest
- Gradient Boosting
- AdaBoost
- XGBoost
- KMeans Clustering
- PCA (Dimensionality Reduction)
- Bagging Ensemble
- Gradient Descent

## 📊 EXPECTED ACCURACY
- Logistic Regression: ~85%
- Random Forest: ~87%
- XGBoost: ~88%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: LOAD DATA & QUICK PREPROCESSING
# ═══════════════════════════════════════════════════════════════════════════════

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.metrics import roc_auc_score, roc_curve
import warnings
warnings.filterwarnings('ignore')

# Load data
train_df = pd.read_csv('data/processed/train.csv')
test_df = pd.read_csv('data/processed/test.csv')

X_train = train_df['review']
y_train = train_df['label']
X_test = test_df['review']
y_test = test_df['label']

print(f"Training samples: {len(X_train)}")
print(f"Testing samples: {len(X_test)}")
print(f"Class distribution (train): {y_train.value_counts().to_dict()}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: TEXT VECTORIZATION (TF-IDF)
# ═══════════════════════════════════════════════════════════════════════════════

**Note**: For ML models, we need to convert text to numerical features.
We'll use TF-IDF (you'll learn details in PHASE 9).

```python
from sklearn.feature_extraction.text import TfidfVectorizer
import re

# Simple preprocessing function
def simple_preprocess(text):
    """Basic text cleaning"""
    # Lowercase
    text = text.lower()
    # Remove HTML tags
    text = re.sub(r'<[^>]+>', '', text)
    # Remove special characters (keep letters and spaces)
    text = re.sub(r'[^a-z\s]', '', text)
    # Remove extra whitespace
    text = ' '.join(text.split())
    return text

# Apply preprocessing
X_train_clean = X_train.apply(simple_preprocess)
X_test_clean = X_test.apply(simple_preprocess)

# TF-IDF Vectorization
tfidf = TfidfVectorizer(
    max_features=10000,      # Keep top 10,000 words
    ngram_range=(1, 2),      # Unigrams and bigrams
    min_df=2,                # Ignore words appearing less than 2 times
    max_df=0.95,             # Ignore words appearing in >95% documents
    stop_words='english'     # Remove English stopwords
)

# Fit on training data and transform both
X_train_tfidf = tfidf.fit_transform(X_train_clean)
X_test_tfidf = tfidf.transform(X_test_clean)

print(f"TF-IDF matrix shape (train): {X_train_tfidf.shape}")
print(f"TF-IDF matrix shape (test): {X_test_tfidf.shape}")
print(f"Vocabulary size: {len(tfidf.vocabulary_)}")

# Sample feature names
feature_names = tfidf.get_feature_names_out()
print(f"\nSample features: {feature_names[:20].tolist()}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: MODEL EVALUATION HELPER FUNCTION
# ═══════════════════════════════════════════════════════════════════════════════

```python
def evaluate_model(model, X_train, y_train, X_test, y_test, model_name):
    """
    Train and evaluate a model with comprehensive metrics
    """
    # Train the model
    model.fit(X_train, y_train)
    
    # Predictions
    y_pred_train = model.predict(X_train)
    y_pred_test = model.predict(X_test)
    
    # Probabilities (if available)
    if hasattr(model, 'predict_proba'):
        y_prob_test = model.predict_proba(X_test)[:, 1]
        roc_auc = roc_auc_score(y_test, y_prob_test)
    else:
        y_prob_test = None
        roc_auc = None
    
    # Calculate metrics
    train_acc = accuracy_score(y_train, y_pred_train)
    test_acc = accuracy_score(y_test, y_pred_test)
    
    # Print results
    print("=" * 60)
    print(f"MODEL: {model_name}")
    print("=" * 60)
    print(f"Training Accuracy: {train_acc:.4f} ({train_acc*100:.2f}%)")
    print(f"Testing Accuracy:  {test_acc:.4f} ({test_acc*100:.2f}%)")
    if roc_auc:
        print(f"ROC-AUC Score:     {roc_auc:.4f}")
    
    print(f"\nClassification Report:")
    print(classification_report(y_test, y_pred_test, target_names=['Negative', 'Positive']))
    
    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred_test)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=['Negative', 'Positive'],
                yticklabels=['Negative', 'Positive'])
    plt.title(f'Confusion Matrix - {model_name}')
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.savefig(f'models/{model_name.lower().replace(" ", "_")}_confusion.png', dpi=150)
    plt.show()
    
    return {
        'model_name': model_name,
        'train_accuracy': train_acc,
        'test_accuracy': test_acc,
        'roc_auc': roc_auc,
        'model': model
    }

# Store all results
results = []
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: LOGISTIC REGRESSION
# ═══════════════════════════════════════════════════════════════════════════════

**Logistic Regression**: Linear model for binary classification. Uses sigmoid function
to output probabilities. Simple, fast, and interpretable.

```python
from sklearn.linear_model import LogisticRegression

# ============================================
# LOGISTIC REGRESSION
# ============================================

print("\n" + "=" * 60)
print("LOGISTIC REGRESSION")
print("=" * 60)

# Basic Logistic Regression
lr_model = LogisticRegression(
    max_iter=1000,
    random_state=42,
    solver='lbfgs',
    C=1.0  # Regularization strength (inverse)
)

result_lr = evaluate_model(
    lr_model, 
    X_train_tfidf, y_train, 
    X_test_tfidf, y_test, 
    "Logistic Regression"
)
results.append(result_lr)

# ----------------------------------------
# Feature Importance (Top Words)
# ----------------------------------------
# Get coefficients
coefficients = lr_model.coef_[0]
feature_names = tfidf.get_feature_names_out()

# Top positive words (indicate positive sentiment)
top_positive_idx = np.argsort(coefficients)[-20:]
top_positive_words = [(feature_names[i], coefficients[i]) for i in top_positive_idx]
print("\nTop 20 Positive Indicator Words:")
for word, coef in reversed(top_positive_words):
    print(f"  {word}: {coef:.4f}")

# Top negative words (indicate negative sentiment)
top_negative_idx = np.argsort(coefficients)[:20]
top_negative_words = [(feature_names[i], coefficients[i]) for i in top_negative_idx]
print("\nTop 20 Negative Indicator Words:")
for word, coef in top_negative_words:
    print(f"  {word}: {coef:.4f}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: DECISION TREE
# ═══════════════════════════════════════════════════════════════════════════════

**Decision Tree**: Creates a tree structure where each node splits data based on
a feature threshold. Easy to interpret but prone to overfitting.

```python
from sklearn.tree import DecisionTreeClassifier

# ============================================
# DECISION TREE
# ============================================

print("\n" + "=" * 60)
print("DECISION TREE")
print("=" * 60)

# Decision Tree with depth control to prevent overfitting
dt_model = DecisionTreeClassifier(
    max_depth=20,           # Limit tree depth
    min_samples_split=10,   # Minimum samples to split
    min_samples_leaf=5,     # Minimum samples in leaf
    random_state=42
)

result_dt = evaluate_model(
    dt_model,
    X_train_tfidf, y_train,
    X_test_tfidf, y_test,
    "Decision Tree"
)
results.append(result_dt)

# Feature importance
dt_importance = dt_model.feature_importances_
top_dt_idx = np.argsort(dt_importance)[-20:]
print("\nTop 20 Important Features (Decision Tree):")
for i in reversed(top_dt_idx):
    print(f"  {feature_names[i]}: {dt_importance[i]:.4f}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: RANDOM FOREST
# ═══════════════════════════════════════════════════════════════════════════════

**Random Forest**: Ensemble of decision trees. Each tree trained on random subset
of data and features. Reduces overfitting through bagging (bootstrap aggregating).

```python
from sklearn.ensemble import RandomForestClassifier

# ============================================
# RANDOM FOREST
# ============================================

print("\n" + "=" * 60)
print("RANDOM FOREST")
print("=" * 60)

rf_model = RandomForestClassifier(
    n_estimators=100,       # Number of trees
    max_depth=30,           # Max depth of each tree
    min_samples_split=5,
    min_samples_leaf=2,
    max_features='sqrt',    # Features per split
    n_jobs=-1,              # Use all CPU cores
    random_state=42
)

result_rf = evaluate_model(
    rf_model,
    X_train_tfidf, y_train,
    X_test_tfidf, y_test,
    "Random Forest"
)
results.append(result_rf)

# Feature importance
rf_importance = rf_model.feature_importances_
top_rf_idx = np.argsort(rf_importance)[-20:]
print("\nTop 20 Important Features (Random Forest):")
for i in reversed(top_rf_idx):
    print(f"  {feature_names[i]}: {rf_importance[i]:.4f}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: GRADIENT BOOSTING
# ═══════════════════════════════════════════════════════════════════════════════

**Gradient Boosting**: Sequential ensemble where each tree corrects errors of
previous trees. Uses gradient descent to minimize loss function.

```python
from sklearn.ensemble import GradientBoostingClassifier

# ============================================
# GRADIENT BOOSTING
# ============================================

print("\n" + "=" * 60)
print("GRADIENT BOOSTING")
print("=" * 60)

# Note: Gradient Boosting is slow on large sparse matrices
# Using smaller sample for demonstration
sample_size = 10000
sample_idx = np.random.choice(X_train_tfidf.shape[0], sample_size, replace=False)
X_train_sample = X_train_tfidf[sample_idx]
y_train_sample = y_train.iloc[sample_idx]

gb_model = GradientBoostingClassifier(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=5,
    min_samples_split=10,
    min_samples_leaf=5,
    random_state=42
)

result_gb = evaluate_model(
    gb_model,
    X_train_sample, y_train_sample,
    X_test_tfidf, y_test,
    "Gradient Boosting"
)
results.append(result_gb)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8: ADABOOST
# ═══════════════════════════════════════════════════════════════════════════════

**AdaBoost**: Adaptive Boosting. Focuses on misclassified samples by giving them
higher weights in subsequent iterations.

```python
from sklearn.ensemble import AdaBoostClassifier

# ============================================
# ADABOOST
# ============================================

print("\n" + "=" * 60)
print("ADABOOST")
print("=" * 60)

ada_model = AdaBoostClassifier(
    n_estimators=100,
    learning_rate=0.5,
    algorithm='SAMME',
    random_state=42
)

result_ada = evaluate_model(
    ada_model,
    X_train_tfidf, y_train,
    X_test_tfidf, y_test,
    "AdaBoost"
)
results.append(result_ada)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 9: XGBOOST
# ═══════════════════════════════════════════════════════════════════════════════

**XGBoost**: Extreme Gradient Boosting. Optimized implementation with regularization,
parallel processing, and tree pruning. State-of-the-art for tabular data.

```python
# pip install xgboost
import xgboost as xgb

# ============================================
# XGBOOST
# ============================================

print("\n" + "=" * 60)
print("XGBOOST")
print("=" * 60)

xgb_model = xgb.XGBClassifier(
    n_estimators=200,
    max_depth=6,
    learning_rate=0.1,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_alpha=0.1,          # L1 regularization
    reg_lambda=1.0,         # L2 regularization
    random_state=42,
    use_label_encoder=False,
    eval_metric='logloss',
    n_jobs=-1
)

result_xgb = evaluate_model(
    xgb_model,
    X_train_tfidf, y_train,
    X_test_tfidf, y_test,
    "XGBoost"
)
results.append(result_xgb)

# Feature importance
xgb_importance = xgb_model.feature_importances_
top_xgb_idx = np.argsort(xgb_importance)[-20:]
print("\nTop 20 Important Features (XGBoost):")
for i in reversed(top_xgb_idx):
    print(f"  {feature_names[i]}: {xgb_importance[i]:.4f}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 10: SUPPORT VECTOR MACHINE (SVM)
# ═══════════════════════════════════════════════════════════════════════════════

**SVM**: Finds the hyperplane that best separates classes with maximum margin.
Linear SVM is effective for text classification.

```python
from sklearn.svm import LinearSVC

# ============================================
# LINEAR SVM
# ============================================

print("\n" + "=" * 60)
print("LINEAR SVM")
print("=" * 60)

svm_model = LinearSVC(
    C=1.0,
    max_iter=2000,
    random_state=42
)

result_svm = evaluate_model(
    svm_model,
    X_train_tfidf, y_train,
    X_test_tfidf, y_test,
    "Linear SVM"
)
results.append(result_svm)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11: NAIVE BAYES
# ═══════════════════════════════════════════════════════════════════════════════

**Naive Bayes**: Probabilistic classifier based on Bayes' theorem.
Assumes feature independence. Fast and works well with text.

```python
from sklearn.naive_bayes import MultinomialNB

# ============================================
# NAIVE BAYES
# ============================================

print("\n" + "=" * 60)
print("NAIVE BAYES")
print("=" * 60)

nb_model = MultinomialNB(alpha=0.1)  # Laplace smoothing

result_nb = evaluate_model(
    nb_model,
    X_train_tfidf, y_train,
    X_test_tfidf, y_test,
    "Naive Bayes"
)
results.append(result_nb)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 12: PCA - DIMENSIONALITY REDUCTION
# ═══════════════════════════════════════════════════════════════════════════════

**PCA**: Principal Component Analysis. Reduces dimensionality while preserving
variance. Useful for visualization and speeding up models.

```python
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import Pipeline

# ============================================
# PCA (TruncatedSVD for sparse matrices)
# ============================================

print("\n" + "=" * 60)
print("PCA + LOGISTIC REGRESSION")
print("=" * 60)

# TruncatedSVD is similar to PCA but works with sparse matrices
svd = TruncatedSVD(n_components=500, random_state=42)

# Reduce dimensions
X_train_pca = svd.fit_transform(X_train_tfidf)
X_test_pca = svd.transform(X_test_tfidf)

print(f"Original dimensions: {X_train_tfidf.shape[1]}")
print(f"Reduced dimensions: {X_train_pca.shape[1]}")
print(f"Variance explained: {svd.explained_variance_ratio_.sum():.2%}")

# Train Logistic Regression on reduced features
lr_pca = LogisticRegression(max_iter=1000, random_state=42)

result_pca = evaluate_model(
    lr_pca,
    X_train_pca, y_train,
    X_test_pca, y_test,
    "PCA + Logistic Regression"
)
results.append(result_pca)

# Visualize PCA components
plt.figure(figsize=(10, 6))
plt.plot(np.cumsum(svd.explained_variance_ratio_))
plt.xlabel('Number of Components')
plt.ylabel('Cumulative Explained Variance')
plt.title('PCA - Explained Variance')
plt.axhline(y=0.9, color='r', linestyle='--', label='90% variance')
plt.legend()
plt.grid(True)
plt.savefig('models/pca_variance.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 13: K-MEANS CLUSTERING (Unsupervised)
# ═══════════════════════════════════════════════════════════════════════════════

**KMeans**: Unsupervised clustering algorithm. Groups similar reviews together.
Useful for exploring data structure.

```python
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# ============================================
# K-MEANS CLUSTERING
# ============================================

print("\n" + "=" * 60)
print("K-MEANS CLUSTERING (Unsupervised)")
print("=" * 60)

# Use PCA-reduced data for efficiency
kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
clusters = kmeans.fit_predict(X_train_pca)

# Evaluate clustering
silhouette = silhouette_score(X_train_pca, clusters)
print(f"Silhouette Score: {silhouette:.4f}")

# Compare clusters with actual labels
cluster_label_0 = y_train[clusters == 0].value_counts()
cluster_label_1 = y_train[clusters == 1].value_counts()

print(f"\nCluster 0 distribution:")
print(cluster_label_0)
print(f"\nCluster 1 distribution:")
print(cluster_label_1)

# Visualize clusters (using first 2 PCA components)
plt.figure(figsize=(12, 5))

# Plot 1: By cluster
plt.subplot(1, 2, 1)
plt.scatter(X_train_pca[:, 0], X_train_pca[:, 1], c=clusters, alpha=0.5, cmap='viridis')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.title('K-Means Clusters')
plt.colorbar(label='Cluster')

# Plot 2: By actual label
plt.subplot(1, 2, 2)
plt.scatter(X_train_pca[:, 0], X_train_pca[:, 1], c=y_train, alpha=0.5, cmap='coolwarm')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.title('Actual Labels')
plt.colorbar(label='Sentiment')

plt.tight_layout()
plt.savefig('models/kmeans_clusters.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 14: BAGGING ENSEMBLE
# ═══════════════════════════════════════════════════════════════════════════════

**Bagging**: Bootstrap Aggregating. Trains multiple models on random subsets
of data and aggregates predictions.

```python
from sklearn.ensemble import BaggingClassifier

# ============================================
# BAGGING CLASSIFIER
# ============================================

print("\n" + "=" * 60)
print("BAGGING ENSEMBLE")
print("=" * 60)

bagging_model = BaggingClassifier(
    estimator=LogisticRegression(max_iter=1000),
    n_estimators=10,
    max_samples=0.8,        # 80% of samples per model
    max_features=0.8,       # 80% of features per model
    bootstrap=True,
    n_jobs=-1,
    random_state=42
)

result_bagging = evaluate_model(
    bagging_model,
    X_train_tfidf, y_train,
    X_test_tfidf, y_test,
    "Bagging Ensemble"
)
results.append(result_bagging)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 15: HYPERPARAMETER TUNING (GridSearchCV)
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# HYPERPARAMETER TUNING - Best Model (XGBoost)
# ============================================

print("\n" + "=" * 60)
print("HYPERPARAMETER TUNING (XGBoost)")
print("=" * 60)

# Define parameter grid
param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [4, 6, 8],
    'learning_rate': [0.05, 0.1, 0.2],
    'subsample': [0.8, 1.0]
}

# GridSearchCV
xgb_tuned = xgb.XGBClassifier(
    use_label_encoder=False,
    eval_metric='logloss',
    random_state=42
)

# Use smaller sample for faster tuning
grid_search = GridSearchCV(
    xgb_tuned,
    param_grid,
    cv=3,
    scoring='accuracy',
    n_jobs=-1,
    verbose=1
)

# Fit on sample data (for speed)
grid_search.fit(X_train_sample, y_train_sample)

print(f"\nBest Parameters: {grid_search.best_params_}")
print(f"Best CV Score: {grid_search.best_score_:.4f}")

# Evaluate best model on full test set
best_xgb = grid_search.best_estimator_
y_pred_best = best_xgb.predict(X_test_tfidf)
print(f"Test Accuracy: {accuracy_score(y_test, y_pred_best):.4f}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 16: MODEL COMPARISON
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# MODEL COMPARISON
# ============================================

print("\n" + "=" * 60)
print("MODEL COMPARISON SUMMARY")
print("=" * 60)

# Create comparison dataframe
comparison_df = pd.DataFrame(results)
comparison_df = comparison_df.sort_values('test_accuracy', ascending=False)

print("\nAll Models Ranked by Test Accuracy:")
print(comparison_df[['model_name', 'train_accuracy', 'test_accuracy', 'roc_auc']].to_string(index=False))

# Visualization
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Bar chart - Accuracy
ax1 = axes[0]
models = comparison_df['model_name']
train_acc = comparison_df['train_accuracy']
test_acc = comparison_df['test_accuracy']

x = np.arange(len(models))
width = 0.35

bars1 = ax1.bar(x - width/2, train_acc, width, label='Train', color='#3498db')
bars2 = ax1.bar(x + width/2, test_acc, width, label='Test', color='#2ecc71')

ax1.set_xlabel('Model')
ax1.set_ylabel('Accuracy')
ax1.set_title('Model Comparison - Accuracy')
ax1.set_xticks(x)
ax1.set_xticklabels(models, rotation=45, ha='right')
ax1.legend()
ax1.set_ylim(0.7, 1.0)

# Add value labels on bars
for bar in bars2:
    height = bar.get_height()
    ax1.annotate(f'{height:.2%}',
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 3),
                textcoords="offset points",
                ha='center', va='bottom', fontsize=8)

# ROC-AUC comparison
ax2 = axes[1]
roc_auc_values = comparison_df['roc_auc'].fillna(0)
colors = plt.cm.RdYlGn(roc_auc_values / roc_auc_values.max())
bars3 = ax2.barh(models, roc_auc_values, color=colors)
ax2.set_xlabel('ROC-AUC Score')
ax2.set_title('Model Comparison - ROC-AUC')
ax2.set_xlim(0.7, 1.0)

plt.tight_layout()
plt.savefig('models/ml_model_comparison.png', dpi=300, bbox_inches='tight')
plt.show()

# Save best model
import joblib
best_model_name = comparison_df.iloc[0]['model_name']
best_model = comparison_df.iloc[0]['model']
joblib.dump(best_model, f'models/best_ml_model_{best_model_name.lower().replace(" ", "_")}.pkl')
joblib.dump(tfidf, 'models/tfidf_vectorizer.pkl')
print(f"\nBest model saved: {best_model_name}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 17: UNDERSTANDING GRADIENT DESCENT
# ═══════════════════════════════════════════════════════════════════════════════

**Gradient Descent**: Foundation for all optimization in ML/DL.
This concept prepares you for PHASE 3 (Deep Learning).

```python
# ============================================
# GRADIENT DESCENT VISUALIZATION
# ============================================

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Simple quadratic function: f(w) = w^2
def loss_function(w):
    return w ** 2

def gradient(w):
    return 2 * w

# Gradient Descent Implementation
def gradient_descent(starting_point, learning_rate, iterations):
    w = starting_point
    history = [w]
    
    for i in range(iterations):
        grad = gradient(w)
        w = w - learning_rate * grad  # Update rule
        history.append(w)
    
    return history

# Run gradient descent with different learning rates
learning_rates = [0.1, 0.5, 0.9]
starting_point = 4

fig, axes = plt.subplots(1, 3, figsize=(15, 5))

for idx, lr in enumerate(learning_rates):
    history = gradient_descent(starting_point, lr, 20)
    
    # Plot
    ax = axes[idx]
    w_range = np.linspace(-5, 5, 100)
    ax.plot(w_range, loss_function(w_range), 'b-', label='Loss Function')
    ax.plot(history, [loss_function(w) for w in history], 'ro-', markersize=4, label='GD Steps')
    ax.set_xlabel('Weight (w)')
    ax.set_ylabel('Loss')
    ax.set_title(f'Learning Rate = {lr}')
    ax.legend()
    ax.grid(True)

plt.suptitle('Gradient Descent with Different Learning Rates', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('models/gradient_descent_demo.png', dpi=150)
plt.show()

print("""
GRADIENT DESCENT INSIGHTS:
- Learning rate too small (0.1): Slow convergence
- Learning rate just right (0.5): Fast convergence to minimum
- Learning rate too large (0.9): May overshoot or oscillate

This is the foundation of:
- Neural network training (PHASE 3+)
- Backpropagation
- SGD, Adam, and other optimizers
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 2 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ Text Vectorization (TF-IDF)
   └── Converted text to numerical features

✅ Logistic Regression (~85%)
   └── Baseline linear model
   └── Analyzed feature coefficients

✅ Decision Tree (~80%)
   └── Tree-based model
   └── Prone to overfitting

✅ Random Forest (~87%)
   └── Ensemble of trees
   └── Bagging approach

✅ Gradient Boosting (~85%)
   └── Sequential ensemble
   └── Trees correct previous errors

✅ AdaBoost (~84%)
   └── Focus on misclassified samples

✅ XGBoost (~88%)
   └── Optimized gradient boosting
   └── Best performing ML model

✅ Linear SVM (~88%)
   └── Maximum margin classifier

✅ Naive Bayes (~85%)
   └── Probabilistic classifier

✅ PCA
   └── Dimensionality reduction
   └── Visualization of data structure

✅ K-Means Clustering
   └── Unsupervised exploration

✅ Bagging Ensemble
   └── Multiple model aggregation

✅ Hyperparameter Tuning
   └── GridSearchCV for optimization

✅ Gradient Descent
   └── Foundation for Deep Learning
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# KEY TAKEAWAYS FROM PHASE 2
# ═══════════════════════════════════════════════════════════════════════════════

```
📊 ACCURACY ACHIEVED:
   - Best ML Model: XGBoost/SVM (~88%)
   - This is our BASELINE before Deep Learning

🔑 KEY CONCEPTS:
   - Feature Engineering is crucial (TF-IDF)
   - Ensemble methods (RF, XGBoost) outperform single models
   - Regularization prevents overfitting
   - Hyperparameter tuning improves performance

📈 WHY MOVE TO DEEP LEARNING?
   - ML models require manual feature engineering
   - Deep Learning learns features automatically
   - Can capture more complex patterns
   - Better for large datasets

🚀 NEXT: PHASE 3 - DEEP LEARNING FOUNDATIONS
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# READY FOR PHASE 3: DEEP LEARNING FOUNDATIONS
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 5: RNN FAMILY (RNN, LSTM, GRU)
# Movie Review Sentiment Analyzer - Implementation Guide
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Process sequential data with memory. Understand vanishing gradients and solutions.

## 📚 CONCEPTS COVERED
- Why RNN (Sequential Data)
- RNN vs ANN
- RNN Internal Working
- LSTM (Long Short-Term Memory)
- GRU (Gated Recurrent Unit)
- Stacked RNN/LSTM/GRU
- Bidirectional RNN/LSTM/GRU

## 📊 EXPECTED ACCURACY
- Simple RNN: ~75-80%
- LSTM: ~85-88%
- Bidirectional LSTM: ~88-90%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: WHY RNN? (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
WHY RNN? (from repository)
═══════════════════════════════════════════════════════════════════════════════

"RNN is basically used when data is SEQUENTIAL - one after other like text.
'I am Alisher' - sequential order matters, we can't change it.
In CNN/ANN inputs are FIXED, but text can VARY in length."

PROBLEMS WITH CNN/ANN FOR TEXT:
┌──────────────────────────────────────────────────────────────────────────────┐
│ 1. Input size → VARYING (text can be any length)                            │
│ 2. Zero padding → UNNECESSARY computation                                    │
│ 3. Prediction problem if someone enters less text                           │
│ 4. TOTALLY DISREGARDING SEQUENTIAL INFORMATION ← BIGGEST ISSUE!             │
└──────────────────────────────────────────────────────────────────────────────┘

EXAMPLE:
"I love you" vs "You love I" - ORDER MATTERS!
CNN/ANN treats both the same (bag of words)

RNN SOLUTION:
- Process ONE word at a TIME
- Remember previous words (hidden state)
- Order is preserved

RNN VS ANN (from repo):
┌─────────────────────────────────────────────────────────────────────────────┐
│ "ANN is FEED FORWARD while RNN sends FEED BACKWARD to the hidden state"     │
│ "In RNN the data or one input is given at a TIME BASIS, then rest one by one"│
└─────────────────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: RNN INTERNAL WORKING (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
RNN INTERNAL WORKING (from repository)
═══════════════════════════════════════════════════════════════════════════════

"In RNN architecture, vocabulary is converted into vectors, then passed to 
input layer where inputs are multiplied with weights+bias and passed to tanh 
(since vectors are 1 and 0 values).

In first time/loop we pass RANDOM output along with weights as input.
In next loop: xi*w + o1*wh + bias → tanh → output
Same process repeated."

STEP-BY-STEP:

STEP 1: Convert Vocabulary to Vectors
┌─────────────────────────────────────────────────────────────────────────────┐
│ Words/characters → numerical vectors                                         │
│ Using: one-hot encoding OR word embeddings                                  │
└─────────────────────────────────────────────────────────────────────────────┘

STEP 2: First Time Step (t=1)
┌─────────────────────────────────────────────────────────────────────────────┐
│ • Input vector × input weights + bias                                       │
│ • Hidden state initialized RANDOMLY or ZERO                                 │
│ • Pass through tanh activation                                              │
│ • Get output                                                                │
└─────────────────────────────────────────────────────────────────────────────┘

STEP 3: Subsequent Time Steps (t=2, 3, ...)
┌─────────────────────────────────────────────────────────────────────────────┐
│ Formula: ht = tanh(xi * Wx + h(t-1) * Wh + bias)                            │
│                                                                             │
│ Where:                                                                      │
│   xi = current input                                                        │
│   Wx = input weights                                                        │
│   h(t-1) = PREVIOUS hidden state (memory!)                                  │
│   Wh = hidden state weights                                                 │
│   bias = bias term                                                          │
└─────────────────────────────────────────────────────────────────────────────┘

VISUAL:
          ┌──────────┐
    xt →  │   RNN    │ → ht (output)
          │   Cell   │
          └────┬─────┘
               ↑
          h(t-1) (previous hidden state - THE MEMORY!)

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: LOAD DATA AND PREPARE
# ═══════════════════════════════════════════════════════════════════════════════

```python
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import EarlyStopping
import pandas as pd
import numpy as np
import re
import matplotlib.pyplot as plt

# Load data
train_df = pd.read_csv('data/processed/train.csv')
test_df = pd.read_csv('data/processed/test.csv')

def preprocess(text):
    text = str(text).lower()
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'[^a-z\s]', '', text)
    return ' '.join(text.split())

X_train = train_df['review'].apply(preprocess)
y_train = train_df['label'].values
X_test = test_df['review'].apply(preprocess)
y_test = test_df['label'].values

# Tokenization
vocab_size = 20000
max_length = 200
embedding_dim = 128

tokenizer = Tokenizer(num_words=vocab_size, oov_token='<OOV>')
tokenizer.fit_on_texts(X_train)

X_train_seq = tokenizer.texts_to_sequences(X_train)
X_test_seq = tokenizer.texts_to_sequences(X_test)

X_train_pad = pad_sequences(X_train_seq, maxlen=max_length, padding='post')
X_test_pad = pad_sequences(X_test_seq, maxlen=max_length, padding='post')

print(f"Training shape: {X_train_pad.shape}")
print(f"Testing shape: {X_test_pad.shape}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: SIMPLE RNN
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# SIMPLE RNN
# ============================================

print("\n" + "=" * 60)
print("SIMPLE RNN")
print("=" * 60)

model_rnn = keras.Sequential([
    layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
    
    # Simple RNN layer
    layers.SimpleRNN(
        units=64,           # Number of RNN units
        activation='tanh',  # Default for RNN (vectors are 0/1)
        return_sequences=False  # Only return last output
    ),
    
    layers.Dense(32, activation='relu'),
    layers.Dropout(0.5),
    layers.Dense(1, activation='sigmoid')
])

model_rnn.summary()

model_rnn.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

history_rnn = model_rnn.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=10,
    batch_size=128,
    callbacks=[EarlyStopping(patience=2, restore_best_weights=True)],
    verbose=1
)

test_loss, test_acc = model_rnn.evaluate(X_test_pad, y_test)
print(f"\nSimple RNN Test Accuracy: {test_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: LSTM (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
LSTM - Long Short-Term Memory (from repository)
═══════════════════════════════════════════════════════════════════════════════

"Traditional RNNs struggle with LONG-TERM DEPENDENCIES due to VANISHING GRADIENTS.
LSTM was introduced to address this problem."

LSTM vs RNN:
┌─────────────────────────────────────────────────────────────────────────────┐
│ RNN:  Only hidden state (short-term memory)                                 │
│ LSTM: Cell state (LONG-term) + Hidden state (SHORT-term)                    │
└─────────────────────────────────────────────────────────────────────────────┘

THREE GATES (from repo):
"To manage what information to keep, update, or discard, LSTMs use THREE gates"

1️⃣ FORGET GATE: What to FORGET from previous state
   "Should I forget the previous subject when I see a new one?"

2️⃣ INPUT GATE: What NEW information to ADD
   "Should I remember this new word is important?"

3️⃣ OUTPUT GATE: What to OUTPUT
   "What should I output based on current state?"

GATE VALUES (from repo):
┌─────────────────────────────────────────────────────────────────────────────┐
│ Gate Value  │ Meaning                                                       │
├─────────────┼───────────────────────────────────────────────────────────────┤
│     0       │ STOP all information                                          │
│    0.5      │ Pass 50% of information                                       │
│     1       │ Pass FULL information                                         │
└─────────────┴───────────────────────────────────────────────────────────────┘

INTERNAL WORKING (from repo):
"Three inputs: cell state ct, hidden state st/ht, and input xt
Two things happen in node: UPDATE and CREATE hidden state
Two outputs: ct and ht"

VISUAL:
                    ┌───────────────────────────────────────┐
                    │              LSTM CELL                │
     c(t-1) ────────│→ [Forget] → [Input] → [Cell State] → │─────→ ct
                    │                  ↓                    │
     h(t-1) ────────│→         [Output Gate]            → │─────→ ht
                    │                  ↑                    │
     xt ────────────│→─────────────────┘                   │
                    └───────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════
""")

# ============================================
# LSTM MODEL
# ============================================

print("\n" + "=" * 60)
print("LSTM")
print("=" * 60)

model_lstm = keras.Sequential([
    layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
    
    # LSTM layer
    layers.LSTM(
        units=64,
        activation='tanh',
        recurrent_activation='sigmoid',
        return_sequences=False
    ),
    
    layers.Dense(32, activation='relu'),
    layers.Dropout(0.5),
    layers.Dense(1, activation='sigmoid')
])

model_lstm.summary()

model_lstm.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

history_lstm = model_lstm.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=10,
    batch_size=128,
    callbacks=[EarlyStopping(patience=2, restore_best_weights=True)],
    verbose=1
)

test_loss, test_acc = model_lstm.evaluate(X_test_pad, y_test)
print(f"\nLSTM Test Accuracy: {test_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: GRU (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
GRU - Gated Recurrent Unit (from repository)
═══════════════════════════════════════════════════════════════════════════════

"GRU is a SIMPLIFIED version of LSTM with 2 gates instead of 3"

GRU vs LSTM:
┌──────────────────┬─────────────────────────┬─────────────────────────────────┐
│ Feature          │ LSTM                    │ GRU                             │
├──────────────────┼─────────────────────────┼─────────────────────────────────┤
│ Gates            │ 3 (forget, input, output)│ 2 (reset, update)              │
│ Memory           │ Cell state + Hidden      │ Hidden state only              │
│ Parameters       │ More                     │ Fewer                          │
│ Training Speed   │ Slower                   │ Faster                         │
│ Performance      │ Better on complex        │ Good, faster                   │
└──────────────────┴─────────────────────────┴─────────────────────────────────┘

GRU GATES:
1️⃣ RESET GATE: How much past to forget
2️⃣ UPDATE GATE: How much new info to add (combines forget + input)

═══════════════════════════════════════════════════════════════════════════════
""")

# ============================================
# GRU MODEL
# ============================================

print("\n" + "=" * 60)
print("GRU")
print("=" * 60)

model_gru = keras.Sequential([
    layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
    
    # GRU layer
    layers.GRU(
        units=64,
        activation='tanh',
        recurrent_activation='sigmoid',
        return_sequences=False
    ),
    
    layers.Dense(32, activation='relu'),
    layers.Dropout(0.5),
    layers.Dense(1, activation='sigmoid')
])

model_gru.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

history_gru = model_gru.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=10,
    batch_size=128,
    callbacks=[EarlyStopping(patience=2, restore_best_weights=True)],
    verbose=1
)

test_loss, test_acc = model_gru.evaluate(X_test_pad, y_test)
print(f"\nGRU Test Accuracy: {test_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: STACKED LSTM/GRU (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
STACKED LSTM/GRU (from repository)
═══════════════════════════════════════════════════════════════════════════════

"Stacked LSTMs are a layered version where multiple LSTM layers are stacked.
Each LSTM layer receives the sequence of hidden states from the layer below.

Lower layers: Handle SHORT-TERM dependencies
Upper layers: Capture LONG-TERM relationships"

VISUAL:
┌─────────────────────────────────────────────────────────────────────────────┐
│ Input Sequence                                                              │
│       ↓                                                                     │
│ [LSTM Layer 1] → handles short-term dependencies                            │
│       ↓                                                                     │
│ [LSTM Layer 2] → captures medium-term patterns                              │
│       ↓                                                                     │
│ [LSTM Layer 3] → captures long-term relationships                           │
│       ↓                                                                     │
│ Output                                                                      │
└─────────────────────────────────────────────────────────────────────────────┘

IMPORTANT: For stacked layers, use return_sequences=True for all except last!

═══════════════════════════════════════════════════════════════════════════════
""")

# ============================================
# STACKED LSTM
# ============================================

print("\n" + "=" * 60)
print("STACKED LSTM")
print("=" * 60)

model_stacked_lstm = keras.Sequential([
    layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
    
    # First LSTM layer - return_sequences=True to pass to next LSTM
    layers.LSTM(64, return_sequences=True),
    layers.Dropout(0.3),
    
    # Second LSTM layer - return_sequences=False (last layer)
    layers.LSTM(32, return_sequences=False),
    layers.Dropout(0.3),
    
    layers.Dense(32, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])

model_stacked_lstm.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

history_stacked = model_stacked_lstm.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=10,
    batch_size=128,
    callbacks=[EarlyStopping(patience=2, restore_best_weights=True)],
    verbose=1
)

test_loss, test_acc = model_stacked_lstm.evaluate(X_test_pad, y_test)
print(f"\nStacked LSTM Test Accuracy: {test_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8: BIDIRECTIONAL LSTM (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
BIDIRECTIONAL RNN/LSTM/GRU (from repository)
═══════════════════════════════════════════════════════════════════════════════

"Process the sequence in BOTH forward and backward directions, capturing 
context from both PAST and FUTURE positions."

EXAMPLE:
Sentence: "The bank by the river was beautiful"

Forward only:  "bank" → could be financial bank (doesn't know "river" comes after)
Bidirectional: "bank" → riverbank (knows "river" comes after!)

VISUAL:
┌─────────────────────────────────────────────────────────────────────────────┐
│ Forward LSTM:   → → → → → →                                                 │
│                 T h e   b a n k                                             │
│ Backward LSTM:  ← ← ← ← ← ←                                                 │
│                                                                             │
│ Output = Concatenate(Forward, Backward)                                     │
└─────────────────────────────────────────────────────────────────────────────┘

BENEFITS:
- Captures BOTH past AND future context
- Better understanding of word meaning
- Useful for: NER, POS tagging, translation, sentiment analysis

═══════════════════════════════════════════════════════════════════════════════
""")

# ============================================
# BIDIRECTIONAL LSTM
# ============================================

print("\n" + "=" * 60)
print("BIDIRECTIONAL LSTM")
print("=" * 60)

model_bilstm = keras.Sequential([
    layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
    
    # Bidirectional LSTM
    layers.Bidirectional(layers.LSTM(64, return_sequences=True)),
    layers.Dropout(0.3),
    
    layers.Bidirectional(layers.LSTM(32)),
    layers.Dropout(0.3),
    
    layers.Dense(32, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])

model_bilstm.summary()

model_bilstm.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

history_bilstm = model_bilstm.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=10,
    batch_size=128,
    callbacks=[EarlyStopping(patience=2, restore_best_weights=True)],
    verbose=1
)

test_loss, test_acc = model_bilstm.evaluate(X_test_pad, y_test)
print(f"\nBidirectional LSTM Test Accuracy: {test_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 9: RNN ARCHITECTURES (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
RNN ARCHITECTURES (from repository)
═══════════════════════════════════════════════════════════════════════════════

1️⃣ ONE-TO-ONE
   Input: Single    Output: Single
   Example: Basic classification
   
2️⃣ ONE-TO-MANY
   Input: Single    Output: Sequence
   Example: Image captioning (image → sentence)
   
3️⃣ MANY-TO-ONE
   Input: Sequence  Output: Single
   Example: SENTIMENT ANALYSIS (sentence → positive/negative) ← OUR TASK!
   
4️⃣ MANY-TO-MANY (Synchronized)
   Input: Sequence  Output: Same length sequence
   Example: Video frame labeling
   
5️⃣ MANY-TO-MANY (Asynchronous)
   Input: Sequence  Output: Different length sequence
   Example: Machine translation (English → French)

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 10: MODEL COMPARISON
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# COMPARISON VISUALIZATION
# ============================================

results = {
    'Simple RNN': model_rnn.evaluate(X_test_pad, y_test, verbose=0)[1],
    'LSTM': model_lstm.evaluate(X_test_pad, y_test, verbose=0)[1],
    'GRU': model_gru.evaluate(X_test_pad, y_test, verbose=0)[1],
    'Stacked LSTM': model_stacked_lstm.evaluate(X_test_pad, y_test, verbose=0)[1],
    'Bidirectional LSTM': model_bilstm.evaluate(X_test_pad, y_test, verbose=0)[1]
}

print("\n" + "=" * 60)
print("RNN FAMILY - RESULTS COMPARISON")
print("=" * 60)

for model_name, acc in sorted(results.items(), key=lambda x: x[1], reverse=True):
    print(f"{model_name}: {acc:.2%}")

# Plot
plt.figure(figsize=(10, 6))
models = list(results.keys())
accuracies = list(results.values())
colors = plt.cm.RdYlGn([acc for acc in accuracies])

bars = plt.barh(models, accuracies, color=colors)
plt.xlabel('Test Accuracy')
plt.title('RNN Family - Model Comparison')
plt.xlim(0.7, 1.0)

for bar, acc in zip(bars, accuracies):
    plt.text(acc + 0.005, bar.get_y() + bar.get_height()/2, 
             f'{acc:.2%}', va='center')

plt.tight_layout()
plt.savefig('models/rnn_comparison.png', dpi=150)
plt.show()

# Save best model
model_bilstm.save('models/bilstm_best.h5')
print("\nBest model (BiLSTM) saved!")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 5 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ Why RNN
   └── Sequential data processing
   └── Variable input lengths
   └── Preserves word order

✅ RNN vs ANN
   └── ANN: Feed forward only
   └── RNN: Feed backward to hidden state

✅ RNN Internal Working
   └── ht = tanh(xi*Wx + h(t-1)*Wh + b)
   └── Hidden state carries memory

✅ Simple RNN (~75-80%)
   └── Basic recurrent processing
   └── Vanishing gradient problem

✅ LSTM (~85-88%)
   └── 3 gates: Forget, Input, Output
   └── Cell state for long-term memory
   └── Solves vanishing gradient

✅ GRU (~84-87%)
   └── 2 gates: Reset, Update
   └── Simpler, faster than LSTM

✅ Stacked LSTM (~87-89%)
   └── Multiple layers
   └── return_sequences=True

✅ Bidirectional LSTM (~88-90%)
   └── Forward + Backward processing
   └── Better context understanding
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY ACHIEVED
# ═══════════════════════════════════════════════════════════════════════════════

```
📊 PHASE 5 RESULTS:

Model                          | Accuracy
-------------------------------|----------
Simple RNN                     | ~75-80%
LSTM                           | ~85-88%
GRU                            | ~84-87%
Stacked LSTM                   | ~87-89%
Bidirectional LSTM             | ~88-90%

📈 Progress:
   ML Best (XGBoost): ~88%
   CNN: ~80-82%
   BiLSTM: ~88-90% ← NOW MATCHING ML!

🚀 NEXT: PHASE 6 - ATTENTION
   Can we do even better by focusing on important words?
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# READY FOR PHASE 6: SEQ2SEQ & ATTENTION
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 7: TRANSFORMERS
# Movie Review Sentiment Analyzer - Implementation Guide
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Master the Transformer architecture and fine-tune BERT for state-of-the-art results.

## 📚 CONCEPTS COVERED
- Transformer Architecture ("Attention Is All You Need")
- Multi-Head Attention
- Positional Encoding
- BERT (Bidirectional Encoder Representations)
- Fine-tuning Pretrained Models
- DistilBERT (Lightweight Alternative)

## 📊 EXPECTED ACCURACY
- BERT Fine-tuned: ~93-94%
- DistilBERT: ~92%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: TRANSFORMER ARCHITECTURE
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
TRANSFORMER ARCHITECTURE - "Attention Is All You Need" (2017)
═══════════════════════════════════════════════════════════════════════════════

KEY INNOVATION:
┌─────────────────────────────────────────────────────────────────────────────┐
│ • NO recurrence (no RNN/LSTM) → Can process in PARALLEL                     │
│ • NO convolution (no CNN)                                                   │
│ • ONLY attention mechanisms                                                 │
│ • Much FASTER training on GPUs                                              │
└─────────────────────────────────────────────────────────────────────────────┘

ARCHITECTURE OVERVIEW:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                            ┌──────────────┐                                 │
│                            │   OUTPUTS    │                                 │
│                            │  (shifted)   │                                 │
│                            └──────┬───────┘                                 │
│                                   │                                         │
│                            ┌──────┴───────┐                                 │
│                            │   DECODER    │                                 │
│                            │  (N=6 layers)│                                 │
│                            └──────┬───────┘                                 │
│                                   │                                         │
│                                   ├──────────────┐                          │
│                                   │              │                          │
│    ┌──────────────┐        ┌──────┴───────┐      │                          │
│    │   INPUTS     │        │   ENCODER    │      │                          │
│    │  EMBEDDING   │───────►│  (N=6 layers)│──────┘                          │
│    │     +        │        └──────────────┘                                 │
│    │  POSITIONAL  │                                                         │
│    │   ENCODING   │                                                         │
│    └──────────────┘                                                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

ENCODER LAYER COMPONENTS:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   Input                                                                     │
│     │                                                                       │
│     ▼                                                                       │
│   ┌─────────────────────────┐                                               │
│   │  Multi-Head Attention   │  ← Self-attention over input                  │
│   └───────────┬─────────────┘                                               │
│               │                                                             │
│               ▼                                                             │
│   ┌─────────────────────────┐                                               │
│   │  Add & Layer Normalize  │  ← Residual connection + normalization        │
│   └───────────┬─────────────┘                                               │
│               │                                                             │
│               ▼                                                             │
│   ┌─────────────────────────┐                                               │
│   │  Feed-Forward Network   │  ← Two linear layers with ReLU                │
│   └───────────┬─────────────┘                                               │
│               │                                                             │
│               ▼                                                             │
│   ┌─────────────────────────┐                                               │
│   │  Add & Layer Normalize  │  ← Another residual + norm                    │
│   └───────────┬─────────────┘                                               │
│               │                                                             │
│               ▼                                                             │
│            Output                                                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

DECODER LAYER COMPONENTS:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   1. MASKED Multi-Head Self-Attention                                       │
│      → Prevents looking at future tokens                                    │
│                                                                             │
│   2. Add & Layer Normalize                                                  │
│                                                                             │
│   3. Multi-Head Cross-Attention (to encoder outputs)                        │
│      → Attends to encoder representations                                   │
│                                                                             │
│   4. Add & Layer Normalize                                                  │
│                                                                             │
│   5. Feed-Forward Network                                                   │
│                                                                             │
│   6. Add & Layer Normalize                                                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: MULTI-HEAD ATTENTION
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
MULTI-HEAD ATTENTION
═══════════════════════════════════════════════════════════════════════════════

WHY MULTIPLE HEADS?
- Single attention focuses on ONE type of relationship
- Multiple heads capture DIFFERENT relationships simultaneously
- Like having multiple "perspectives" on the same data

EXAMPLE:
"The cat sat on the mat because it was comfortable"

Head 1: Might focus on SYNTACTIC relationships
        (subject-verb: cat → sat)

Head 2: Might focus on SEMANTIC relationships
        (pronoun resolution: it → cat)

Head 3: Might focus on POSITIONAL relationships
        (nearby words: sat → on → the → mat)

Head 4: Might focus on LOGICAL relationships
        (cause: because → comfortable)

FORMULA:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   MultiHead(Q, K, V) = Concat(head₁, head₂, ..., headₕ) × Wᴼ               │
│                                                                             │
│   where headᵢ = Attention(Q × Wᵢᵠ, K × Wᵢᴷ, V × Wᵢⱽ)                       │
│                                                                             │
│   Typical values:                                                           │
│   • d_model = 512 (hidden dimension)                                        │
│   • h = 8 (number of heads)                                                 │
│   • dₖ = dᵥ = d_model / h = 64 (dimension per head)                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

VISUAL:
┌────────────────────────────────────────────────────────────────────────────┐
│                          Input (Q, K, V)                                   │
│                               │                                            │
│         ┌─────────┬───────────┼───────────┬─────────┐                      │
│         ▼         ▼           ▼           ▼         ▼                      │
│    ┌────────┐┌────────┐  ┌────────┐  ┌────────┐┌────────┐                  │
│    │ Head 1 ││ Head 2 │  │ Head 3 │  │ Head 4 ││  ...   │                  │
│    │(Wq,Wk,Wv)│(Wq,Wk,Wv)│(Wq,Wk,Wv)│(Wq,Wk,Wv)│        │                  │
│    └────┬───┘└────┬───┘  └────┬───┘  └────┬───┘└────┬───┘                  │
│         │         │           │           │         │                      │
│         └─────────┴───────────┼───────────┴─────────┘                      │
│                               ▼                                            │
│                        ┌────────────┐                                      │
│                        │ Concatenate │                                      │
│                        └──────┬─────┘                                      │
│                               │                                            │
│                        ┌──────┴─────┐                                      │
│                        │  Linear Wᴼ │                                      │
│                        └──────┬─────┘                                      │
│                               │                                            │
│                            Output                                          │
└────────────────────────────────────────────────────────────────────────────┘

COMPUTATION EXAMPLE:
Input: 512-dimensional embeddings
Heads: 8
Each head: 512/8 = 64 dimensions

Head 1: Attention on 64-dim slice
Head 2: Attention on 64-dim slice
...
Head 8: Attention on 64-dim slice

Concat all heads: 8 × 64 = 512 dimensions
Final linear: 512 → 512

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: POSITIONAL ENCODING
# ═══════════════════════════════════════════════════════════════════════════════

```python
import numpy as np
import matplotlib.pyplot as plt

print("""
═══════════════════════════════════════════════════════════════════════════════
POSITIONAL ENCODING
═══════════════════════════════════════════════════════════════════════════════

THE PROBLEM:
- Transformers process all tokens in PARALLEL
- No inherent notion of POSITION (unlike RNN which processes sequentially)
- "I love you" and "you love I" would be the SAME without position info!

SOLUTION - Sinusoidal Positional Encoding:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   PE(pos, 2i)   = sin(pos / 10000^(2i/d_model))                             │
│   PE(pos, 2i+1) = cos(pos / 10000^(2i/d_model))                             │
│                                                                             │
│   Where:                                                                    │
│   • pos = position in sequence (0, 1, 2, ...)                               │
│   • i = dimension index (0, 1, 2, ..., d_model/2)                           │
│   • d_model = embedding dimension (e.g., 512)                               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

WHY SINUSOIDAL?
1. Allows model to learn RELATIVE positions
   (PE[pos+k] can be represented as linear function of PE[pos])

2. Can extrapolate to longer sequences than seen during training

3. Unique encoding for each position
   (different frequency patterns)

4. Values bounded between -1 and 1

HOW IT'S USED:
Final_Embedding = Word_Embedding + Positional_Encoding

═══════════════════════════════════════════════════════════════════════════════
""")

# ============================================
# IMPLEMENT POSITIONAL ENCODING
# ============================================

def get_positional_encoding(max_len, d_model):
    """
    Generate sinusoidal positional encoding
    
    Args:
        max_len: Maximum sequence length
        d_model: Embedding dimension
    
    Returns:
        Positional encoding matrix (max_len, d_model)
    """
    # Position indices
    position = np.arange(max_len)[:, np.newaxis]
    
    # Dimension indices
    div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))
    
    # Initialize positional encoding
    pe = np.zeros((max_len, d_model))
    
    # Apply sin to even indices
    pe[:, 0::2] = np.sin(position * div_term)
    
    # Apply cos to odd indices
    pe[:, 1::2] = np.cos(position * div_term)
    
    return pe

# Generate and visualize
pe = get_positional_encoding(100, 128)

print(f"Positional encoding shape: {pe.shape}")
print(f"Position 0: {pe[0, :10].round(3)}")
print(f"Position 1: {pe[1, :10].round(3)}")

# Visualization
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Full positional encoding matrix
ax1 = axes[0]
im = ax1.imshow(pe, cmap='RdBu', aspect='auto')
ax1.set_xlabel('Embedding Dimension')
ax1.set_ylabel('Position in Sequence')
ax1.set_title('Positional Encoding Matrix')
plt.colorbar(im, ax=ax1)

# Individual dimension waves
ax2 = axes[1]
positions = np.arange(100)
ax2.plot(positions, pe[:, 0], label='dim 0')
ax2.plot(positions, pe[:, 10], label='dim 10')
ax2.plot(positions, pe[:, 50], label='dim 50')
ax2.plot(positions, pe[:, 100], label='dim 100')
ax2.set_xlabel('Position')
ax2.set_ylabel('Encoding Value')
ax2.set_title('Positional Encoding Waves')
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.savefig('models/positional_encoding.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: BERT OVERVIEW
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
BERT - Bidirectional Encoder Representations from Transformers (Google, 2018)
═══════════════════════════════════════════════════════════════════════════════

KEY INNOVATION:
- Uses ONLY the ENCODER part of Transformer
- BIDIRECTIONAL (looks at both left AND right context)
- Unlike GPT which is left-to-right only

BERT vs GPT:
┌────────────────┬─────────────────────────┬──────────────────────────────┐
│ Feature        │ BERT                    │ GPT                          │
├────────────────┼─────────────────────────┼──────────────────────────────┤
│ Direction      │ Bidirectional           │ Left-to-right only           │
│ Architecture   │ Encoder only            │ Decoder only                 │
│ Pre-training   │ MLM + NSP               │ Language Modeling            │
│ Best for       │ Understanding tasks     │ Generation tasks             │
│                │ (classification, QA)    │ (text generation)            │
└────────────────┴─────────────────────────┴──────────────────────────────┘

PRE-TRAINING TASKS:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│ 1. MASKED LANGUAGE MODELING (MLM):                                          │
│    • Randomly mask 15% of tokens                                            │
│    • Model predicts the masked tokens                                       │
│    • Example: "The [MASK] sat on the mat" → "cat"                           │
│                                                                             │
│ 2. NEXT SENTENCE PREDICTION (NSP):                                          │
│    • Given two sentences, predict if B follows A                            │
│    • Example: "I love cats. [SEP] They are cute." → IsNext: True            │
│    • Example: "I love cats. [SEP] The sky is blue." → IsNext: False         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

BERT VARIANTS:
┌────────────────┬────────────────┬────────────────┬────────────────┐
│ Model          │ Layers         │ Hidden Size    │ Parameters     │
├────────────────┼────────────────┼────────────────┼────────────────┤
│ BERT-Base      │ 12             │ 768            │ 110M           │
│ BERT-Large     │ 24             │ 1024           │ 340M           │
│ DistilBERT     │ 6              │ 768            │ 66M (40% less) │
│ RoBERTa        │ 12/24          │ 768/1024       │ 125M/355M      │
│ ALBERT         │ 12             │ 768            │ 12M (lighter)  │
└────────────────┴────────────────┴────────────────┴────────────────┘

BERT INPUT FORMAT:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│ [CLS] This movie was great [SEP] I loved it [SEP]                           │
│   │                           │              │                              │
│   └── Classification token    └── Separator  └── End of sequence            │
│                                                                             │
│ Token IDs:     [101, 2023, 3185, 2001, 2307, 102, 1045, 3866, 2009, 102]    │
│ Segment IDs:   [0,   0,    0,    0,    0,    0,   1,    1,    1,    1]      │
│ Position IDs:  [0,   1,    2,    3,    4,    5,   6,    7,    8,    9]      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

FINE-TUNING FOR SENTIMENT:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   [CLS] This movie was great [SEP]                                          │
│     │                                                                       │
│     ▼                                                                       │
│   ┌─────────────────────────┐                                               │
│   │   PRETRAINED BERT       │ ← Weights already learned on huge corpus!     │
│   │   (768-dim output)      │                                               │
│   └──────────┬──────────────┘                                               │
│              │                                                              │
│              ▼ (take [CLS] token output)                                    │
│   ┌─────────────────────────┐                                               │
│   │  Classification Head    │ ← Train this for your task                    │
│   │  (Linear + Softmax)     │                                               │
│   └──────────┬──────────────┘                                               │
│              │                                                              │
│              ▼                                                              │
│      Positive / Negative                                                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: INSTALL AND SETUP
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# INSTALL REQUIRED PACKAGES
# ============================================

# pip install transformers datasets torch

print("""
HUGGING FACE TRANSFORMERS LIBRARY:
- Easy access to 100,000+ pretrained models
- Simple fine-tuning API
- Works with PyTorch and TensorFlow

Key Classes:
- AutoTokenizer: Handles text tokenization (subword)
- AutoModel: Loads pretrained model weights
- Trainer: Simplifies training loop
- Pipeline: Quick inference

Model Hub: https://huggingface.co/models
""")

import torch
from transformers import (
    AutoTokenizer, 
    AutoModelForSequenceClassification,
    Trainer, 
    TrainingArguments,
    pipeline
)
from datasets import Dataset
import pandas as pd
import numpy as np

# Check device
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Using device: {device}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: LOAD AND PREPARE DATA
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# LOAD DATA
# ============================================

train_df = pd.read_csv('data/processed/train.csv')
test_df = pd.read_csv('data/processed/test.csv')

# Use smaller subset for faster training (adjust as needed)
TRAIN_SIZE = 10000
TEST_SIZE = 2000

train_df = train_df.sample(n=TRAIN_SIZE, random_state=42)
test_df = test_df.sample(n=TEST_SIZE, random_state=42)

print(f"Training samples: {len(train_df)}")
print(f"Testing samples: {len(test_df)}")

# Convert to Hugging Face Dataset
train_dataset = Dataset.from_pandas(train_df[['review', 'label']])
test_dataset = Dataset.from_pandas(test_df[['review', 'label']])

print(f"\nSample data:")
print(train_dataset[0])
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: TOKENIZATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# LOAD TOKENIZER
# ============================================

model_name = "bert-base-uncased"

tokenizer = AutoTokenizer.from_pretrained(model_name)

print(f"Model: {model_name}")
print(f"Vocabulary size: {tokenizer.vocab_size}")

# Example tokenization
sample_text = "This movie was absolutely fantastic!"
tokens = tokenizer(sample_text, padding=True, truncation=True, return_tensors="pt")

print(f"\nSample tokenization:")
print(f"Text: {sample_text}")
print(f"Token IDs: {tokens['input_ids'][0].tolist()}")
print(f"Tokens: {tokenizer.convert_ids_to_tokens(tokens['input_ids'][0])}")
print(f"Attention Mask: {tokens['attention_mask'][0].tolist()}")

# ============================================
# TOKENIZE DATASET
# ============================================

def tokenize_function(examples):
    """Tokenize text with truncation and padding"""
    return tokenizer(
        examples['review'],
        padding='max_length',
        truncation=True,
        max_length=256
    )

# Apply tokenization
print("\nTokenizing datasets...")
train_dataset = train_dataset.map(tokenize_function, batched=True)
test_dataset = test_dataset.map(tokenize_function, batched=True)

# Set format for PyTorch
train_dataset.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label'])
test_dataset.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label'])

print(f"Tokenized training sample keys: {train_dataset[0].keys()}")
print(f"Input IDs shape: {train_dataset[0]['input_ids'].shape}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8: LOAD PRETRAINED MODEL
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# LOAD BERT MODEL
# ============================================

model = AutoModelForSequenceClassification.from_pretrained(
    model_name,
    num_labels=2  # Binary classification
)

print(f"\nModel architecture:")
print(model)

# Count parameters
total_params = sum(p.numel() for p in model.parameters())
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"\nTotal parameters: {total_params:,}")
print(f"Trainable parameters: {trainable_params:,}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 9: TRAINING CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# TRAINING ARGUMENTS
# ============================================

training_args = TrainingArguments(
    output_dir='./models/bert_sentiment',
    
    # Training hyperparameters
    num_train_epochs=3,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=32,
    
    # Optimizer settings
    learning_rate=2e-5,
    weight_decay=0.01,
    warmup_steps=500,
    
    # Logging
    logging_dir='./logs',
    logging_steps=100,
    
    # Evaluation
    evaluation_strategy='epoch',
    save_strategy='epoch',
    load_best_model_at_end=True,
    metric_for_best_model='accuracy',
    
    # Misc
    seed=42,
    push_to_hub=False
)

# ============================================
# METRICS FUNCTION
# ============================================

from sklearn.metrics import accuracy_score, precision_recall_fscore_support

def compute_metrics(pred):
    """Compute metrics for evaluation"""
    labels = pred.label_ids
    preds = pred.predictions.argmax(-1)
    
    precision, recall, f1, _ = precision_recall_fscore_support(
        labels, preds, average='binary'
    )
    acc = accuracy_score(labels, preds)
    
    return {
        'accuracy': acc,
        'f1': f1,
        'precision': precision,
        'recall': recall
    }
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 10: TRAIN BERT
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# CREATE TRAINER
# ============================================

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
    compute_metrics=compute_metrics
)

# ============================================
# TRAIN
# ============================================

print("\n" + "=" * 60)
print("STARTING BERT FINE-TUNING")
print("=" * 60)

trainer.train()

# ============================================
# EVALUATE
# ============================================

print("\n" + "=" * 60)
print("EVALUATION RESULTS")
print("=" * 60)

results = trainer.evaluate()

print(f"\nBERT Fine-tuned Results:")
print(f"  Accuracy:  {results['eval_accuracy']:.2%}")
print(f"  F1 Score:  {results['eval_f1']:.4f}")
print(f"  Precision: {results['eval_precision']:.4f}")
print(f"  Recall:    {results['eval_recall']:.4f}")

# ============================================
# SAVE MODEL
# ============================================

trainer.save_model('./models/bert_sentiment_final')
tokenizer.save_pretrained('./models/bert_sentiment_final')
print("\nModel saved to ./models/bert_sentiment_final")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11: DISTILBERT (FASTER ALTERNATIVE)
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# DISTILBERT - LIGHTER & FASTER
# ============================================

print("""
DISTILBERT ADVANTAGES:
- 40% smaller than BERT
- 60% faster than BERT
- Retains 97% of BERT's performance
- Great for production/deployment
""")

model_name_distil = "distilbert-base-uncased"

# Load tokenizer and model
tokenizer_distil = AutoTokenizer.from_pretrained(model_name_distil)
model_distil = AutoModelForSequenceClassification.from_pretrained(
    model_name_distil,
    num_labels=2
)

# Tokenize for DistilBERT
def tokenize_distil(examples):
    return tokenizer_distil(
        examples['review'],
        padding='max_length',
        truncation=True,
        max_length=256
    )

# Prepare datasets
train_distil = Dataset.from_pandas(train_df[['review', 'label']])
test_distil = Dataset.from_pandas(test_df[['review', 'label']])

train_distil = train_distil.map(tokenize_distil, batched=True)
test_distil = test_distil.map(tokenize_distil, batched=True)

train_distil.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label'])
test_distil.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label'])

# Training arguments (can use larger batch size)
training_args_distil = TrainingArguments(
    output_dir='./models/distilbert_sentiment',
    num_train_epochs=3,
    per_device_train_batch_size=32,  # Larger batch possible
    per_device_eval_batch_size=64,
    learning_rate=2e-5,
    warmup_steps=500,
    weight_decay=0.01,
    logging_steps=100,
    evaluation_strategy='epoch',
    save_strategy='epoch',
    load_best_model_at_end=True
)

# Create trainer
trainer_distil = Trainer(
    model=model_distil,
    args=training_args_distil,
    train_dataset=train_distil,
    eval_dataset=test_distil,
    compute_metrics=compute_metrics
)

# Train
print("\n" + "=" * 60)
print("STARTING DISTILBERT FINE-TUNING")
print("=" * 60)

trainer_distil.train()

# Evaluate
results_distil = trainer_distil.evaluate()

print(f"\nDistilBERT Results:")
print(f"  Accuracy:  {results_distil['eval_accuracy']:.2%}")
print(f"  F1 Score:  {results_distil['eval_f1']:.4f}")

# Save
trainer_distil.save_model('./models/distilbert_sentiment_final')
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 12: INFERENCE
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# INFERENCE WITH PIPELINE
# ============================================

print("\n" + "=" * 60)
print("INFERENCE EXAMPLES")
print("=" * 60)

# Load fine-tuned model with pipeline
sentiment_pipeline = pipeline(
    "sentiment-analysis",
    model='./models/bert_sentiment_final',
    tokenizer='./models/bert_sentiment_final'
)

# Test predictions
test_reviews = [
    "This movie was absolutely fantastic! Best film I've seen this year.",
    "Terrible waste of time. The plot made no sense.",
    "It was okay, nothing special but not bad either.",
    "Loved the acting and cinematography. Highly recommend!",
    "Boring and predictable. Save your money.",
    "A masterpiece of modern cinema. The director outdid himself.",
    "I fell asleep halfway through. So dull and lifeless."
]

for review in test_reviews:
    result = sentiment_pipeline(review)[0]
    label = "POSITIVE" if result['label'] == 'LABEL_1' else "NEGATIVE"
    confidence = result['score']
    
    print(f"\nReview: {review[:60]}...")
    print(f"Prediction: {label} (confidence: {confidence:.1%})")

# ============================================
# MANUAL INFERENCE
# ============================================

def predict_sentiment(text, model, tokenizer):
    """Manual prediction without pipeline"""
    # Tokenize
    inputs = tokenizer(
        text, 
        return_tensors='pt',
        padding=True,
        truncation=True,
        max_length=256
    )
    
    # Move to device
    inputs = {k: v.to(device) for k, v in inputs.items()}
    
    # Predict
    model.eval()
    with torch.no_grad():
        outputs = model(**inputs)
        predictions = torch.nn.functional.softmax(outputs.logits, dim=-1)
    
    # Get result
    pred_label = predictions.argmax().item()
    confidence = predictions[0][pred_label].item()
    
    return {
        'label': 'Positive' if pred_label == 1 else 'Negative',
        'confidence': confidence
    }

# Test manual inference
test_text = "This is an incredible movie with amazing performances!"
result = predict_sentiment(test_text, model, tokenizer)
print(f"\nManual inference:")
print(f"Text: {test_text}")
print(f"Result: {result}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 13: TRANSFORMER FROM SCRATCH (EDUCATIONAL)
# ═══════════════════════════════════════════════════════════════════════════════

```python
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# ============================================
# MULTI-HEAD ATTENTION LAYER
# ============================================

class MultiHeadAttention(layers.Layer):
    """Multi-Head Self-Attention"""
    
    def __init__(self, d_model, num_heads):
        super(MultiHeadAttention, self).__init__()
        self.num_heads = num_heads
        self.d_model = d_model
        
        assert d_model % num_heads == 0
        self.depth = d_model // num_heads
        
        self.wq = layers.Dense(d_model)
        self.wk = layers.Dense(d_model)
        self.wv = layers.Dense(d_model)
        self.wo = layers.Dense(d_model)
    
    def split_heads(self, x, batch_size):
        """Split into multiple heads"""
        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])
    
    def call(self, x, mask=None):
        batch_size = tf.shape(x)[0]
        
        # Linear projections
        q = self.wq(x)
        k = self.wk(x)
        v = self.wv(x)
        
        # Split heads
        q = self.split_heads(q, batch_size)
        k = self.split_heads(k, batch_size)
        v = self.split_heads(v, batch_size)
        
        # Scaled dot-product attention
        scaled_attention = self.scaled_dot_product_attention(q, k, v, mask)
        
        # Concat heads
        scaled_attention = tf.transpose(scaled_attention, perm=[0, 2, 1, 3])
        concat_attention = tf.reshape(scaled_attention, (batch_size, -1, self.d_model))
        
        # Final linear
        output = self.wo(concat_attention)
        return output
    
    def scaled_dot_product_attention(self, q, k, v, mask):
        matmul_qk = tf.matmul(q, k, transpose_b=True)
        
        dk = tf.cast(tf.shape(k)[-1], tf.float32)
        scaled = matmul_qk / tf.math.sqrt(dk)
        
        if mask is not None:
            scaled += (mask * -1e9)
        
        weights = tf.nn.softmax(scaled, axis=-1)
        return tf.matmul(weights, v)


# ============================================
# TRANSFORMER ENCODER BLOCK
# ============================================

class TransformerBlock(layers.Layer):
    """Single Transformer Encoder Block"""
    
    def __init__(self, d_model, num_heads, ff_dim, dropout=0.1):
        super(TransformerBlock, self).__init__()
        
        self.attention = MultiHeadAttention(d_model, num_heads)
        self.ffn = keras.Sequential([
            layers.Dense(ff_dim, activation='relu'),
            layers.Dense(d_model)
        ])
        
        self.layernorm1 = layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout1 = layers.Dropout(dropout)
        self.dropout2 = layers.Dropout(dropout)
    
    def call(self, inputs, training=False):
        # Self-attention
        attn_output = self.attention(inputs)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(inputs + attn_output)
        
        # Feed-forward
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output, training=training)
        return self.layernorm2(out1 + ffn_output)


# ============================================
# POSITIONAL EMBEDDING LAYER
# ============================================

class PositionalEmbedding(layers.Layer):
    """Token + Positional Embedding"""
    
    def __init__(self, max_len, vocab_size, d_model):
        super(PositionalEmbedding, self).__init__()
        self.token_emb = layers.Embedding(vocab_size, d_model)
        self.pos_emb = layers.Embedding(max_len, d_model)
    
    def call(self, x):
        max_len = tf.shape(x)[1]
        positions = tf.range(start=0, limit=max_len, delta=1)
        return self.token_emb(x) + self.pos_emb(positions)


# ============================================
# BUILD TRANSFORMER CLASSIFIER
# ============================================

def build_transformer_classifier(
    vocab_size, max_len, d_model=128, num_heads=4, 
    ff_dim=256, num_blocks=2
):
    """Build Transformer for text classification"""
    
    inputs = keras.Input(shape=(max_len,))
    
    # Embedding + Positional
    x = PositionalEmbedding(max_len, vocab_size, d_model)(inputs)
    
    # Transformer Blocks
    for _ in range(num_blocks):
        x = TransformerBlock(d_model, num_heads, ff_dim)(x)
    
    # Global Average Pooling
    x = layers.GlobalAveragePooling1D()(x)
    
    # Classification Head
    x = layers.Dense(64, activation='relu')(x)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(1, activation='sigmoid')(x)
    
    return keras.Model(inputs=inputs, outputs=outputs)

# Build model
vocab_size = 20000
max_length = 200

model_transformer = build_transformer_classifier(
    vocab_size=vocab_size,
    max_len=max_length,
    d_model=128,
    num_heads=4,
    ff_dim=256,
    num_blocks=2
)

model_transformer.summary()

print("\nTransformer from scratch built successfully!")
print("(Use pretrained BERT for better results)")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 14: MODEL COMPARISON
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# FINAL COMPARISON
# ============================================

print("\n" + "=" * 60)
print("TRANSFORMER MODELS COMPARISON")
print("=" * 60)

comparison = {
    'Transformer (scratch)': 0.86,
    'DistilBERT': results_distil['eval_accuracy'],
    'BERT': results['eval_accuracy']
}

for model_name, accuracy in sorted(comparison.items(), key=lambda x: x[1], reverse=True):
    print(f"{model_name}: {accuracy:.2%}")

# Plot
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 6))
models = list(comparison.keys())
accuracies = list(comparison.values())
colors = ['#3498db', '#2ecc71', '#e74c3c']

bars = plt.bar(models, accuracies, color=colors)
plt.ylabel('Accuracy')
plt.title('Transformer Models Comparison')
plt.ylim(0.8, 1.0)

for bar, acc in zip(bars, accuracies):
    plt.text(bar.get_x() + bar.get_width()/2, acc + 0.01, 
             f'{acc:.1%}', ha='center', fontsize=12, fontweight='bold')

plt.tight_layout()
plt.savefig('models/transformer_comparison.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 7 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ Transformer Architecture
   └── Encoder-Decoder structure
   └── No recurrence, no convolution
   └── Parallel processing (faster!)
   └── Self-attention + Feed-forward

✅ Multi-Head Attention
   └── Multiple attention heads
   └── Capture different relationships
   └── Concatenate and project

✅ Positional Encoding
   └── Sinusoidal encoding
   └── PE(pos, 2i) = sin(pos/10000^(2i/d))
   └── Added to embeddings

✅ BERT Understanding
   └── Encoder-only Transformer
   └── Pretrained with MLM + NSP
   └── [CLS] token for classification
   └── Fine-tune for downstream tasks

✅ BERT Fine-tuning
   └── Hugging Face Transformers library
   └── AutoTokenizer, AutoModel
   └── Trainer API
   └── ~93-94% accuracy!

✅ DistilBERT
   └── 40% smaller, 60% faster
   └── ~92% accuracy
   └── Great for deployment

✅ Transformer from Scratch
   └── Educational implementation
   └── Understanding all components
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY ACHIEVED - STATE OF THE ART! 🏆
# ═══════════════════════════════════════════════════════════════════════════════

```
📊 PHASE 7 RESULTS:

Model                          | Accuracy    | Speed
-------------------------------|-------------|--------
Transformer (scratch)          | ~85-88%     | Fast
DistilBERT                     | ~92%        | Very Fast
BERT Fine-tuned                | ~93-94%     | Moderate

📈 COMPLETE PROGRESS THROUGH ALL PHASES:
   Perceptron      → 65%
   MLP             → 75%
   CNN             → 82%
   Logistic Reg    → 85%
   XGBoost         → 88%
   BiLSTM          → 89%
   LSTM+Attention  → 91%
   BERT            → 94%  🏆 STATE OF THE ART!

🎉 CONGRATULATIONS! You've achieved state-of-the-art accuracy!

🚀 NEXT: PHASE 8 - NLP BASICS
   Now you understand WHY preprocessing matters for these models!
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# READY FOR PHASE 8: NLP BASICS
# ═══════════════════════════════════════════════════════════════════════════════

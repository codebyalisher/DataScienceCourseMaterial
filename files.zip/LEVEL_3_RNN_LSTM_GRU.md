# ═══════════════════════════════════════════════════════════════════════════════
# LEVEL 3: RECURRENT NEURAL NETWORKS (RNN FAMILY)
# Complete Verbatim Content from DataScienceCourseMaterial Repository
# ═══════════════════════════════════════════════════════════════════════════════

**Prerequisites:** Complete LEVEL 1 (Deep Learning Foundations) and LEVEL 2 (CNN)

**Why LEVEL 3 Now:** While CNN handles GRID data (images), RNN handles SEQUENTIAL data (text, time series). For NLP, understanding sequences is crucial. RNN introduces the concept of MEMORY - using previous outputs as current inputs.

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 1: WHY RNN?
# ═══════════════════════════════════════════════════════════════════════════════

**Why this is FIRST:** Before learning HOW RNN works, we need to understand WHY it exists. What problem does it solve that CNN/ANN cannot?

---

**RNN**: it is basically used when data is sequentially mean one after other like text i.e. i am alisher here sequential matter we cant change its input like in cnn or ann where any input given rnadomly,also in cnn and ann the inputs are fixed mean inputs cant be varied but when inputs varied like in text then we need other type of neural network which comes RNN.

---

## Why RNN is Needed:

### The Problem with CNN/ANN:

1. **Sequential Data**: Data that comes one after other (like text)
   - Example: "I am Alisher" - sequential order matters
   - We CAN'T change the input order like in CNN or ANN

2. **Fixed Input Size**: In CNN and ANN, inputs are FIXED
   - But text can vary in length
   - "Hello" vs "Hello, how are you doing today?"

3. **Issues with traditional approaches**:
   - Input size → varying
   - Zero padding → unnecessary computation
   - Prediction problem if someone enters less text
   - Totally disregarding the sequential information and this is the biggest issue

---

## The Biggest Issue:

**"Totally disregarding the sequential information"**

- In ANN/CNN: Each input is processed independently
- No memory of what came before
- But in language: "I love you" vs "You love I" - ORDER MATTERS!

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 2: RNN VS ANN
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** Now we understand WHY RNN exists. Let's see HOW it differs from ANN architecturally.

---

**RNN vs ANN**: ANN is feed forward while RNN sends feed backward to the hidden state.

In RNN basically the data or one input is given at a time basis and then rest one by one.

---

## Key Difference:

| Aspect | ANN | RNN |
|--------|-----|-----|
| **Data Flow** | Feed FORWARD only | Feed BACKWARD to hidden state |
| **Input Processing** | All inputs at once | One input at a time |
| **Memory** | No memory | Has memory (hidden state) |
| **Sequential Info** | Ignored | Preserved |

---

## Visual Understanding:

**ANN (Feed Forward):**
```
Input → Hidden → Output
(no connection back)
```

**RNN (Recurrent):**
```
Input → Hidden → Output
           ↑______|
    (hidden state fed back)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 3: INTERNAL WORKING OF RNN
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** After understanding the difference, we need to know exactly HOW RNN processes data internally.

---

In RNN architecture working internally like the vocabulary is converted into vectors and then those vectors are passed to the input layer where inputs are multiplied with the weights+bias and passed to the activation function which is default tanh since the vectors are 1 and 0 values.

In first time or loop we pass the random output along with the weights as input to this layer and in next time or loop the xi*w + o1*wh + bias to the tanh function and get the output and same process will be repeated.

---

## Detailed Internal Working:

In a Recurrent Neural Network (RNN) architecture, the process begins with converting the input vocabulary—typically words or characters—into numerical vectors, often through techniques like one-hot encoding or word embeddings. These vectors are then passed to the input layer of the RNN. At each time step, the input vector is multiplied with a set of input weights, and a bias term is added. The result is then combined with the hidden state from the previous time step, which has also been multiplied by a separate set of weights. This combined value is passed through an activation function, usually the hyperbolic tangent (tanh), which introduces non-linearity and allows the network to learn complex patterns. During the first time step, the hidden state is typically initialized randomly or set to zero. In subsequent steps, the output (hidden state) from the previous time step is fed back into the network, enabling it to maintain memory of past inputs. This process repeats for each element in the input sequence, allowing the RNN to capture temporal dependencies and contextual information across time.

---

## Step-by-Step Process:

### Step 1: Convert Vocabulary to Vectors
- Words/characters → numerical vectors
- Using: one-hot encoding OR word embeddings

### Step 2: First Time Step (t=1)
- Input vector × input weights + bias
- Hidden state initialized randomly or zero
- Pass through tanh activation
- Get output

### Step 3: Subsequent Time Steps (t=2, 3, ...)
```
Formula: tanh(xi * w + o(t-1) * wh + bias)
```
Where:
- `xi` = current input
- `w` = input weights
- `o(t-1)` = previous output (hidden state)
- `wh` = hidden state weights
- `bias` = bias term

### Step 4: Repeat
- Same process for each element in sequence
- Hidden state carries memory of past inputs

---

## Why tanh?
- Vectors are 1 and 0 values
- tanh outputs between -1 and 1
- Introduces non-linearity
- Allows learning complex patterns

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 4: RNN ARCHITECTURES (INPUT-OUTPUT CONFIGURATIONS)
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** RNN can be configured in different ways depending on the task. Understanding these configurations is crucial for choosing the right one.

---

Recurrent Neural Networks (RNNs) can be structured in various input-output configurations based on the type of sequence data being processed:

1. **One-to-One**: Traditional feedforward neural network where a single input maps to a single output, typically used in basic classification tasks.

2. **One-to-Many**: Takes a single input and generates a sequence of outputs, suitable for tasks like image captioning where one image input yields a sentence.

3. **Many-to-One**: Processes a sequence of inputs to produce a single output—for example, in sentiment analysis, where an entire sentence (sequence of words) leads to one prediction (positive or negative sentiment).

4. **Many-to-Many**: Comes in two forms:
   - **Synchronized**: Input and output sequences are of the same length (like in video frame labeling)
   - **Asynchronous**: Input and output lengths differ, as in machine translation, where a sentence in one language is translated into another

These architectures leverage the RNN's ability to maintain context across time steps, enabling it to handle diverse sequence-based tasks effectively.

---

## Summary Table:

| Architecture | Input | Output | Example Use Case |
|--------------|-------|--------|------------------|
| **One-to-One** | Single | Single | Basic classification |
| **One-to-Many** | Single | Sequence | Image captioning |
| **Many-to-One** | Sequence | Single | Sentiment analysis |
| **Many-to-Many (Sync)** | Sequence | Same length sequence | Video frame labeling |
| **Many-to-Many (Async)** | Sequence | Different length sequence | Machine translation |

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 5: STEPS FOR IMPLEMENTATION OF RNN
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** Now we know the theory. Let's understand the practical implementation steps.

---

**Steps for implemntation of the RNN**: Just like the one hot endocoding techniques the embeding is also encoding techniques which have lot of benefits

Here's a concise summary of all the key techniques used in implementing an RNN for NLP tasks:

To implement an RNN for natural language processing, the process begins with **tokenization**, where raw text is converted into sequences of integers, followed by **padding** to ensure uniform sequence length. These sequences are passed through an **embedding layer**, which maps tokens to dense vector representations—either learned during training or loaded from pre-trained embeddings like Word2Vec or GloVe.

Optionally, a **masking layer** is applied to ignore padded tokens. The core of the model is the **RNN layer**, which can be a simple RNN, LSTM, or GRU, each designed to handle sequential data with varying capabilities for capturing long-term dependencies.

To improve generalization, **dropout** and **recurrent dropout** can be applied within the RNN. For richer context understanding, a **bidirectional RNN** can be used to process the sequence in both forward and backward directions.

More advanced models may include **attention mechanisms**, which help the network focus on relevant parts of the input, or **stacked RNNs** with multiple recurrent layers for deeper learning.

The output from the recurrent layers typically passes through one or more **dense layers**, and finally to an **output layer** with an activation function like sigmoid or softmax, depending on the task (e.g., binary or multi-class classification).

Together, these components form a powerful and flexible architecture for modeling sequential data.

---

## Implementation Steps Summary:

| Step | Technique | Purpose |
|------|-----------|---------|
| 1 | **Tokenization** | Raw text → sequences of integers |
| 2 | **Padding** | Ensure uniform sequence length |
| 3 | **Embedding Layer** | Tokens → dense vectors (learned or pre-trained) |
| 4 | **Masking Layer** (optional) | Ignore padded tokens |
| 5 | **RNN Layer** | Simple RNN, LSTM, or GRU |
| 6 | **Dropout/Recurrent Dropout** | Improve generalization |
| 7 | **Bidirectional RNN** (optional) | Process forward AND backward |
| 8 | **Attention Mechanism** (optional) | Focus on relevant parts |
| 9 | **Stacked RNNs** (optional) | Multiple recurrent layers |
| 10 | **Dense Layers** | After recurrent layers |
| 11 | **Output Layer** | Sigmoid (binary) or Softmax (multiclass) |

---

## Key Note on Embedding:

**"Just like the one hot encoding techniques the embedding is also encoding techniques which have lot of benefits"**

| One-Hot Encoding | Embedding |
|------------------|-----------|
| Sparse (mostly zeros) | Dense (all values meaningful) |
| High dimensional | Lower dimensional |
| No semantic meaning | Captures semantic meaning |
| Fixed | Learned during training |

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 6: RNN VS LSTM
# ═══════════════════════════════════════════════════════════════════════════════

**Why LSTM comes after RNN:** Standard RNNs have a critical flaw - VANISHING GRADIENTS. They forget long-term information. LSTM was invented specifically to solve this problem.

---

The key difference between a standard Recurrent Neural Network (RNN) and a Long Short-Term Memory (LSTM) network lies in how they handle memory over time.

Traditional RNNs are designed to process sequences by passing hidden states from one time step to the next, allowing the model to retain some information from the past. However, **RNNs struggle with learning long-term dependencies** due to issues like **vanishing gradients**, which make it difficult for the network to retain relevant information over many time steps.

LSTM networks were introduced to address this problem by incorporating a more advanced memory structure. Instead of relying solely on a single hidden state, LSTMs use two components:
- **Cell state**: Which acts as long-term memory
- **Hidden state**: Which captures short-term information

To manage what information to keep, update, or discard, LSTMs use **three special gates**:
1. **Forget gate**
2. **Input gate**
3. **Output gate**

Each of which is controlled by the current input and previous hidden state.

These gates allow the LSTM to selectively remember important data over long sequences and forget irrelevant information, making it much more effective than a basic RNN for tasks involving long-range context, such as language modeling, translation, or time series forecasting.

---

## LSTM Components:

### Two Memory Components:
1. **Cell State (ct)**: Long-term memory
2. **Hidden State (st/ht)**: Short-term memory

### Three Gates:
1. **Forget Gate**: What to FORGET from previous state
2. **Input Gate**: What NEW information to ADD
3. **Output Gate**: What to OUTPUT

---

## LSTM Internal Working:

**Three inputs**: cell state ct and hidden state st and xt input

**Two things happen in node**: update and create hidden state

**Two outputs**: ct and ht

In each gate there is bitwise operation either to stop or passing the 50% or full information to move along the cell state.

---

## Gate Operations:

| Gate Value | Meaning |
|------------|---------|
| 0 | STOP all information |
| 0.5 | Pass 50% of information |
| 1 | Pass FULL information |

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 7: GRU (GATED RECURRENT UNIT)
# ═══════════════════════════════════════════════════════════════════════════════

**Why GRU comes after LSTM:** GRU is a SIMPLIFIED version of LSTM. It has fewer parameters (2 gates instead of 3) but achieves similar performance. Understanding LSTM first helps appreciate GRU's simplification.

---

## GRU vs LSTM:

GRU has **two gates** instead of three:
1. **Reset gate**
2. **Update gate**

It combines the forget and input gates into a single update gate and merges the cell state and hidden state.

---

## RNN vs LSTM vs GRU Comparison Table:

| Feature | RNN | LSTM | GRU |
|---------|-----|------|-----|
| **Gates** | 0 | 3 (forget, input, output) | 2 (reset, update) |
| **Memory** | Hidden state only | Cell state + Hidden state | Hidden state |
| **Long-term dependencies** | Poor | Excellent | Good |
| **Computational cost** | Low | High | Medium |
| **Parameters** | Few | Many | Moderate |
| **Training speed** | Fast | Slow | Medium |
| **Use case** | Short sequences | Long sequences, complex patterns | Medium sequences, efficiency needed |

---

## When to Use What:

- **RNN**: Short sequences, simple patterns
- **LSTM**: Long sequences, complex patterns, need best accuracy
- **GRU**: Medium sequences, need balance of speed and accuracy

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 8: STACKED RNNs, LSTMs, AND GRUs
# ═══════════════════════════════════════════════════════════════════════════════

**Why Stacked comes here:** After understanding basic RNN, LSTM, GRU, we can now STACK them for deeper learning.

---

**Deep RNNs, stacked RNNs, stacked LSTMs, and stacked GRUs**

**Stacked LSTMs** are a layered version of LSTM networks where multiple LSTM layers are stacked together. Each LSTM layer receives the sequence of hidden states from the LSTM layer below it instead of just from the input sequence directly. So, for each time step t, the current input xt goes through the first LSTM layer, and its output becomes the input for the next LSTM layer, and this continues for however many layers are stacked. This setup allows the model to learn very deep sequence patterns, with the lower layers handling short-term dependencies and the upper layers capturing more long-term relationships. The gates in each layer (input, forget, and output gates) operate independently but help refine the representation of the sequence as it moves deeper through the layers.

**Stacked GRUs** follow the same concept as stacked LSTMs, but instead of using LSTM cells, they use GRU cells. Multiple GRU layers are placed one on top of another, and each layer processes the sequence of hidden states from the layer below. At each time step, the current input is first passed through the bottom GRU layer, and then its output becomes the input for the next GRU layer in the stack. Just like LSTMs, each GRU layer uses reset and update gates to control information flow, but since GRUs are simpler with fewer gates, stacked GRUs tend to be lighter and faster to train while still learning complex sequence patterns across different levels in the stack.

---

## Stacked Architecture:

```
Input Sequence
      ↓
[LSTM/GRU Layer 1] → handles short-term dependencies
      ↓
[LSTM/GRU Layer 2] → captures medium-term patterns
      ↓
[LSTM/GRU Layer 3] → captures long-term relationships
      ↓
Output
```

---

## Key Points:

| Aspect | Stacked LSTM | Stacked GRU |
|--------|--------------|-------------|
| **Concept** | Multiple LSTM layers stacked | Multiple GRU layers stacked |
| **Input** | Hidden states from layer below | Hidden states from layer below |
| **Gates** | 3 gates per layer (independent) | 2 gates per layer |
| **Lower layers** | Short-term dependencies | Short-term dependencies |
| **Upper layers** | Long-term relationships | Long-term relationships |
| **Speed** | Slower | Faster |
| **Complexity** | Higher | Lower |

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 9: BIDIRECTIONAL (RNN, LSTM, GRU)
# ═══════════════════════════════════════════════════════════════════════════════

**Why Bidirectional comes here:** Sometimes understanding a word requires knowing what comes AFTER it, not just before. Bidirectional processes both directions.

---

**Bidrectional (RNN,LSTM,GRU)**: Process the sequence in BOTH forward and backward directions, capturing context from both past and future positions.

This is particularly useful for tasks where the meaning of a word depends on both what came before AND what comes after it.

---

## How Bidirectional Works:

```
Forward RNN:  → → → → → →
              H e l l o !
Backward RNN: ← ← ← ← ← ←

Combined output = Forward + Backward
```

---

## Benefits:

1. **Captures both past and future context**
2. **Better understanding of word meaning**
3. **Useful for**: NER, POS tagging, translation, sentiment analysis

---

## Example:

Sentence: "The bank by the river was beautiful"

- Forward only: "bank" could be financial bank
- Bidirectional: "river" comes after → "bank" means riverbank

---

# ═══════════════════════════════════════════════════════════════════════════════
# LEARNING SEQUENCE FOR LEVEL 3
# ═══════════════════════════════════════════════════════════════════════════════

```
LEVEL 3: RECURRENT NEURAL NETWORKS (RNN FAMILY)
════════════════════════════════════════════════

Section 1:  Why RNN? (the problem with ANN/CNN for sequences)
                ↓
Section 2:  RNN vs ANN (architectural difference)
                ↓
Section 3:  Internal Working of RNN (step-by-step process)
                ↓
Section 4:  RNN Architectures (one-to-one, one-to-many, etc.)
                ↓
Section 5:  Implementation Steps (tokenization to output)
                ↓
Section 6:  RNN vs LSTM (vanishing gradient solution)
                ↓
Section 7:  GRU (simplified LSTM)
                ↓
Section 8:  Stacked RNNs/LSTMs/GRUs (deeper learning)
                ↓
Section 9:  Bidirectional (forward + backward)

════════════════════════════════════════════════
LEVEL 3 COMPLETE - READY FOR LEVEL 4 (Seq2Seq & Attention)
════════════════════════════════════════════════
```

---

*This is LEVEL 3 containing ALL verbatim content from the repository for RNN Family. Each concept builds on previous levels and prepares for LEVEL 4 (Seq2Seq & Attention).*

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 8: NLP BASICS
# Movie Review Sentiment Analyzer - Implementation Guide
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Now that you understand deep learning models, learn WHY text preprocessing matters.

## 📚 CONCEPTS COVERED (FROM REPO)
- NLP Introduction
- NLP Pipelines (5 Steps)
- Preprocessing (11 Steps)

## 🔄 WHY THIS COMES AFTER DEEP LEARNING?
You now understand HOW models process text. This phase teaches you HOW to 
prepare text optimally for those models.

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: NLP INTRODUCTION (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
NLP INTRODUCTION (from repository)
═══════════════════════════════════════════════════════════════════════════════

NLP = Natural Language Processing
"Making machines understand human language"

KEY CHALLENGES:
1. Ambiguity: "Bank" = financial institution OR river side?
2. Context: "It was cool" = temperature OR awesome?
3. Sarcasm: "Oh great, another delay" = negative, not positive
4. Slang: "That's lit" = good (not on fire)
5. Languages: Grammar rules differ across languages

NLP APPLICATIONS:
- Sentiment Analysis (our project!)
- Machine Translation
- Chatbots / Virtual Assistants
- Text Summarization
- Named Entity Recognition
- Question Answering
- Speech Recognition

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: NLP PIPELINE (FROM REPO - 5 STEPS)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
NLP PIPELINE - 5 STEPS (from repository)
═══════════════════════════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   STEP 1: DATA ACQUISITION                                                  │
│   ─────────────────────────                                                 │
│   • Web scraping                                                            │
│   • APIs (Twitter, Reddit)                                                  │
│   • Public datasets (Kaggle, IMDB)                                          │
│   • Company data                                                            │
│                                                                             │
│   STEP 2: TEXT PREPARATION / PREPROCESSING                                  │
│   ──────────────────────────────────────────                                │
│   • Cleaning (remove HTML, URLs, special chars)                             │
│   • Normalization (lowercase, stemming, lemmatization)                      │
│   • Tokenization (split into words)                                         │
│   • Stop word removal                                                       │
│                                                                             │
│   STEP 3: FEATURE ENGINEERING                                               │
│   ─────────────────────────────                                             │
│   • Bag of Words (BoW)                                                      │
│   • TF-IDF                                                                  │
│   • Word Embeddings (Word2Vec, GloVe)                                       │
│   • Custom features (text length, sentiment lexicons)                       │
│                                                                             │
│   STEP 4: MODELING                                                          │
│   ────────────────────                                                      │
│   • Traditional ML (Logistic Regression, SVM, Random Forest)                │
│   • Deep Learning (LSTM, CNN, Transformers)                                 │
│   • Pretrained models (BERT, GPT)                                           │
│                                                                             │
│   STEP 5: DEPLOYMENT                                                        │
│   ────────────────────                                                      │
│   • REST API (Flask, FastAPI)                                               │
│   • Cloud deployment (Heroku, AWS, GCP)                                     │
│   • Monitoring and updates                                                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: PREPROCESSING - 11 STEPS (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
import re
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer

# Download NLTK data
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

print("""
═══════════════════════════════════════════════════════════════════════════════
11 PREPROCESSING STEPS (from repository)
═══════════════════════════════════════════════════════════════════════════════
""")

# Sample text with various issues
sample_text = """
<html>AMAZING Movie!!! 🎬 Check it out at https://example.com/movie
The acting was gr8 & the plot was FANTASTIC... I luv it sooo much!!
I'm gonna watch it 2morrow with my frends. Can't wait! :) #BestMovie
"""

print(f"ORIGINAL TEXT:\n{sample_text}")
print("=" * 60)

# ============================================
# STEP 1: LOWERCASING
# ============================================
def step1_lowercase(text):
    """Convert all text to lowercase"""
    return text.lower()

text = step1_lowercase(sample_text)
print(f"\n1. LOWERCASING:\n{text}")

# ============================================
# STEP 2: REMOVE HTML TAGS
# ============================================
def step2_remove_html(text):
    """Remove HTML tags using regex"""
    html_pattern = re.compile(r'<[^>]+>')
    return html_pattern.sub('', text)

text = step2_remove_html(text)
print(f"\n2. REMOVE HTML:\n{text}")

# ============================================
# STEP 3: REMOVE URLs
# ============================================
def step3_remove_urls(text):
    """Remove URLs using regex"""
    url_pattern = re.compile(r'https?://\S+|www\.\S+')
    return url_pattern.sub('', text)

text = step3_remove_urls(text)
print(f"\n3. REMOVE URLs:\n{text}")

# ============================================
# STEP 4: REMOVE PUNCTUATION
# ============================================
def step4_remove_punctuation(text):
    """Remove punctuation marks"""
    # Keep only letters, numbers, and spaces
    return re.sub(r'[^\w\s]', '', text)

text = step4_remove_punctuation(text)
print(f"\n4. REMOVE PUNCTUATION:\n{text}")

# ============================================
# STEP 5: CHAT WORD TREATMENT
# ============================================
def step5_expand_chat_words(text):
    """Expand chat abbreviations"""
    chat_words = {
        'gr8': 'great',
        'luv': 'love',
        'u': 'you',
        '2morrow': 'tomorrow',
        'frends': 'friends',
        'gonna': 'going to',
        'cant': 'cannot',
        'sooo': 'so',
        'im': 'i am',
        'dont': 'do not',
        'wont': 'will not',
        'thx': 'thanks',
        'pls': 'please',
        'b4': 'before',
        'bcoz': 'because',
        'omg': 'oh my god',
        'lol': 'laughing out loud',
        'brb': 'be right back',
        'btw': 'by the way'
    }
    
    words = text.split()
    expanded = [chat_words.get(word, word) for word in words]
    return ' '.join(expanded)

text = step5_expand_chat_words(text)
print(f"\n5. EXPAND CHAT WORDS:\n{text}")

# ============================================
# STEP 6: SPELLING CORRECTION
# ============================================
def step6_spelling_correction(text):
    """Correct spelling (using TextBlob)"""
    # Note: In production, use TextBlob or pyspellchecker
    # from textblob import TextBlob
    # return str(TextBlob(text).correct())
    
    # Simple example corrections
    corrections = {
        'teh': 'the',
        'recieve': 'receive',
        'definately': 'definitely'
    }
    
    words = text.split()
    corrected = [corrections.get(word, word) for word in words]
    return ' '.join(corrected)

text = step6_spelling_correction(text)
print(f"\n6. SPELLING CORRECTION:\n{text}")

# ============================================
# STEP 7: REMOVE STOP WORDS
# ============================================
def step7_remove_stopwords(text):
    """Remove common stop words"""
    stop_words = set(stopwords.words('english'))
    words = text.split()
    filtered = [word for word in words if word not in stop_words]
    return ' '.join(filtered)

text = step7_remove_stopwords(text)
print(f"\n7. REMOVE STOP WORDS:\n{text}")

# ============================================
# STEP 8: HANDLE EMOJIS
# ============================================
def step8_handle_emojis(text, mode='remove'):
    """Handle emojis - remove or convert to text"""
    # Emoji to text mapping
    emoji_dict = {
        '🎬': 'movie',
        '😊': 'happy',
        '😢': 'sad',
        '❤️': 'love',
        '👍': 'thumbs up',
        '👎': 'thumbs down',
        '🔥': 'fire',
        '💯': 'hundred'
    }
    
    if mode == 'convert':
        for emoji, word in emoji_dict.items():
            text = text.replace(emoji, word)
    
    # Remove any remaining emojis
    emoji_pattern = re.compile("["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map
        u"\U0001F1E0-\U0001F1FF"  # flags
        "]+", flags=re.UNICODE)
    
    return emoji_pattern.sub('', text)

text = step8_handle_emojis(text, mode='convert')
print(f"\n8. HANDLE EMOJIS:\n{text}")

# ============================================
# STEP 9: TOKENIZATION
# ============================================
def step9_tokenize(text):
    """Split text into individual tokens (words)"""
    return word_tokenize(text)

tokens = step9_tokenize(text)
print(f"\n9. TOKENIZATION:\n{tokens}")

# ============================================
# STEP 10: STEMMING
# ============================================
def step10_stemming(tokens):
    """
    Reduce words to their root form (rule-based)
    
    From repo: "Stemming is RULE-BASED and may not result in real words"
    Example: "running" -> "run", "studies" -> "studi" (not a word!)
    """
    stemmer = PorterStemmer()
    return [stemmer.stem(token) for token in tokens]

stemmed = step10_stemming(tokens)
print(f"\n10. STEMMING:\n{stemmed}")

# ============================================
# STEP 11: LEMMATIZATION
# ============================================
def step11_lemmatization(tokens):
    """
    Reduce words to their dictionary form (dictionary-based)
    
    From repo: "Lemmatization is DICTIONARY-BASED and always results in real words"
    Example: "running" -> "run", "studies" -> "study" (real word!)
    """
    lemmatizer = WordNetLemmatizer()
    return [lemmatizer.lemmatize(token) for token in tokens]

lemmatized = step11_lemmatization(tokens)
print(f"\n11. LEMMATIZATION:\n{lemmatized}")

# ============================================
# STEMMING VS LEMMATIZATION
# ============================================
print("""
═══════════════════════════════════════════════════════════════════════════════
STEMMING VS LEMMATIZATION (from repository)
═══════════════════════════════════════════════════════════════════════════════

┌────────────────┬─────────────────────────────────────────────────────────────┐
│ Aspect         │ Stemming              │ Lemmatization                       │
├────────────────┼───────────────────────┼─────────────────────────────────────┤
│ Method         │ RULE-BASED            │ DICTIONARY-BASED                    │
│ Output         │ May NOT be real word  │ ALWAYS real word                    │
│ Speed          │ Faster                │ Slower                              │
│ Example        │ "studies" → "studi"   │ "studies" → "study"                 │
│ Example        │ "caring" → "car"      │ "caring" → "care"                   │
└────────────────┴───────────────────────┴─────────────────────────────────────┘

WHEN TO USE:
- Stemming: When speed matters, search engines
- Lemmatization: When accuracy matters, NLP tasks

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: COMPLETE PREPROCESSING PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# COMPLETE PREPROCESSING FUNCTION
# ============================================

class TextPreprocessor:
    """Complete text preprocessing pipeline"""
    
    def __init__(self, 
                 lowercase=True,
                 remove_html=True,
                 remove_urls=True,
                 remove_punctuation=True,
                 expand_chat=True,
                 remove_stopwords=True,
                 handle_emojis='remove',
                 normalize='lemmatize'):
        
        self.lowercase = lowercase
        self.remove_html = remove_html
        self.remove_urls = remove_urls
        self.remove_punctuation = remove_punctuation
        self.expand_chat = expand_chat
        self.remove_stopwords = remove_stopwords
        self.handle_emojis = handle_emojis
        self.normalize = normalize
        
        # Initialize tools
        self.stop_words = set(stopwords.words('english'))
        self.stemmer = PorterStemmer()
        self.lemmatizer = WordNetLemmatizer()
        
        # Chat words dictionary
        self.chat_words = {
            'gr8': 'great', 'luv': 'love', 'u': 'you',
            '2morrow': 'tomorrow', 'gonna': 'going to',
            'cant': 'cannot', 'dont': 'do not',
            'im': 'i am', 'thx': 'thanks', 'pls': 'please'
        }
    
    def preprocess(self, text):
        """Apply all preprocessing steps"""
        
        # 1. Lowercase
        if self.lowercase:
            text = text.lower()
        
        # 2. Remove HTML
        if self.remove_html:
            text = re.sub(r'<[^>]+>', '', text)
        
        # 3. Remove URLs
        if self.remove_urls:
            text = re.sub(r'https?://\S+|www\.\S+', '', text)
        
        # 4. Remove punctuation
        if self.remove_punctuation:
            text = re.sub(r'[^\w\s]', '', text)
        
        # 5. Expand chat words
        if self.expand_chat:
            words = text.split()
            words = [self.chat_words.get(w, w) for w in words]
            text = ' '.join(words)
        
        # 6. Handle emojis
        if self.handle_emojis == 'remove':
            emoji_pattern = re.compile("["
                u"\U0001F600-\U0001F64F"
                u"\U0001F300-\U0001F5FF"
                u"\U0001F680-\U0001F6FF"
                u"\U0001F1E0-\U0001F1FF"
                "]+", flags=re.UNICODE)
            text = emoji_pattern.sub('', text)
        
        # 7. Tokenize
        tokens = text.split()
        
        # 8. Remove stopwords
        if self.remove_stopwords:
            tokens = [t for t in tokens if t not in self.stop_words]
        
        # 9. Normalize (stem or lemmatize)
        if self.normalize == 'stem':
            tokens = [self.stemmer.stem(t) for t in tokens]
        elif self.normalize == 'lemmatize':
            tokens = [self.lemmatizer.lemmatize(t) for t in tokens]
        
        return ' '.join(tokens)
    
    def preprocess_batch(self, texts):
        """Preprocess multiple texts"""
        return [self.preprocess(text) for text in texts]


# ============================================
# USAGE EXAMPLE
# ============================================

# Initialize preprocessor
preprocessor = TextPreprocessor(
    lowercase=True,
    remove_html=True,
    remove_urls=True,
    remove_punctuation=True,
    expand_chat=True,
    remove_stopwords=True,
    handle_emojis='remove',
    normalize='lemmatize'
)

# Test
sample = "<p>OMG!!! This movie is gr8! 🎬 Check https://example.com</p>"
processed = preprocessor.preprocess(sample)
print(f"Original: {sample}")
print(f"Processed: {processed}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: APPLY TO IMDB DATASET
# ═══════════════════════════════════════════════════════════════════════════════

```python
import pandas as pd

# Load data
train_df = pd.read_csv('data/processed/train.csv')

# Initialize preprocessor
preprocessor = TextPreprocessor(
    lowercase=True,
    remove_html=True,
    remove_urls=True,
    remove_punctuation=True,
    expand_chat=False,  # IMDB doesn't have much chat language
    remove_stopwords=False,  # For deep learning, keep stopwords
    handle_emojis='remove',
    normalize=None  # For BERT, don't stem/lemmatize
)

# Apply preprocessing
print("Preprocessing IMDB reviews...")
train_df['processed_review'] = train_df['review'].apply(preprocessor.preprocess)

# Compare
print("\nOriginal:")
print(train_df['review'].iloc[0][:200])
print("\nProcessed:")
print(train_df['processed_review'].iloc[0][:200])

# Save
train_df.to_csv('data/processed/train_preprocessed.csv', index=False)
print("\nPreprocessed data saved!")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: PREPROCESSING IMPACT ON MODELS
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
PREPROCESSING IMPACT ON DIFFERENT MODELS
═══════════════════════════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────────────────────────┐
│ Model Type        │ Recommended Preprocessing                              │
├───────────────────┼────────────────────────────────────────────────────────┤
│ Bag of Words /    │ Full preprocessing:                                    │
│ TF-IDF            │ - Lowercase ✓                                          │
│                   │ - Remove HTML, URLs ✓                                  │
│                   │ - Remove stopwords ✓                                   │
│                   │ - Stemming/Lemmatization ✓                             │
├───────────────────┼────────────────────────────────────────────────────────┤
│ LSTM / RNN        │ Moderate preprocessing:                                │
│                   │ - Lowercase ✓                                          │
│                   │ - Remove HTML, URLs ✓                                  │
│                   │ - Keep stopwords (they carry sequence info)            │
│                   │ - No stemming (embeddings need full words)             │
├───────────────────┼────────────────────────────────────────────────────────┤
│ BERT /            │ Minimal preprocessing:                                 │
│ Transformers      │ - Keep original case (BERT handles it)                 │
│                   │ - Remove HTML, URLs ✓                                  │
│                   │ - Keep stopwords ✓                                     │
│                   │ - No stemming ✓ (BERT has its own tokenizer)           │
│                   │ - BERT tokenizer does subword splitting                │
└───────────────────┴────────────────────────────────────────────────────────┘

KEY INSIGHT:
- Traditional ML: More preprocessing = better
- Deep Learning: Less preprocessing = better (model learns patterns)
- Transformers: Minimal preprocessing (pretrained tokenizers)

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 8 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ NLP Introduction
   └── Challenges: Ambiguity, context, sarcasm
   └── Applications: Sentiment, translation, chatbots

✅ NLP Pipeline (5 Steps)
   └── Data Acquisition
   └── Text Preparation
   └── Feature Engineering
   └── Modeling
   └── Deployment

✅ Preprocessing (11 Steps)
   └── 1. Lowercasing
   └── 2. Remove HTML tags
   └── 3. Remove URLs
   └── 4. Remove punctuation
   └── 5. Chat word treatment
   └── 6. Spelling correction
   └── 7. Remove stop words
   └── 8. Handle emojis
   └── 9. Tokenization
   └── 10. Stemming
   └── 11. Lemmatization

✅ Stemming vs Lemmatization
   └── Stemming: Rule-based, may not be real word
   └── Lemmatization: Dictionary-based, always real word

✅ Preprocessing for Different Models
   └── Traditional ML: Full preprocessing
   └── Deep Learning: Moderate preprocessing
   └── Transformers: Minimal preprocessing
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# NEXT: PHASE 9 - TEXT REPRESENTATION
# ═══════════════════════════════════════════════════════════════════════════════

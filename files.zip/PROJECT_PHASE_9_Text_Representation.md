# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 9: TEXT REPRESENTATION
# Movie Review Sentiment Analyzer - Implementation Guide
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Learn different ways to convert text into numerical vectors for machine learning.

## 📚 CONCEPTS COVERED (FROM REPO)
- Bag of Words (BoW)
- N-grams
- TF-IDF
- Word2Vec (CBOW, Skip-gram)
- POS Tagging (HMM, Viterbi)

## 📊 EXPECTED ACCURACY WITH THESE REPRESENTATIONS
- BoW + LogReg: ~82-85%
- TF-IDF + LogReg: ~85-87%
- Word2Vec + LogReg: ~86-88%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: BAG OF WORDS (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
BAG OF WORDS (from repository)
═══════════════════════════════════════════════════════════════════════════════

"Bag of Words creates WORD FREQUENCY vectors for each document"

CHARACTERISTICS:
- High-dimensional (vocabulary size)
- Sparse (mostly zeros)
- No semantic meaning (similar words treated differently)
- Ignores word order

EXAMPLE:
Doc 1: "I love this movie"
Doc 2: "I hate this movie"

Vocabulary: [I, love, hate, this, movie]

BoW Vectors:
Doc 1: [1, 1, 0, 1, 1]
Doc 2: [1, 0, 1, 1, 1]

PROBLEM:
- "love" and "hate" are opposites but have same weight (1)
- "movie" and "film" are similar but treated as different

═══════════════════════════════════════════════════════════════════════════════
""")

from sklearn.feature_extraction.text import CountVectorizer
import pandas as pd
import numpy as np

# Sample documents
documents = [
    "I love this movie it is great",
    "I hate this movie it is terrible",
    "This movie is amazing and wonderful",
    "This movie is boring and awful"
]

# Create BoW vectorizer
bow_vectorizer = CountVectorizer()
bow_matrix = bow_vectorizer.fit_transform(documents)

# Display
feature_names = bow_vectorizer.get_feature_names_out()
bow_df = pd.DataFrame(bow_matrix.toarray(), columns=feature_names)
print("Bag of Words Matrix:")
print(bow_df)
print(f"\nVocabulary size: {len(feature_names)}")
print(f"Matrix shape: {bow_matrix.shape}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: N-GRAMS (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
N-GRAMS (from repository)
═══════════════════════════════════════════════════════════════════════════════

"N-grams are CONTIGUOUS SEQUENCES of n items from text"

TYPES:
- Unigrams (n=1): Individual words ["I", "love", "this"]
- Bigrams (n=2): Word pairs ["I love", "love this", "this movie"]
- Trigrams (n=3): Word triplets ["I love this", "love this movie"]

WHY N-GRAMS?
- Captures some word ORDER (unlike basic BoW)
- "not good" as bigram captures negation
- Better for sentiment analysis

EXAMPLE:
Text: "I love this movie"
Unigrams: [I, love, this, movie]
Bigrams: [I love, love this, this movie]
Trigrams: [I love this, love this movie]

═══════════════════════════════════════════════════════════════════════════════
""")

# Unigrams (default)
unigram_vectorizer = CountVectorizer(ngram_range=(1, 1))
unigram_matrix = unigram_vectorizer.fit_transform(documents)
print(f"Unigram features: {len(unigram_vectorizer.get_feature_names_out())}")

# Bigrams
bigram_vectorizer = CountVectorizer(ngram_range=(2, 2))
bigram_matrix = bigram_vectorizer.fit_transform(documents)
print(f"Bigram features: {bigram_vectorizer.get_feature_names_out()[:10]}")

# Unigrams + Bigrams
combined_vectorizer = CountVectorizer(ngram_range=(1, 2))
combined_matrix = combined_vectorizer.fit_transform(documents)
print(f"Uni+Bigram features: {len(combined_vectorizer.get_feature_names_out())}")

# Display sample
print("\nSample Bigrams:")
print(bigram_vectorizer.get_feature_names_out())
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: TF-IDF (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
TF-IDF (from repository)
═══════════════════════════════════════════════════════════════════════════════

"TF-IDF = Term Frequency × Inverse Document Frequency"

FORMULA:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   TF-IDF(t, d) = TF(t, d) × log(N / DF(t))                                  │
│                                                                             │
│   Where:                                                                    │
│   - TF(t, d) = Frequency of term t in document d                            │
│   - N = Total number of documents                                           │
│   - DF(t) = Number of documents containing term t                           │
│   - IDF = log(N / DF(t)) = Inverse Document Frequency                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

INTUITION:
- High TF-IDF: Word is FREQUENT in this doc but RARE in corpus (important!)
- Low TF-IDF: Word is either rare here OR common everywhere (less important)

EXAMPLE:
- "movie" appears in all movie reviews → Low IDF → Low importance
- "masterpiece" appears in few reviews → High IDF → High importance

═══════════════════════════════════════════════════════════════════════════════
""")

from sklearn.feature_extraction.text import TfidfVectorizer

# Create TF-IDF vectorizer
tfidf_vectorizer = TfidfVectorizer()
tfidf_matrix = tfidf_vectorizer.fit_transform(documents)

# Display
feature_names = tfidf_vectorizer.get_feature_names_out()
tfidf_df = pd.DataFrame(tfidf_matrix.toarray(), columns=feature_names)
print("TF-IDF Matrix:")
print(tfidf_df.round(3))

# Compare BoW vs TF-IDF for "movie" (appears in all docs)
print(f"\nWord 'movie' in BoW: {bow_df['movie'].tolist()}")
print(f"Word 'movie' in TF-IDF: {tfidf_df['movie'].round(3).tolist()}")
print("→ TF-IDF gives lower weight to common words!")

# Manual TF-IDF calculation
print("""
MANUAL CALCULATION EXAMPLE:
Doc 1: "I love this movie it is great"

TF("love", Doc1) = 1/7 = 0.143
DF("love") = 1 (only in Doc1)
IDF("love") = log(4/1) = 1.386
TF-IDF("love", Doc1) = 0.143 × 1.386 = 0.198

TF("movie", Doc1) = 1/7 = 0.143
DF("movie") = 4 (in all docs)
IDF("movie") = log(4/4) = 0
TF-IDF("movie", Doc1) = 0.143 × 0 = 0
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: WORD2VEC (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
WORD2VEC (from repository)
═══════════════════════════════════════════════════════════════════════════════

"Word2Vec creates DENSE vectors that capture SEMANTIC meaning"

KEY FEATURES:
- Dense vectors (50-300 dimensions vs 10,000+ for BoW)
- Captures semantic relationships
- Similar words have similar vectors

FAMOUS EXAMPLE:
vector("king") - vector("man") + vector("woman") ≈ vector("queen")

TWO ARCHITECTURES:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   CBOW (Continuous Bag of Words):                                           │
│   - Predict CENTER word from CONTEXT words                                  │
│   - Input: [The, quick, ___, jumps] → Output: fox                           │
│   - Faster training                                                         │
│   - Better for frequent words                                               │
│                                                                             │
│   SKIP-GRAM:                                                                │
│   - Predict CONTEXT words from CENTER word                                  │
│   - Input: fox → Output: [The, quick, brown, jumps]                         │
│   - Slower training                                                         │
│   - Better for rare words                                                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

VISUAL:
CBOW:     [context] → [hidden] → [center word]
Skip-gram: [center word] → [hidden] → [context]

═══════════════════════════════════════════════════════════════════════════════
""")

from gensim.models import Word2Vec
import numpy as np

# Sample corpus (tokenized)
corpus = [
    ['i', 'love', 'this', 'movie', 'it', 'is', 'great'],
    ['i', 'hate', 'this', 'movie', 'it', 'is', 'terrible'],
    ['this', 'movie', 'is', 'amazing', 'and', 'wonderful'],
    ['this', 'movie', 'is', 'boring', 'and', 'awful'],
    ['great', 'acting', 'and', 'wonderful', 'story'],
    ['terrible', 'acting', 'and', 'boring', 'plot'],
    ['i', 'love', 'the', 'amazing', 'cinematography'],
    ['i', 'hate', 'the', 'awful', 'dialogue']
]

# Train Word2Vec (CBOW)
model_cbow = Word2Vec(
    sentences=corpus,
    vector_size=50,      # Embedding dimension
    window=3,            # Context window size
    min_count=1,         # Minimum word frequency
    sg=0,                # 0=CBOW, 1=Skip-gram
    epochs=100
)

# Train Word2Vec (Skip-gram)
model_skipgram = Word2Vec(
    sentences=corpus,
    vector_size=50,
    window=3,
    min_count=1,
    sg=1,                # Skip-gram
    epochs=100
)

# Get word vector
print("Word vector for 'love':")
print(model_cbow.wv['love'][:10], "...")  # First 10 dimensions

# Find similar words
print("\nMost similar to 'love':")
print(model_cbow.wv.most_similar('love', topn=3))

print("\nMost similar to 'terrible':")
print(model_cbow.wv.most_similar('terrible', topn=3))

# Document vector (average of word vectors)
def get_document_vector(doc, model):
    """Get document vector by averaging word vectors"""
    vectors = []
    for word in doc:
        if word in model.wv:
            vectors.append(model.wv[word])
    if vectors:
        return np.mean(vectors, axis=0)
    return np.zeros(model.vector_size)

doc_vector = get_document_vector(['i', 'love', 'this', 'movie'], model_cbow)
print(f"\nDocument vector shape: {doc_vector.shape}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: POS TAGGING (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
POS TAGGING (from repository)
═══════════════════════════════════════════════════════════════════════════════

"Part-of-Speech tagging assigns grammatical tags to each word"

COMMON POS TAGS:
┌─────────┬─────────────────┬──────────────┐
│ Tag     │ Meaning         │ Example      │
├─────────┼─────────────────┼──────────────┤
│ NN      │ Noun            │ movie, actor │
│ VB      │ Verb            │ love, hate   │
│ JJ      │ Adjective       │ great, bad   │
│ RB      │ Adverb          │ very, really │
│ DT      │ Determiner      │ the, a       │
│ PRP     │ Pronoun         │ I, he, she   │
│ IN      │ Preposition     │ in, on, at   │
│ CC      │ Conjunction     │ and, but, or │
└─────────┴─────────────────┴──────────────┘

WHY POS TAGGING FOR SENTIMENT?
- Adjectives often carry sentiment (great, terrible)
- Can extract only adjectives for analysis
- Helps with word sense disambiguation

═══════════════════════════════════════════════════════════════════════════════
""")

import nltk
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')

# POS tagging example
sentence = "This movie is absolutely fantastic and incredibly well made"
tokens = nltk.word_tokenize(sentence)
pos_tags = nltk.pos_tag(tokens)

print(f"Sentence: {sentence}")
print(f"\nPOS Tags:")
for word, tag in pos_tags:
    print(f"  {word}: {tag}")

# Extract adjectives (sentiment words)
adjectives = [word for word, tag in pos_tags if tag.startswith('JJ')]
print(f"\nAdjectives (sentiment words): {adjectives}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: HMM AND VITERBI (FROM REPO)
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
HMM AND VITERBI ALGORITHM (from repository)
═══════════════════════════════════════════════════════════════════════════════

"HMM (Hidden Markov Model) is used for POS tagging"

GitHub Reference: https://github.com/TrishamBP/pos-tagging-hmm-viterbi-algorithm-nlp

HMM COMPONENTS:
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   1. STATES: POS tags (NN, VB, JJ, etc.)                                    │
│                                                                             │
│   2. OBSERVATIONS: Words (movie, love, great)                               │
│                                                                             │
│   3. TRANSITION PROBABILITIES:                                              │
│      P(next_tag | current_tag)                                              │
│      Example: P(NN | DT) = high (the → movie)                               │
│                                                                             │
│   4. EMISSION PROBABILITIES:                                                │
│      P(word | tag)                                                          │
│      Example: P("movie" | NN) = high                                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

VITERBI ALGORITHM:
"Dynamic programming algorithm to find the MOST LIKELY sequence of tags"

1. Initialize probabilities for first word
2. For each subsequent word:
   - Calculate probability of each tag
   - Track the best path
3. Backtrack to find optimal tag sequence

EXAMPLE:
"I love movies"

Step 1: "I" → most likely PRP (pronoun)
Step 2: "love" → given PRP before, most likely VB (verb)
Step 3: "movies" → given VB before, most likely NN (noun)

Result: [PRP, VB, NN]

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: APPLY TO IMDB DATASET
# ═══════════════════════════════════════════════════════════════════════════════

```python
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import re

# Load data
train_df = pd.read_csv('data/processed/train.csv')
test_df = pd.read_csv('data/processed/test.csv')

# Simple preprocessing
def preprocess(text):
    text = str(text).lower()
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'[^a-z\s]', '', text)
    return ' '.join(text.split())

X_train = train_df['review'].apply(preprocess)
y_train = train_df['label']
X_test = test_df['review'].apply(preprocess)
y_test = test_df['label']

# ============================================
# COMPARE TEXT REPRESENTATIONS
# ============================================

results = {}

# 1. Bag of Words
print("Training with Bag of Words...")
bow = CountVectorizer(max_features=10000)
X_train_bow = bow.fit_transform(X_train)
X_test_bow = bow.transform(X_test)

model_bow = LogisticRegression(max_iter=1000)
model_bow.fit(X_train_bow, y_train)
results['BoW'] = accuracy_score(y_test, model_bow.predict(X_test_bow))
print(f"BoW Accuracy: {results['BoW']:.2%}")

# 2. Bag of Words + Bigrams
print("\nTraining with BoW + Bigrams...")
bow_bigram = CountVectorizer(max_features=10000, ngram_range=(1, 2))
X_train_bigram = bow_bigram.fit_transform(X_train)
X_test_bigram = bow_bigram.transform(X_test)

model_bigram = LogisticRegression(max_iter=1000)
model_bigram.fit(X_train_bigram, y_train)
results['BoW+Bigrams'] = accuracy_score(y_test, model_bigram.predict(X_test_bigram))
print(f"BoW+Bigrams Accuracy: {results['BoW+Bigrams']:.2%}")

# 3. TF-IDF
print("\nTraining with TF-IDF...")
tfidf = TfidfVectorizer(max_features=10000, ngram_range=(1, 2))
X_train_tfidf = tfidf.fit_transform(X_train)
X_test_tfidf = tfidf.transform(X_test)

model_tfidf = LogisticRegression(max_iter=1000)
model_tfidf.fit(X_train_tfidf, y_train)
results['TF-IDF'] = accuracy_score(y_test, model_tfidf.predict(X_test_tfidf))
print(f"TF-IDF Accuracy: {results['TF-IDF']:.2%}")

# Summary
print("\n" + "=" * 40)
print("TEXT REPRESENTATION COMPARISON")
print("=" * 40)
for method, acc in sorted(results.items(), key=lambda x: x[1], reverse=True):
    print(f"{method}: {acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 9 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ Bag of Words (BoW)
   └── Word frequency vectors
   └── High-dimensional, sparse
   └── No semantic meaning

✅ N-grams
   └── Unigrams, Bigrams, Trigrams
   └── Captures word order
   └── "not good" as single feature

✅ TF-IDF
   └── TF × IDF formula
   └── Weights important words higher
   └── Common words get lower weight

✅ Word2Vec
   └── Dense semantic vectors
   └── CBOW: Context → Center word
   └── Skip-gram: Center word → Context

✅ POS Tagging
   └── Grammatical tags (NN, VB, JJ)
   └── Extract sentiment words

✅ HMM and Viterbi
   └── States, Observations
   └── Transition & Emission probabilities
   └── Find most likely tag sequence
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY ACHIEVED
# ═══════════════════════════════════════════════════════════════════════════════

```
📊 PHASE 9 RESULTS:

Representation     | Model              | Accuracy
-------------------|--------------------|----------
Bag of Words       | Logistic Regression| ~82-85%
BoW + Bigrams      | Logistic Regression| ~83-86%
TF-IDF             | Logistic Regression| ~85-87%
Word2Vec           | Logistic Regression| ~86-88%

🚀 NEXT: PHASE 10 - NLP APPLICATIONS & DEPLOYMENT
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# READY FOR PHASE 10: DEPLOYMENT
# ═══════════════════════════════════════════════════════════════════════════════

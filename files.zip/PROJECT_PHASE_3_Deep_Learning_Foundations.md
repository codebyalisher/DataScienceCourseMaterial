# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 3: DEEP LEARNING FOUNDATIONS
# Movie Review Sentiment Analyzer - Implementation Guide
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Build neural networks from scratch, understand the fundamentals of deep learning.

## 📚 CONCEPTS COVERED
- Perceptron (Single Neuron)
- Multi-Layer Perceptron (MLP)
- Activation Functions
- Loss Functions (BCE, CCE, MSE)
- Forward Propagation
- Backpropagation
- Gradient Descent (SGD vs BGD)
- Overfitting Solutions

## 📊 EXPECTED ACCURACY
- Perceptron: ~60-65%
- MLP: ~70-75%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: UNDERSTANDING THE PERCEPTRON
# ═══════════════════════════════════════════════════════════════════════════════

**Perceptron**: The fundamental building block of neural networks. Initially designed
for binary classification. Takes inputs, multiplies by weights, adds bias, applies
activation function.

```python
import numpy as np
import matplotlib.pyplot as plt

# ============================================
# PERCEPTRON FROM SCRATCH
# ============================================

class Perceptron:
    """
    Single layer perceptron (one neuron)
    
    Formula: output = activation(sum(inputs * weights) + bias)
    
    For binary classification:
    - If output >= 0.5: predict 1 (positive)
    - If output < 0.5: predict 0 (negative)
    """
    
    def __init__(self, n_inputs, learning_rate=0.01):
        """
        Initialize perceptron with random weights
        
        wijk notation from repo:
        - i = layer number
        - j = node position in layer
        - k = which node from previous layer
        """
        # Initialize weights randomly (small values)
        self.weights = np.random.randn(n_inputs) * 0.01
        self.bias = 0.0
        self.learning_rate = learning_rate
        self.losses = []
    
    def sigmoid(self, z):
        """
        Sigmoid activation function
        Squashes output between 0 and 1
        """
        # Clip to prevent overflow
        z = np.clip(z, -500, 500)
        return 1 / (1 + np.exp(-z))
    
    def sigmoid_derivative(self, z):
        """Derivative of sigmoid for backpropagation"""
        s = self.sigmoid(z)
        return s * (1 - s)
    
    def forward(self, X):
        """
        Forward Propagation:
        1. Take dot product of inputs with weights
        2. Add bias
        3. Apply activation function
        """
        # Linear combination: z = X·W + b
        self.z = np.dot(X, self.weights) + self.bias
        # Apply activation
        self.output = self.sigmoid(self.z)
        return self.output
    
    def compute_loss(self, y_true, y_pred):
        """
        Binary Cross-Entropy Loss
        
        L = -[y·log(ŷ) + (1-y)·log(1-ŷ)]
        """
        # Clip predictions to prevent log(0)
        y_pred = np.clip(y_pred, 1e-15, 1 - 1e-15)
        loss = -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))
        return loss
    
    def backward(self, X, y_true, y_pred):
        """
        Backpropagation:
        
        We need to calculate:
        ∂L/∂W = (∂L/∂ŷ) × (∂ŷ/∂W)
        
        This is the CHAIN RULE!
        
        For BCE + Sigmoid:
        ∂L/∂W = (ŷ - y) × X
        ∂L/∂b = (ŷ - y)
        """
        m = X.shape[0]  # Number of samples
        
        # Gradient calculation
        error = y_pred - y_true  # (ŷ - y)
        
        # Gradient for weights: ∂L/∂W
        dW = np.dot(X.T, error) / m
        
        # Gradient for bias: ∂L/∂b
        db = np.mean(error)
        
        return dW, db
    
    def update_weights(self, dW, db):
        """
        Gradient Descent Update:
        
        W_new = W_old - learning_rate × ∂L/∂W
        b_new = b_old - learning_rate × ∂L/∂b
        
        We SUBTRACT because we want to MINIMIZE loss
        """
        self.weights -= self.learning_rate * dW
        self.bias -= self.learning_rate * db
    
    def train(self, X, y, epochs=100):
        """
        Training loop:
        1. Forward propagation
        2. Compute loss
        3. Backpropagation
        4. Update weights
        5. Repeat
        """
        for epoch in range(epochs):
            # Forward
            y_pred = self.forward(X)
            
            # Loss
            loss = self.compute_loss(y, y_pred)
            self.losses.append(loss)
            
            # Backward
            dW, db = self.backward(X, y, y_pred)
            
            # Update
            self.update_weights(dW, db)
            
            if epoch % 10 == 0:
                accuracy = self.evaluate(X, y)
                print(f"Epoch {epoch}: Loss = {loss:.4f}, Accuracy = {accuracy:.4f}")
    
    def predict(self, X):
        """Make predictions"""
        output = self.forward(X)
        return (output >= 0.5).astype(int)
    
    def evaluate(self, X, y):
        """Calculate accuracy"""
        predictions = self.predict(X)
        return np.mean(predictions == y)


# ============================================
# TEST PERCEPTRON ON SIMPLE DATA
# ============================================

# Create simple linearly separable data
np.random.seed(42)
n_samples = 1000

# Class 0: centered at (-1, -1)
X0 = np.random.randn(n_samples // 2, 2) + np.array([-1, -1])
# Class 1: centered at (1, 1)
X1 = np.random.randn(n_samples // 2, 2) + np.array([1, 1])

X = np.vstack([X0, X1])
y = np.hstack([np.zeros(n_samples // 2), np.ones(n_samples // 2)])

# Shuffle
shuffle_idx = np.random.permutation(n_samples)
X, y = X[shuffle_idx], y[shuffle_idx]

# Train perceptron
perceptron = Perceptron(n_inputs=2, learning_rate=0.1)
perceptron.train(X, y, epochs=100)

# Plot results
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Plot 1: Decision Boundary
ax1 = axes[0]
# Create mesh grid
xx, yy = np.meshgrid(np.linspace(-4, 4, 100), np.linspace(-4, 4, 100))
Z = perceptron.predict(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape)

ax1.contourf(xx, yy, Z, alpha=0.3, cmap='RdBu')
ax1.scatter(X[y == 0][:, 0], X[y == 0][:, 1], c='red', label='Class 0', alpha=0.5)
ax1.scatter(X[y == 1][:, 0], X[y == 1][:, 1], c='blue', label='Class 1', alpha=0.5)
ax1.set_xlabel('Feature 1')
ax1.set_ylabel('Feature 2')
ax1.set_title('Perceptron Decision Boundary')
ax1.legend()

# Plot 2: Loss Curve
ax2 = axes[1]
ax2.plot(perceptron.losses)
ax2.set_xlabel('Epoch')
ax2.set_ylabel('Loss')
ax2.set_title('Training Loss')
ax2.grid(True)

plt.tight_layout()
plt.savefig('models/perceptron_demo.png', dpi=150)
plt.show()

print(f"\nFinal Accuracy: {perceptron.evaluate(X, y):.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: MULTI-LAYER PERCEPTRON (MLP) FROM SCRATCH
# ═══════════════════════════════════════════════════════════════════════════════

**MLP**: Multiple perceptrons stacked. Output of each perceptron multiplied with
weight and passed to next layer. Final layer applies sigmoid for output.

```python
# ============================================
# MLP FROM SCRATCH
# ============================================

class MLP:
    """
    Multi-Layer Perceptron with one hidden layer
    
    Architecture:
    Input Layer → Hidden Layer → Output Layer
    
    Notation (from repo):
    - wijk: weight where i=entering layer, j=node position, k=previous node
    - oij: output of node j in layer i
    - bij: bias of node j in layer i
    """
    
    def __init__(self, input_size, hidden_size, output_size, learning_rate=0.01):
        """
        Initialize MLP
        
        Trainable Parameters:
        - W1: input_size × hidden_size
        - b1: hidden_size
        - W2: hidden_size × output_size
        - b2: output_size
        
        Total = (input × hidden) + hidden + (hidden × output) + output
        """
        # He initialization (good for ReLU)
        self.W1 = np.random.randn(input_size, hidden_size) * np.sqrt(2 / input_size)
        self.b1 = np.zeros(hidden_size)
        self.W2 = np.random.randn(hidden_size, output_size) * np.sqrt(2 / hidden_size)
        self.b2 = np.zeros(output_size)
        
        self.learning_rate = learning_rate
        self.losses = []
        
        # Print architecture
        print("=" * 50)
        print("MLP ARCHITECTURE")
        print("=" * 50)
        print(f"Input size: {input_size}")
        print(f"Hidden size: {hidden_size}")
        print(f"Output size: {output_size}")
        total_params = (input_size * hidden_size + hidden_size + 
                       hidden_size * output_size + output_size)
        print(f"Total trainable parameters: {total_params}")
        print("=" * 50)
    
    def relu(self, z):
        """ReLU activation for hidden layer"""
        return np.maximum(0, z)
    
    def relu_derivative(self, z):
        """Derivative of ReLU"""
        return (z > 0).astype(float)
    
    def sigmoid(self, z):
        """Sigmoid activation for output layer"""
        z = np.clip(z, -500, 500)
        return 1 / (1 + np.exp(-z))
    
    def forward(self, X):
        """
        Forward Propagation through all layers
        
        Layer 1 (Hidden):
        z1 = X·W1 + b1
        a1 = ReLU(z1)
        
        Layer 2 (Output):
        z2 = a1·W2 + b2
        a2 = sigmoid(z2)
        """
        # Hidden layer
        self.z1 = np.dot(X, self.W1) + self.b1
        self.a1 = self.relu(self.z1)  # Hidden layer output
        
        # Output layer
        self.z2 = np.dot(self.a1, self.W2) + self.b2
        self.a2 = self.sigmoid(self.z2)  # Final output
        
        return self.a2
    
    def compute_loss(self, y_true, y_pred):
        """Binary Cross-Entropy Loss"""
        y_pred = np.clip(y_pred, 1e-15, 1 - 1e-15)
        loss = -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))
        return loss
    
    def backward(self, X, y_true, y_pred):
        """
        Backpropagation using Chain Rule
        
        We go BACKWARD through the network:
        
        Output layer gradient:
        ∂L/∂W2 = a1.T · (a2 - y)
        ∂L/∂b2 = sum(a2 - y)
        
        Hidden layer gradient (chain rule):
        ∂L/∂W1 = X.T · [(a2 - y) · W2.T * ReLU'(z1)]
        ∂L/∂b1 = sum[(a2 - y) · W2.T * ReLU'(z1)]
        """
        m = X.shape[0]
        
        # Output layer
        dz2 = y_pred - y_true.reshape(-1, 1)  # (a2 - y)
        dW2 = np.dot(self.a1.T, dz2) / m
        db2 = np.mean(dz2, axis=0)
        
        # Hidden layer (backpropagate through output layer)
        dz1 = np.dot(dz2, self.W2.T) * self.relu_derivative(self.z1)
        dW1 = np.dot(X.T, dz1) / m
        db1 = np.mean(dz1, axis=0)
        
        return dW1, db1, dW2, db2
    
    def update_weights(self, dW1, db1, dW2, db2):
        """Gradient Descent Update"""
        self.W1 -= self.learning_rate * dW1
        self.b1 -= self.learning_rate * db1
        self.W2 -= self.learning_rate * dW2
        self.b2 -= self.learning_rate * db2
    
    def train(self, X, y, epochs=100, batch_size=32):
        """
        Training with mini-batch gradient descent
        
        SGD vs BGD:
        - SGD: Update weights after each sample (batch_size=1)
        - BGD: Update weights after all samples (batch_size=n)
        - Mini-batch: Update after batch_size samples (best of both)
        """
        n_samples = X.shape[0]
        
        for epoch in range(epochs):
            # Shuffle data each epoch
            indices = np.random.permutation(n_samples)
            X_shuffled = X[indices]
            y_shuffled = y[indices]
            
            epoch_loss = 0
            n_batches = 0
            
            # Mini-batch training
            for i in range(0, n_samples, batch_size):
                X_batch = X_shuffled[i:i+batch_size]
                y_batch = y_shuffled[i:i+batch_size]
                
                # Forward
                y_pred = self.forward(X_batch)
                
                # Loss
                batch_loss = self.compute_loss(y_batch, y_pred.flatten())
                epoch_loss += batch_loss
                n_batches += 1
                
                # Backward
                dW1, db1, dW2, db2 = self.backward(X_batch, y_batch, y_pred)
                
                # Update
                self.update_weights(dW1, db1, dW2, db2)
            
            avg_loss = epoch_loss / n_batches
            self.losses.append(avg_loss)
            
            if epoch % 10 == 0:
                accuracy = self.evaluate(X, y)
                print(f"Epoch {epoch}: Loss = {avg_loss:.4f}, Accuracy = {accuracy:.4f}")
    
    def predict(self, X):
        """Make predictions"""
        output = self.forward(X)
        return (output >= 0.5).astype(int).flatten()
    
    def evaluate(self, X, y):
        """Calculate accuracy"""
        predictions = self.predict(X)
        return np.mean(predictions == y)


# ============================================
# TEST MLP ON XOR PROBLEM
# ============================================

# XOR is NOT linearly separable - needs hidden layer!
X_xor = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y_xor = np.array([0, 1, 1, 0])  # XOR output

# Perceptron CANNOT solve XOR
print("\nTrying Perceptron on XOR (will fail):")
perceptron_xor = Perceptron(n_inputs=2, learning_rate=0.5)
perceptron_xor.train(X_xor, y_xor, epochs=100)
print(f"Perceptron XOR Accuracy: {perceptron_xor.evaluate(X_xor, y_xor):.2%}")

# MLP CAN solve XOR
print("\nTrying MLP on XOR (will succeed):")
mlp_xor = MLP(input_size=2, hidden_size=4, output_size=1, learning_rate=0.5)
mlp_xor.train(X_xor, y_xor, epochs=1000, batch_size=4)
print(f"MLP XOR Accuracy: {mlp_xor.evaluate(X_xor, y_xor):.2%}")
print(f"MLP Predictions: {mlp_xor.predict(X_xor)}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: APPLY TO SENTIMENT ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# MLP ON SENTIMENT DATA
# ============================================

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
import re

# Load data
train_df = pd.read_csv('data/processed/train.csv')
test_df = pd.read_csv('data/processed/test.csv')

# Simple preprocessing
def preprocess(text):
    text = text.lower()
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'[^a-z\s]', '', text)
    return ' '.join(text.split())

X_train = train_df['review'].apply(preprocess)
y_train = train_df['label'].values
X_test = test_df['review'].apply(preprocess)
y_test = test_df['label'].values

# TF-IDF (smaller vocabulary for MLP)
tfidf = TfidfVectorizer(max_features=5000, stop_words='english')
X_train_tfidf = tfidf.fit_transform(X_train).toarray()
X_test_tfidf = tfidf.transform(X_test).toarray()

print(f"Training shape: {X_train_tfidf.shape}")
print(f"Testing shape: {X_test_tfidf.shape}")

# Use smaller sample for from-scratch MLP (it's slow)
sample_size = 5000
sample_idx = np.random.choice(len(X_train_tfidf), sample_size, replace=False)
X_train_sample = X_train_tfidf[sample_idx]
y_train_sample = y_train[sample_idx]

# Train MLP from scratch
print("\n" + "=" * 60)
print("TRAINING MLP FROM SCRATCH")
print("=" * 60)

mlp = MLP(
    input_size=5000,    # TF-IDF features
    hidden_size=128,    # Hidden neurons
    output_size=1,      # Binary output
    learning_rate=0.1
)

mlp.train(X_train_sample, y_train_sample, epochs=50, batch_size=64)

# Evaluate
train_acc = mlp.evaluate(X_train_sample, y_train_sample)
test_acc = mlp.evaluate(X_test_tfidf, y_test)

print(f"\nFinal Training Accuracy: {train_acc:.2%}")
print(f"Final Testing Accuracy: {test_acc:.2%}")

# Plot loss
plt.figure(figsize=(10, 5))
plt.plot(mlp.losses)
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('MLP Training Loss (From Scratch)')
plt.grid(True)
plt.savefig('models/mlp_scratch_loss.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: MLP USING KERAS (PRODUCTION-READY)
# ═══════════════════════════════════════════════════════════════════════════════

**Types of Models in Keras**:
- **Sequential**: Linear stack of layers (simple)
- **Functional API**: Non-linear, multiple inputs/outputs, transfer learning

```python
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, models
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint

# ============================================
# KERAS SEQUENTIAL MODEL
# ============================================

print("\n" + "=" * 60)
print("KERAS MLP (SEQUENTIAL)")
print("=" * 60)

# Build model
model_sequential = keras.Sequential([
    # Input layer (implicit) + First hidden layer
    layers.Dense(256, activation='relu', input_shape=(5000,)),
    layers.Dropout(0.5),  # Overfitting solution
    
    # Second hidden layer
    layers.Dense(128, activation='relu'),
    layers.Dropout(0.3),
    
    # Third hidden layer
    layers.Dense(64, activation='relu'),
    layers.Dropout(0.2),
    
    # Output layer
    layers.Dense(1, activation='sigmoid')  # Binary classification
])

# Model summary
model_sequential.summary()

# Compile
model_sequential.compile(
    optimizer=keras.optimizers.Adam(learning_rate=0.001),
    loss='binary_crossentropy',  # BCE for binary
    metrics=['accuracy']
)

# Callbacks
callbacks = [
    EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True),
    ModelCheckpoint('models/mlp_keras_best.h5', save_best_only=True)
]

# Train
history = model_sequential.fit(
    X_train_tfidf, y_train,
    validation_split=0.2,
    epochs=50,
    batch_size=128,
    callbacks=callbacks,
    verbose=1
)

# Evaluate
train_loss, train_acc = model_sequential.evaluate(X_train_tfidf, y_train, verbose=0)
test_loss, test_acc = model_sequential.evaluate(X_test_tfidf, y_test, verbose=0)

print(f"\nTraining Accuracy: {train_acc:.2%}")
print(f"Testing Accuracy: {test_acc:.2%}")

# Plot training history
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Loss
axes[0].plot(history.history['loss'], label='Train')
axes[0].plot(history.history['val_loss'], label='Validation')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('Loss')
axes[0].set_title('Training & Validation Loss')
axes[0].legend()
axes[0].grid(True)

# Accuracy
axes[1].plot(history.history['accuracy'], label='Train')
axes[1].plot(history.history['val_accuracy'], label='Validation')
axes[1].set_xlabel('Epoch')
axes[1].set_ylabel('Accuracy')
axes[1].set_title('Training & Validation Accuracy')
axes[1].legend()
axes[1].grid(True)

plt.tight_layout()
plt.savefig('models/mlp_keras_history.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: KERAS FUNCTIONAL API
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# KERAS FUNCTIONAL API
# ============================================

print("\n" + "=" * 60)
print("KERAS MLP (FUNCTIONAL API)")
print("=" * 60)

# Input layer
inputs = keras.Input(shape=(5000,), name='text_input')

# Hidden layers
x = layers.Dense(256, activation='relu', name='hidden1')(inputs)
x = layers.Dropout(0.5)(x)
x = layers.Dense(128, activation='relu', name='hidden2')(x)
x = layers.Dropout(0.3)(x)
x = layers.Dense(64, activation='relu', name='hidden3')(x)

# Output layer
outputs = layers.Dense(1, activation='sigmoid', name='output')(x)

# Create model
model_functional = keras.Model(inputs=inputs, outputs=outputs, name='mlp_functional')

# Summary
model_functional.summary()

# Compile
model_functional.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# Train
history_func = model_functional.fit(
    X_train_tfidf, y_train,
    validation_split=0.2,
    epochs=30,
    batch_size=128,
    callbacks=[EarlyStopping(patience=5, restore_best_weights=True)],
    verbose=1
)

# Evaluate
test_loss, test_acc = model_functional.evaluate(X_test_tfidf, y_test)
print(f"\nFunctional API Test Accuracy: {test_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: LOSS FUNCTIONS EXPLAINED
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# LOSS FUNCTIONS VISUALIZATION
# ============================================

print("\n" + "=" * 60)
print("LOSS FUNCTIONS")
print("=" * 60)

# Create predictions range
y_pred_range = np.linspace(0.01, 0.99, 100)

# True label = 1 (positive)
bce_positive = -np.log(y_pred_range)  # -log(ŷ) when y=1

# True label = 0 (negative)
bce_negative = -np.log(1 - y_pred_range)  # -log(1-ŷ) when y=0

# MSE for comparison
mse_positive = (1 - y_pred_range) ** 2
mse_negative = (0 - y_pred_range) ** 2

# Plot
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# BCE
ax1 = axes[0]
ax1.plot(y_pred_range, bce_positive, 'b-', label='True=1 (Positive)')
ax1.plot(y_pred_range, bce_negative, 'r-', label='True=0 (Negative)')
ax1.set_xlabel('Predicted Probability (ŷ)')
ax1.set_ylabel('Loss')
ax1.set_title('Binary Cross-Entropy Loss')
ax1.legend()
ax1.grid(True)
ax1.set_ylim(0, 5)

# MSE
ax2 = axes[1]
ax2.plot(y_pred_range, mse_positive, 'b-', label='True=1 (Positive)')
ax2.plot(y_pred_range, mse_negative, 'r-', label='True=0 (Negative)')
ax2.set_xlabel('Predicted Probability (ŷ)')
ax2.set_ylabel('Loss')
ax2.set_title('Mean Squared Error Loss')
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.savefig('models/loss_functions.png', dpi=150)
plt.show()

print("""
LOSS FUNCTIONS SUMMARY:

📊 REGRESSION PROBLEMS:
   - MSE (Mean Squared Error): (y - ŷ)²
     Use when: Continuous output, no outliers
   
   - MAE (Mean Absolute Error): |y - ŷ|
     Use when: Continuous output, HAS outliers

📊 CLASSIFICATION PROBLEMS:
   - BCE (Binary Cross-Entropy): -[y·log(ŷ) + (1-y)·log(1-ŷ)]
     Use when: Binary classification (2 classes)
   
   - CCE (Categorical Cross-Entropy): -Σ y·log(ŷ)
     Use when: Multi-class, calculate log for EACH category
   
   - SCE (Sparse Cross-Entropy): Same as CCE
     Use when: Multi-class, labels are integers (not one-hot)
     Calculates for only ONE category (more efficient)
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: ACTIVATION FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# ACTIVATION FUNCTIONS
# ============================================

z = np.linspace(-5, 5, 100)

# Sigmoid
sigmoid = 1 / (1 + np.exp(-z))

# Tanh
tanh = np.tanh(z)

# ReLU
relu = np.maximum(0, z)

# Leaky ReLU
leaky_relu = np.where(z > 0, z, 0.01 * z)

# Plot
fig, axes = plt.subplots(2, 2, figsize=(12, 10))

# Sigmoid
axes[0, 0].plot(z, sigmoid, 'b-', linewidth=2)
axes[0, 0].axhline(y=0.5, color='gray', linestyle='--', alpha=0.5)
axes[0, 0].axvline(x=0, color='gray', linestyle='--', alpha=0.5)
axes[0, 0].set_title('Sigmoid: σ(z) = 1/(1+e^(-z))', fontsize=12)
axes[0, 0].set_xlabel('z')
axes[0, 0].set_ylabel('σ(z)')
axes[0, 0].grid(True)
axes[0, 0].set_ylim(-0.1, 1.1)

# Tanh
axes[0, 1].plot(z, tanh, 'g-', linewidth=2)
axes[0, 1].axhline(y=0, color='gray', linestyle='--', alpha=0.5)
axes[0, 1].axvline(x=0, color='gray', linestyle='--', alpha=0.5)
axes[0, 1].set_title('Tanh: tanh(z)', fontsize=12)
axes[0, 1].set_xlabel('z')
axes[0, 1].set_ylabel('tanh(z)')
axes[0, 1].grid(True)

# ReLU
axes[1, 0].plot(z, relu, 'r-', linewidth=2)
axes[1, 0].axhline(y=0, color='gray', linestyle='--', alpha=0.5)
axes[1, 0].axvline(x=0, color='gray', linestyle='--', alpha=0.5)
axes[1, 0].set_title('ReLU: max(0, z)', fontsize=12)
axes[1, 0].set_xlabel('z')
axes[1, 0].set_ylabel('ReLU(z)')
axes[1, 0].grid(True)

# Leaky ReLU
axes[1, 1].plot(z, leaky_relu, 'm-', linewidth=2)
axes[1, 1].axhline(y=0, color='gray', linestyle='--', alpha=0.5)
axes[1, 1].axvline(x=0, color='gray', linestyle='--', alpha=0.5)
axes[1, 1].set_title('Leaky ReLU: max(0.01z, z)', fontsize=12)
axes[1, 1].set_xlabel('z')
axes[1, 1].set_ylabel('LeakyReLU(z)')
axes[1, 1].grid(True)

plt.tight_layout()
plt.savefig('models/activation_functions.png', dpi=150)
plt.show()

print("""
ACTIVATION FUNCTIONS SUMMARY:

📊 SIGMOID:
   - Output: (0, 1)
   - Use: Output layer for binary classification
   - Problem: Vanishing gradient

📊 TANH:
   - Output: (-1, 1)
   - Use: RNN hidden layers (vectors are 0/1)
   - Better than sigmoid (zero-centered)

📊 RELU:
   - Output: [0, ∞)
   - Use: Hidden layers (most common)
   - Fast, no vanishing gradient
   - Problem: "Dying ReLU" (neurons stuck at 0)

📊 LEAKY RELU:
   - Output: (-∞, ∞)
   - Use: When ReLU neurons are dying
   - Small negative slope prevents dead neurons
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8: OVERFITTING SOLUTIONS
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# OVERFITTING SOLUTIONS DEMONSTRATION
# ============================================

print("""
OVERFITTING SOLUTIONS FROM REPOSITORY:

1️⃣ EARLY STOPPING
   - Monitor validation loss
   - Stop when it starts increasing
   - Keras: EarlyStopping(patience=5)

2️⃣ DROPOUT
   - Randomly disable neurons during training
   - Forces network to not rely on specific neurons
   - Keras: layers.Dropout(0.5)

3️⃣ L1/L2 REGULARIZATION
   - Add penalty for large weights
   - L1: sum(|w|) - sparse weights
   - L2: sum(w²) - small weights
   - Keras: kernel_regularizer=l2(0.01)

4️⃣ DATA AUGMENTATION
   - Create variations of training data
   - For images: rotation, flip, zoom
   - For text: synonym replacement, back-translation

5️⃣ CROSS-VALIDATION
   - Train on multiple folds
   - More robust evaluation

6️⃣ REDUCE MODEL COMPLEXITY
   - Fewer layers/neurons
   - Simpler architecture
""")

# Demonstrate L2 Regularization
from tensorflow.keras import regularizers

model_regularized = keras.Sequential([
    layers.Dense(256, activation='relu', 
                 kernel_regularizer=regularizers.l2(0.01),
                 input_shape=(5000,)),
    layers.Dropout(0.5),
    layers.Dense(128, activation='relu',
                 kernel_regularizer=regularizers.l2(0.01)),
    layers.Dropout(0.3),
    layers.Dense(1, activation='sigmoid')
])

model_regularized.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# Train with early stopping
history_reg = model_regularized.fit(
    X_train_tfidf, y_train,
    validation_split=0.2,
    epochs=50,
    batch_size=128,
    callbacks=[EarlyStopping(patience=5, restore_best_weights=True)],
    verbose=1
)

# Compare overfitting
fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(history_reg.history['loss'], label='Train Loss')
ax.plot(history_reg.history['val_loss'], label='Val Loss')
ax.set_xlabel('Epoch')
ax.set_ylabel('Loss')
ax.set_title('Training with Regularization + Dropout + Early Stopping')
ax.legend()
ax.grid(True)
plt.savefig('models/overfitting_demo.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 9: SGD vs BGD DEMONSTRATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# SGD vs BGD (from repo)
# ============================================

print("""
SGD vs BGD (from repository):

📊 SGD (Stochastic Gradient Descent):
   - Update weights at EACH sample/row
   - Batch size = 1
   - Very noisy, fast updates
   - May never converge perfectly

📊 BGD (Batch Gradient Descent):
   - Update weights after COMPLETE batch
   - Batch size = all samples
   - Smooth, slow updates
   - May get stuck in local minimum

📊 MINI-BATCH GD (Best of both):
   - Update weights after batch_size samples
   - Typical batch_size: 32, 64, 128, 256
   - Balanced noise and stability
   - Most commonly used
""")

# Visual comparison
np.random.seed(42)

# Simple optimization problem: find minimum of f(w) = w²
def loss_fn(w):
    return w ** 2

def gradient_fn(w):
    return 2 * w

# Simulate SGD (with noise)
def sgd_path(start, lr, steps, noise=0.5):
    path = [start]
    w = start
    for _ in range(steps):
        grad = gradient_fn(w) + np.random.randn() * noise  # Noisy gradient
        w = w - lr * grad
        path.append(w)
    return path

# Simulate BGD (no noise)
def bgd_path(start, lr, steps):
    path = [start]
    w = start
    for _ in range(steps):
        grad = gradient_fn(w)  # Clean gradient
        w = w - lr * grad
        path.append(w)
    return path

# Run simulations
start = 4.0
lr = 0.1
steps = 30

sgd = sgd_path(start, lr, steps, noise=1.0)
bgd = bgd_path(start, lr, steps)

# Plot
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Path comparison
ax1 = axes[0]
ax1.plot(sgd, 'r-', alpha=0.7, label='SGD (noisy)')
ax1.plot(bgd, 'b-', alpha=0.7, label='BGD (smooth)')
ax1.axhline(y=0, color='green', linestyle='--', label='Optimal')
ax1.set_xlabel('Step')
ax1.set_ylabel('Weight (w)')
ax1.set_title('SGD vs BGD: Weight Path')
ax1.legend()
ax1.grid(True)

# Loss comparison
ax2 = axes[1]
ax2.plot([loss_fn(w) for w in sgd], 'r-', alpha=0.7, label='SGD')
ax2.plot([loss_fn(w) for w in bgd], 'b-', alpha=0.7, label='BGD')
ax2.set_xlabel('Step')
ax2.set_ylabel('Loss')
ax2.set_title('SGD vs BGD: Loss')
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.savefig('models/sgd_vs_bgd.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 3 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ Perceptron from Scratch
   └── Single neuron implementation
   └── Forward propagation
   └── Backpropagation
   └── Cannot solve XOR

✅ MLP from Scratch
   └── Multi-layer implementation
   └── Hidden layers with ReLU
   └── CAN solve XOR
   └── Chain rule for gradients

✅ Keras Sequential Model
   └── Simple linear stack
   └── Easy to build

✅ Keras Functional API
   └── Flexible architecture
   └── Multiple inputs/outputs possible

✅ Loss Functions
   └── BCE for binary classification
   └── CCE for multi-class
   └── MSE/MAE for regression

✅ Activation Functions
   └── Sigmoid (output)
   └── Tanh (RNN)
   └── ReLU (hidden)

✅ Forward Propagation
   └── z = X·W + b
   └── a = activation(z)

✅ Backpropagation
   └── Chain rule
   └── ∂L/∂W = ∂L/∂ŷ × ∂ŷ/∂W

✅ SGD vs BGD
   └── SGD: per sample
   └── BGD: all samples
   └── Mini-batch: best of both

✅ Overfitting Solutions
   └── Early stopping
   └── Dropout
   └── L1/L2 regularization
   └── Data augmentation
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY ACHIEVED
# ═══════════════════════════════════════════════════════════════════════════════

```
📊 PHASE 3 RESULTS:

Model                          | Accuracy
-------------------------------|----------
Perceptron (scratch)           | ~60-65%
MLP (scratch)                  | ~70-75%
Keras MLP (Sequential)         | ~75-80%
Keras MLP (Functional)         | ~75-80%

📈 Progress from PHASE 2:
   ML Best (XGBoost): ~88%
   DL MLP: ~75-80%

❓ Why is MLP worse than XGBoost?
   - TF-IDF is sparse (not ideal for dense networks)
   - Text has sequential structure (MLP ignores it)
   - Need specialized architectures (CNN/RNN)

🚀 NEXT: PHASE 4 - CNN
   - Convolutional layers capture local patterns
   - Better for text classification
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# READY FOR PHASE 4: CNN
# ═══════════════════════════════════════════════════════════════════════════════

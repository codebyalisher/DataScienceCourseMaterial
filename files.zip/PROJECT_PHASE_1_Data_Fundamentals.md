# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 1: DATA FUNDAMENTALS
# Movie Review Sentiment Analyzer - Implementation Guide
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Build a solid foundation by acquiring, assessing, exploring, and visualizing the IMDB dataset.

## 📚 CONCEPTS COVERED
- Data Acquisition
- Manual Assessment
- Programmatic Assessment
- Exploratory Data Analysis (EDA)
- Data Visualization & Storytelling

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: ENVIRONMENT SETUP
# ═══════════════════════════════════════════════════════════════════════════════

```python
# Create a new directory for the project
# Open terminal and run:
# mkdir movie_sentiment_analyzer
# cd movie_sentiment_analyzer
# python -m venv venv
# source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install required packages
# pip install pandas numpy matplotlib seaborn wordcloud scikit-learn tensorflow keras nltk

# Create project structure:
# movie_sentiment_analyzer/
# ├── data/
# │   ├── raw/
# │   └── processed/
# ├── notebooks/
# │   ├── phase1_data_fundamentals.ipynb
# │   ├── phase2_machine_learning.ipynb
# │   └── ... (one notebook per phase)
# ├── src/
# │   ├── preprocessing.py
# │   ├── models.py
# │   └── utils.py
# ├── models/
# │   └── saved_models/
# └── app/
#     └── flask_app.py
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: DATA ACQUISITION
# ═══════════════════════════════════════════════════════════════════════════════

## Option A: Using Keras Built-in Dataset

```python
import tensorflow as tf
from tensorflow.keras.datasets import imdb
import numpy as np
import pandas as pd

# Load IMDB dataset
# num_words = keep top 10,000 most frequent words
(X_train, y_train), (X_test, y_test) = imdb.load_data(num_words=10000)

print(f"Training samples: {len(X_train)}")
print(f"Testing samples: {len(X_test)}")
print(f"Sample review (encoded): {X_train[0][:20]}...")
print(f"Sample label: {y_train[0]}")  # 0 = negative, 1 = positive

# Get word index to decode reviews
word_index = imdb.get_word_index()

# Reverse the word index (index -> word)
reverse_word_index = {value: key for key, value in word_index.items()}

# Function to decode reviews
def decode_review(encoded_review):
    """Convert encoded review back to text"""
    # Index is offset by 3 because 0, 1, 2 are reserved
    # 0 = padding, 1 = start, 2 = unknown
    return ' '.join([reverse_word_index.get(i - 3, '?') for i in encoded_review])

# Decode a sample review
sample_review = decode_review(X_train[0])
print(f"\nDecoded review:\n{sample_review[:500]}...")
```

## Option B: Using Kaggle Dataset (Recommended for full text)

```python
# Download from: https://www.kaggle.com/datasets/lakshmi25npathi/imdb-dataset-of-50k-movie-reviews

import pandas as pd

# Load the CSV file
df = pd.read_csv('data/raw/IMDB Dataset.csv')

print(f"Dataset shape: {df.shape}")
print(f"\nColumn names: {df.columns.tolist()}")
print(f"\nFirst few rows:")
print(df.head())

# Basic info
print(f"\nDataset Info:")
print(df.info())
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: MANUAL ASSESSMENT
# ═══════════════════════════════════════════════════════════════════════════════

**Manual Assessment**: Done by visually inspecting data in tools like Excel, Google Sheets, or raw text files.

```python
# ============================================
# MANUAL ASSESSMENT - Visual Inspection
# ============================================

# 1. View first few records
print("=" * 60)
print("FIRST 5 REVIEWS:")
print("=" * 60)
for idx in range(5):
    print(f"\n--- Review {idx + 1} ---")
    print(f"Sentiment: {df['sentiment'].iloc[idx]}")
    print(f"Review (first 200 chars): {df['review'].iloc[idx][:200]}...")
    print()

# 2. View random samples
print("=" * 60)
print("RANDOM SAMPLES:")
print("=" * 60)
random_samples = df.sample(5, random_state=42)
for idx, row in random_samples.iterrows():
    print(f"\n--- Sample ---")
    print(f"Sentiment: {row['sentiment']}")
    print(f"Review: {row['review'][:200]}...")

# 3. Check for obvious issues
print("\n" + "=" * 60)
print("MANUAL QUALITY CHECKS:")
print("=" * 60)

# Check unique sentiments
print(f"\nUnique sentiments: {df['sentiment'].unique()}")

# Check for empty reviews
empty_reviews = df[df['review'].str.strip() == '']
print(f"Empty reviews: {len(empty_reviews)}")

# Check for very short reviews
short_reviews = df[df['review'].str.len() < 50]
print(f"Reviews shorter than 50 chars: {len(short_reviews)}")

# Check for very long reviews
long_reviews = df[df['review'].str.len() > 5000]
print(f"Reviews longer than 5000 chars: {len(long_reviews)}")

# Sample a very short review
if len(short_reviews) > 0:
    print(f"\nSample short review: {short_reviews['review'].iloc[0]}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: PROGRAMMATIC ASSESSMENT
# ═══════════════════════════════════════════════════════════════════════════════

**Programmatic Assessment**: Uses code or automated tools to assess and profile data.

```python
# ============================================
# PROGRAMMATIC ASSESSMENT
# ============================================

import pandas as pd
import numpy as np

# 1. Basic Statistics
print("=" * 60)
print("BASIC STATISTICS:")
print("=" * 60)

print(f"\nDataset Shape: {df.shape}")
print(f"Total Reviews: {len(df)}")
print(f"Columns: {df.columns.tolist()}")

# Data types
print(f"\nData Types:")
print(df.dtypes)

# 2. Missing Values Check
print("\n" + "=" * 60)
print("MISSING VALUES:")
print("=" * 60)

missing = df.isnull().sum()
missing_percent = (df.isnull().sum() / len(df)) * 100
missing_df = pd.DataFrame({
    'Missing Count': missing,
    'Missing Percent': missing_percent
})
print(missing_df)

# 3. Duplicate Check
print("\n" + "=" * 60)
print("DUPLICATES:")
print("=" * 60)

duplicates = df.duplicated().sum()
print(f"Total duplicates: {duplicates}")
print(f"Duplicate percentage: {(duplicates/len(df))*100:.2f}%")

# Check duplicate reviews only
duplicate_reviews = df['review'].duplicated().sum()
print(f"Duplicate reviews: {duplicate_reviews}")

# 4. Class Distribution
print("\n" + "=" * 60)
print("CLASS DISTRIBUTION:")
print("=" * 60)

class_dist = df['sentiment'].value_counts()
class_percent = df['sentiment'].value_counts(normalize=True) * 100
class_df = pd.DataFrame({
    'Count': class_dist,
    'Percentage': class_percent
})
print(class_df)

# 5. Text Length Analysis
print("\n" + "=" * 60)
print("TEXT LENGTH ANALYSIS:")
print("=" * 60)

df['review_length'] = df['review'].apply(len)
df['word_count'] = df['review'].apply(lambda x: len(x.split()))

print(f"\nCharacter Length Statistics:")
print(df['review_length'].describe())

print(f"\nWord Count Statistics:")
print(df['word_count'].describe())

# 6. Identify Outliers
print("\n" + "=" * 60)
print("OUTLIERS:")
print("=" * 60)

# Using IQR method for word count
Q1 = df['word_count'].quantile(0.25)
Q3 = df['word_count'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

outliers = df[(df['word_count'] < lower_bound) | (df['word_count'] > upper_bound)]
print(f"Word count outliers: {len(outliers)} ({(len(outliers)/len(df))*100:.2f}%)")
print(f"Lower bound: {lower_bound:.0f} words")
print(f"Upper bound: {upper_bound:.0f} words")

# 7. Check for HTML tags
print("\n" + "=" * 60)
print("HTML TAGS CHECK:")
print("=" * 60)

html_pattern = r'<[^>]+>'
html_reviews = df['review'].str.contains(html_pattern, regex=True).sum()
print(f"Reviews with HTML tags: {html_reviews}")

# 8. Check for URLs
print("\n" + "=" * 60)
print("URL CHECK:")
print("=" * 60)

url_pattern = r'https?://\S+'
url_reviews = df['review'].str.contains(url_pattern, regex=True).sum()
print(f"Reviews with URLs: {url_reviews}")

# 9. Summary Report
print("\n" + "=" * 60)
print("ASSESSMENT SUMMARY:")
print("=" * 60)

print(f"""
Dataset: IMDB Movie Reviews
Total Samples: {len(df)}
Features: {len(df.columns)}
Target Variable: sentiment (binary)

Quality Issues Found:
- Missing Values: {df.isnull().sum().sum()}
- Duplicates: {duplicates}
- HTML Tags: {html_reviews} reviews
- URLs: {url_reviews} reviews
- Short Reviews (<50 chars): {len(short_reviews)}
- Outliers (word count): {len(outliers)}

Class Balance:
- Positive: {class_dist.get('positive', 0)} ({class_percent.get('positive', 0):.1f}%)
- Negative: {class_dist.get('negative', 0)} ({class_percent.get('negative', 0):.1f}%)

Text Statistics:
- Avg words per review: {df['word_count'].mean():.0f}
- Min words: {df['word_count'].min()}
- Max words: {df['word_count'].max()}
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: EXPLORATORY DATA ANALYSIS (EDA)
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# EXPLORATORY DATA ANALYSIS
# ============================================

import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import re

# Set style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("husl")

# Create figure for multiple plots
fig = plt.figure(figsize=(16, 20))

# ----------------------------------------
# 1. Class Distribution
# ----------------------------------------
ax1 = fig.add_subplot(3, 2, 1)
colors = ['#2ecc71', '#e74c3c']
df['sentiment'].value_counts().plot(kind='bar', ax=ax1, color=colors)
ax1.set_title('Class Distribution', fontsize=14, fontweight='bold')
ax1.set_xlabel('Sentiment')
ax1.set_ylabel('Count')
ax1.tick_params(axis='x', rotation=0)

# Add count labels on bars
for i, v in enumerate(df['sentiment'].value_counts()):
    ax1.text(i, v + 200, str(v), ha='center', fontweight='bold')

# ----------------------------------------
# 2. Review Length Distribution
# ----------------------------------------
ax2 = fig.add_subplot(3, 2, 2)
df['review_length'].hist(bins=50, ax=ax2, color='#3498db', edgecolor='white')
ax2.set_title('Review Length Distribution (Characters)', fontsize=14, fontweight='bold')
ax2.set_xlabel('Number of Characters')
ax2.set_ylabel('Frequency')
ax2.axvline(df['review_length'].mean(), color='red', linestyle='--', label=f'Mean: {df["review_length"].mean():.0f}')
ax2.legend()

# ----------------------------------------
# 3. Word Count Distribution
# ----------------------------------------
ax3 = fig.add_subplot(3, 2, 3)
df['word_count'].hist(bins=50, ax=ax3, color='#9b59b6', edgecolor='white')
ax3.set_title('Word Count Distribution', fontsize=14, fontweight='bold')
ax3.set_xlabel('Number of Words')
ax3.set_ylabel('Frequency')
ax3.axvline(df['word_count'].mean(), color='red', linestyle='--', label=f'Mean: {df["word_count"].mean():.0f}')
ax3.legend()

# ----------------------------------------
# 4. Word Count by Sentiment
# ----------------------------------------
ax4 = fig.add_subplot(3, 2, 4)
df.boxplot(column='word_count', by='sentiment', ax=ax4)
ax4.set_title('Word Count by Sentiment', fontsize=14, fontweight='bold')
ax4.set_xlabel('Sentiment')
ax4.set_ylabel('Word Count')
plt.suptitle('')  # Remove automatic title

# ----------------------------------------
# 5. Review Length by Sentiment (Violin Plot)
# ----------------------------------------
ax5 = fig.add_subplot(3, 2, 5)
sns.violinplot(x='sentiment', y='word_count', data=df, ax=ax5, palette=colors)
ax5.set_title('Word Count Distribution by Sentiment', fontsize=14, fontweight='bold')
ax5.set_xlabel('Sentiment')
ax5.set_ylabel('Word Count')

# ----------------------------------------
# 6. Sentiment Percentage (Pie Chart)
# ----------------------------------------
ax6 = fig.add_subplot(3, 2, 6)
df['sentiment'].value_counts().plot(kind='pie', ax=ax6, autopct='%1.1f%%', 
                                      colors=colors, explode=[0.02, 0.02])
ax6.set_title('Sentiment Distribution', fontsize=14, fontweight='bold')
ax6.set_ylabel('')

plt.tight_layout()
plt.savefig('data/eda_overview.png', dpi=300, bbox_inches='tight')
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: WORD FREQUENCY ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# WORD FREQUENCY ANALYSIS
# ============================================

from collections import Counter
import re

def simple_tokenize(text):
    """Simple tokenization - lowercase and split"""
    text = text.lower()
    text = re.sub(r'[^a-z\s]', '', text)  # Keep only letters and spaces
    return text.split()

# Tokenize all reviews
all_words = []
positive_words = []
negative_words = []

for idx, row in df.iterrows():
    words = simple_tokenize(row['review'])
    all_words.extend(words)
    
    if row['sentiment'] == 'positive':
        positive_words.extend(words)
    else:
        negative_words.extend(words)

# Count frequencies
all_word_freq = Counter(all_words)
positive_word_freq = Counter(positive_words)
negative_word_freq = Counter(negative_words)

# Display top words
print("=" * 60)
print("TOP 20 MOST COMMON WORDS (Overall):")
print("=" * 60)
for word, count in all_word_freq.most_common(20):
    print(f"{word}: {count}")

print("\n" + "=" * 60)
print("TOP 20 MOST COMMON WORDS (Positive Reviews):")
print("=" * 60)
for word, count in positive_word_freq.most_common(20):
    print(f"{word}: {count}")

print("\n" + "=" * 60)
print("TOP 20 MOST COMMON WORDS (Negative Reviews):")
print("=" * 60)
for word, count in negative_word_freq.most_common(20):
    print(f"{word}: {count}")

# ----------------------------------------
# Plot Word Frequencies
# ----------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

# Overall
words, counts = zip(*all_word_freq.most_common(15))
axes[0].barh(list(reversed(words)), list(reversed(counts)), color='#3498db')
axes[0].set_title('Top 15 Words (Overall)', fontsize=12, fontweight='bold')
axes[0].set_xlabel('Frequency')

# Positive
words, counts = zip(*positive_word_freq.most_common(15))
axes[1].barh(list(reversed(words)), list(reversed(counts)), color='#2ecc71')
axes[1].set_title('Top 15 Words (Positive)', fontsize=12, fontweight='bold')
axes[1].set_xlabel('Frequency')

# Negative
words, counts = zip(*negative_word_freq.most_common(15))
axes[2].barh(list(reversed(words)), list(reversed(counts)), color='#e74c3c')
axes[2].set_title('Top 15 Words (Negative)', fontsize=12, fontweight='bold')
axes[2].set_xlabel('Frequency')

plt.tight_layout()
plt.savefig('data/word_frequency.png', dpi=300, bbox_inches='tight')
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: WORD CLOUDS
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# WORD CLOUDS
# ============================================

from wordcloud import WordCloud

# Define stopwords (common words to exclude)
stopwords = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
             'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
             'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
             'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare', 'it',
             'its', 'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'we',
             'they', 'what', 'which', 'who', 'whom', 'when', 'where', 'why', 'how',
             'all', 'each', 'every', 'both', 'few', 'more', 'most', 'other', 'some',
             'such', 'no', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very',
             'just', 'br', 'movie', 'film', 'one', 'also', 'see', 'time', 'really'}

# Combine all reviews by sentiment
positive_text = ' '.join(df[df['sentiment'] == 'positive']['review'].tolist())
negative_text = ' '.join(df[df['sentiment'] == 'negative']['review'].tolist())

# Create word clouds
fig, axes = plt.subplots(1, 2, figsize=(16, 8))

# Positive Word Cloud
wordcloud_pos = WordCloud(width=800, height=400, 
                          background_color='white',
                          stopwords=stopwords,
                          colormap='Greens',
                          max_words=100).generate(positive_text)
axes[0].imshow(wordcloud_pos, interpolation='bilinear')
axes[0].set_title('Positive Reviews Word Cloud', fontsize=16, fontweight='bold')
axes[0].axis('off')

# Negative Word Cloud
wordcloud_neg = WordCloud(width=800, height=400,
                          background_color='white',
                          stopwords=stopwords,
                          colormap='Reds',
                          max_words=100).generate(negative_text)
axes[1].imshow(wordcloud_neg, interpolation='bilinear')
axes[1].set_title('Negative Reviews Word Cloud', fontsize=16, fontweight='bold')
axes[1].axis('off')

plt.tight_layout()
plt.savefig('data/wordclouds.png', dpi=300, bbox_inches='tight')
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8: DATA STORYTELLING
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# DATA STORYTELLING - Final Summary
# ============================================

print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    IMDB MOVIE REVIEW DATASET - EDA SUMMARY                   ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  📊 DATASET OVERVIEW                                                         ║
║  ─────────────────────────────────────────────────────────────────────────── ║
║  • Total Reviews: 50,000                                                     ║
║  • Positive Reviews: 25,000 (50%)                                            ║
║  • Negative Reviews: 25,000 (50%)                                            ║
║  • Dataset is PERFECTLY BALANCED ✓                                           ║
║                                                                              ║
║  📝 TEXT CHARACTERISTICS                                                     ║
║  ─────────────────────────────────────────────────────────────────────────── ║
║  • Average words per review: ~230                                            ║
║  • Shortest review: ~10 words                                                ║
║  • Longest review: ~2,500 words                                              ║
║  • Most reviews: 100-400 words                                               ║
║                                                                              ║
║  🔍 QUALITY ISSUES FOUND                                                     ║
║  ─────────────────────────────────────────────────────────────────────────── ║
║  • HTML tags present (e.g., <br />) - Need removal                           ║
║  • Some URLs present - Need removal                                          ║
║  • Special characters - Need handling                                        ║
║  • No significant missing values ✓                                           ║
║                                                                              ║
║  💡 KEY INSIGHTS                                                             ║
║  ─────────────────────────────────────────────────────────────────────────── ║
║  • Positive reviews tend to use: great, good, best, love, well               ║
║  • Negative reviews tend to use: bad, worst, waste, boring, poor             ║
║  • Review length similar across sentiments                                   ║
║  • Dataset ready for modeling after preprocessing                            ║
║                                                                              ║
║  📋 NEXT STEPS                                                               ║
║  ─────────────────────────────────────────────────────────────────────────── ║
║  1. Text Preprocessing (PHASE 7-8)                                           ║
║  2. Feature Engineering                                                      ║
║  3. Model Building (PHASE 2-7)                                               ║
║  4. Deployment (PHASE 10)                                                    ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 9: SAVE PROCESSED DATA
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# SAVE DATA FOR NEXT PHASES
# ============================================

# Add computed columns
df['review_length'] = df['review'].apply(len)
df['word_count'] = df['review'].apply(lambda x: len(x.split()))

# Convert sentiment to binary
df['label'] = df['sentiment'].map({'positive': 1, 'negative': 0})

# Save processed data
df.to_csv('data/processed/imdb_with_features.csv', index=False)

print("Data saved to: data/processed/imdb_with_features.csv")
print(f"Columns: {df.columns.tolist()}")
print(f"Shape: {df.shape}")

# Create train/test split for later use
from sklearn.model_selection import train_test_split

X = df['review']
y = df['label']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"\nTrain size: {len(X_train)}")
print(f"Test size: {len(X_test)}")

# Save splits
train_df = pd.DataFrame({'review': X_train, 'label': y_train})
test_df = pd.DataFrame({'review': X_test, 'label': y_test})

train_df.to_csv('data/processed/train.csv', index=False)
test_df.to_csv('data/processed/test.csv', index=False)

print("\nTrain/Test splits saved!")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 1 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ Data Acquisition
   └── Downloaded IMDB dataset (50,000 reviews)

✅ Manual Assessment
   └── Visually inspected samples
   └── Checked for obvious issues

✅ Programmatic Assessment
   └── Checked missing values
   └── Checked duplicates
   └── Checked class distribution
   └── Analyzed text lengths
   └── Identified outliers
   └── Checked for HTML/URLs

✅ Exploratory Data Analysis
   └── Class distribution plots
   └── Text length distributions
   └── Word count analysis
   └── Violin/Box plots by sentiment

✅ Data Visualization
   └── Word frequency charts
   └── Word clouds (positive/negative)
   └── Summary statistics

✅ Data Saved
   └── Processed CSV with features
   └── Train/Test splits created
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# READY FOR PHASE 2: MACHINE LEARNING
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# LEVEL 1: BASICS - DEEP LEARNING FOUNDATIONS
# Complete Verbatim Content from DataScienceCourseMaterial Repository
# ═══════════════════════════════════════════════════════════════════════════════

**Why LEVEL 1 First:** These are the fundamental building blocks. You CANNOT understand CNN, RNN, LSTM, Transformers, or any NLP model without first understanding these concepts. Every neural network is built on these foundations.

---

# RESOURCE LINKS

* **[Full Complete Everything Roadmap for Data Science](https://github.com/SamBelkacem/AI-ML-cheatsheets)**
* **[100days Ml by xcampus hands on experience](https://github.com/campusx-official/100-days-of-machine-learning/blob/main/day18-pandas-dataframe-using-web-scraping/day18.ipynb)**
* **[Course for Absolute beginers Website](https://jovian.com/learn/data-analysis-with-python-zero-to-pandas), [YouTube Channel](https://www.youtube.com/@jovianhq/playlists)**
* **[Overview of Data Science](https://www.linkedin.com/pulse/data-science-methodology-step-by-step-guide-uzair-azmat-5tekf/?trackingId=DOxr4vPTsiNgGbFTdDijoQ%3D%3D)**
* **[General Concepts](https://www.linkedin.com/pulse/complete-data-analysis-guide-python-uzair-azmat-uavvf/?trackingId=QNtfgWzo5XW04hwg3EPwUQ%3D%3D)**
* **[ML algorithms overview](https://media.licdn.com/dms/image/v2/D5622AQFM4BFXG2EbIg/feedshare-shrink_1280/B56ZZdEfgOHUAk-/0/1745318186007?e=1748476800&v=beta&t=woqQgZYUSOvDxL52W7WS0ic3l5ZCE8o67SK4ZRpx1hw), [ML Algorithms regressions](https://www.youtube.com/watch?v=UZPfbG0jNec&list=PLKnIA16_Rmva-wY_HBh1gTH32ocu2SoTr), [ML Algorithms Gradient Descent](https://www.youtube.com/watch?v=ORyfPJypKuU&list=PLKnIA16_RmvZvBbJex7T84XYRmor3IPK1), [Gradient Boosting](https://www.youtube.com/watch?v=fbKz7N92mhQ&list=PLKnIA16_RmvaMPgWfHnN4MXl3qQ1597Jw) ,[Logsitic Regression](https://www.youtube.com/watch?v=XNXzVfItWGY&list=PLKnIA16_Rmvb-ZTsM1QS-tlwmlkeGSnru), [PCA](https://www.youtube.com/watch?v=ToGuhynu-No&list=PLKnIA16_RmvYHW62E_lGQa0EFsph2NquD), [Random Forest](https://www.youtube.com/watch?v=ToGuhynu-No&list=PLKnIA16_RmvYHW62E_lGQa0EFsph2NquD),[Adaboost](https://www.youtube.com/watch?v=sFKnP0iP0K0&list=PLKnIA16_RmvZxriy68dPZhorB8LXP1PY6),[XgBoost](https://www.youtube.com/watch?v=BTLB-ppqBZc&list=PLKnIA16_RmvbXJbBW4zCy4Xbr81GRyaC4), [Kmeans Clustering](https://www.youtube.com/watch?v=5shTLzwAdEc&list=PLKnIA16_RmvbA_hYXlRgdCg9bn8ZQK2z9),[Bagging ensemble](https://www.youtube.com/watch?v=LUiBOAy7x6Y&list=PLKnIA16_RmvZ7iKIcJrLjUoFDEeSejRpn)**
* **[Time Series Analysis](https://www.youtube.com/watch?v=A3fowDMo8mM)**

---

# PROMPT TEMPLATE FOR DEEP LEARNING

```
> **"Provide an in-depth explanation of \[TOPIC] covering the following aspects:**
>
> 1. **Motivation**: What problem does it solve? What limitations or challenges in earlier methods led to the development of this approach?
>
> 2. **Origin**: Who proposed it, and in what paper or context (if applicable)?
>
> 3. **High-Level Overview**: Describe the concept at a top level in simple, clear terms before going into the internal structure.
>
> 4. **Subcomponents & Architecture**: Break the topic into its core components or modules. For each component:
>
>    * What does it do functionally?
>    * What are the inputs/outputs and how does it interact with other components?
>    * Include **training-time behavior** vs **inference-time behavior**.
>
> 5. **Mathematical Intuition**:
>
>    * Explain the **formulas and calculations** (e.g., attention scores, probabilities, distributions, gradients).
>    * Clarify what is being computed (e.g. μ, σ, dot products, softmax, etc.).
>
> 6. **Geometric Intuition**:
>
>    * Use spatial analogies (e.g., projection, similarity in vector space, transformations) to explain how the algorithm behaves in high-dimensional geometry.
>
> 7. **Inner Workings**: Describe how the method operates step-by-step in both training and inference phases.
>
> 8. **Related Techniques**:
>
>    * Mention variations, extensions, or alternative methods.
>    * Compare with older or parallel approaches in terms of efficiency, expressiveness, scalability, and interpretability.
>
> 9. **Pros and Cons**:
>
>    * Strengths and ideal use cases.
>    * Weaknesses, trade-offs, or assumptions.
>
> 10. **Real-World Applications**:
>
>     * Where is it used in industry or research?
>     * Any notable systems or tools that implement it.
>
> 11. **(Optional) Code Snippets or Diagrams**:
>
>     * Include pseudocode, Python code (e.g., PyTorch, TensorFlow), or visual diagrams for better clarity."
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 1: THE PERCEPTRON
# ═══════════════════════════════════════════════════════════════════════════════

**Why Perceptron is FIRST:** The perceptron is the simplest unit of a neural network - like an atom in chemistry. Every neural network (MLP, CNN, RNN, LSTM, Transformer) is built from perceptrons. You cannot understand anything else without understanding this first.

---

The perceptron is a fundamental building block of neural networks. It was initially designed for binary classification, but the concept has evolved and can be adapted for both classification and regression problems by pairing it with appropriate activation functions and error (loss) functions.

---

## Perceptron Implementation

in percetpron,it is similar to the multiple regression which try to find out the hyperplane to predict the values,there are 2 ways to implement it,one is perceptron trick in which we try to push or pull the line towards +ve region or -ve region by subtracting the the data points from the old points for getting the new weight we repeat this untill covnergience occured mean algo furthere dont make mistake,and this is done inside the loop ,we do two condtions to handle this+ve and -ve region but there is also issue here jumps ,to overcome the jumps we now subtract the along with the learning rate to move slowly,but there is also anothere approach whcih is better than this approach in which we use the actual value and predicted values along with the learning rate in which we do the precision or recall and on this base we do update the value or to get the new weight.this is the overall view of this way.

---

**Summary of Two Approaches:**

1. **Perceptron Trick**: 
   - Push or pull the line towards +ve region or -ve region
   - Subtract data points from old points for getting new weight
   - Repeat until convergence (algo further don't make mistake)
   - Done inside the loop
   - Two conditions to handle +ve and -ve region
   - Issue: jumps
   - Solution: subtract along with learning rate to move slowly

2. **Better Approach**:
   - Use actual value and predicted values along with learning rate
   - Do precision or recall
   - On this base update the value or get new weight

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 2: MULTI-LAYER PERCEPTRON (MLP)
# ═══════════════════════════════════════════════════════════════════════════════

**Why MLP comes after Perceptron:** MLP is simply multiple perceptrons stacked together. The output of one perceptron becomes input to the next. This is where "deep" learning begins.

---

**MLP**: it is similar to the perceptron in which we calculate by using input feature and weight and then we passed to the sigmoid function and get the output, but here in MLP the output of each perceptrons again multiplied with weight and by taking summation of them and then passed to the next node and hence at the end final layer the output is passed to the sigmoid for output.

---

## Multiple Perceptron Notations

actually here in the below image here we are tring to calcualte weights and bias and number of trainable paramters

**Notation**: `wijk, oij, bij` --> here b is the bias and i is the number of layer and j is the position of the node in this layer and in weight, k is denoting that in which layer weight is entering, i.e. w142 here 1 mean in which layer it is entering and 2 mean node of this layer, 4 mean from which previous layer node it is coming

---

**Understanding the Notation:**
- `wijk` = Weight notation
  - `i` = which layer the weight is entering
  - `j` = position of node in this layer
  - `k` = from which previous layer node it is coming
- `oij` = Output notation
  - `i` = layer number
  - `j` = node position
- `bij` = Bias notation
  - `i` = layer number
  - `j` = node position

**Example**: w142
- 1 = layer it is entering
- 4 = node of previous layer it's coming from
- 2 = node of this layer

---

## Calculating Trainable Parameters

For each layer: **(inputs × outputs) + outputs**

Where:
- inputs × outputs = number of weights
- outputs = number of biases

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 3: TYPES OF MODELS IN KERAS
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** Now that we understand perceptrons and MLPs, we need to know HOW to build them in code. Keras provides two ways.

---

**Types of Models**

**functional api model** in keras basically is used for non-linear multiple dtypes or input and multiple outputs in whcih we hve multiple branch each branch is representign the specific input and output ,also we can concatenate the multiple branches to predict one output .also we can use the transfer learning in it.this was the overview of functional api model and othere one is sequential model.

---

**Summary:**

1. **Functional API Model**:
   - Used for non-linear architectures
   - Multiple data types or inputs
   - Multiple outputs
   - Multiple branches (each branch representing specific input and output)
   - Can concatenate multiple branches to predict one output
   - Can use transfer learning

2. **Sequential Model**:
   - Used for linear architectures
   - Simple stack of layers
   - One input, one output

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 4: LOSS FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

**Why Loss Functions come here:** After we have a network that can make predictions, we need to measure HOW WRONG the predictions are. Loss functions quantify this error. This is essential for learning.

---

**Loss Functions**: if we are dealing with the ***regression problems***-->use MSE,but if there are outliers use MAE. ***Classification Problems*** we use binary cross entropy(bce) for binary classification,for multiple classifications we use cross categorical entropy(cce) for 3 classification in it we have to calcualte the log for each category,sparse cross entropy(sce) for many categories but here for them we calculate for only one category.

---

## Regression Problems

| Problem Type | Loss Function | When to Use |
|--------------|---------------|-------------|
| Regression | **MSE** (Mean Squared Error) | Default for regression |
| Regression with outliers | **MAE** (Mean Absolute Error) | When there are outliers |

---

## Classification Problems

| Problem Type | Loss Function | Description |
|--------------|---------------|-------------|
| Binary Classification | **BCE** (Binary Cross Entropy) | For 2 classes (0 or 1) |
| Multi-class Classification | **CCE** (Categorical Cross Entropy) | For 3+ categories, calculate log for EACH category |
| Many Categories | **SCE** (Sparse Categorical Cross Entropy) | For many categories, calculate for only ONE category |

---

**Key Difference between CCE and SCE:**
- **CCE**: Calculate log for EACH category (requires one-hot encoded labels)
- **SCE**: Calculate for only ONE category (uses integer labels directly)

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 5: FORWARD PROPAGATION
# ═══════════════════════════════════════════════════════════════════════════════

**Why Forward Propagation comes here:** Before we can minimize the loss, we need to understand how data flows through the network to PRODUCE predictions. Forward propagation is the prediction process.

---

**Forward Propagation**: in it we taek teh dot product of weights and the output of the perceptron or neuron from the layer and add the biases and we do this repeatedly for all layers and at the end we get the number which is our result ,this is straight forward so we call it forward propagation.

---

## Step-by-Step Process:

1. Take the **dot product** of weights and output of neuron from previous layer
2. **Add the biases**
3. **Repeat** for all layers
4. At the end, get the final number (result/prediction)

**Why called "forward":** It's straightforward - data flows in one direction from input to output.

---

## Mathematical Formula:

For each layer:
```
z = W · a_prev + b
a = f(z)
```

Where:
- `z` = weighted sum (pre-activation)
- `W` = weights matrix
- `a_prev` = activations from previous layer
- `b` = bias vector
- `f(z)` = activation function
- `a` = output activations

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 6: BACKPROPAGATION
# ═══════════════════════════════════════════════════════════════════════════════

**Why Backpropagation comes after Forward Propagation:** Now that we know how to make predictions and measure error, we need to figure out how to IMPROVE. Backpropagation calculates how much each weight contributed to the error.

---

**BackPropagation**: in this image we have to minimize the loss function and for this we have to minimize the predicted value since we cant chagne the actual value,and our predicted value is basically the output of final neuron or we can say y^=O21,which is again the combination of previous things like weights,bias and neurons and again these neurons are also combination of the previous things ,so overall if we want to adjust the weight and bias to minimize the loss function we have to go to back by minimizing those things mean weights and biases using gradient descent or we also call the gradient descent the partial derivative,this is what we say backpropagation.

---

## Understanding Backpropagation:

1. **Goal**: Minimize the loss function

2. **Problem**: We can't change actual values, only predicted values

3. **Predicted value** (ŷ = O21) is combination of:
   - Weights
   - Biases
   - Neurons (which are also combinations of weights, biases, neurons)

4. **Solution**: Go BACKWARD through the network
   - Adjust weights and biases
   - Use gradient descent (partial derivatives)
   - Minimize loss by minimizing these components

**This is why we call it BACKPROPAGATION** - we propagate the error BACK through the network.

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 7: DERIVATIVE AND CHAIN RULE
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** To do backpropagation, we need to understand derivatives and the chain rule. This is the mathematical foundation.

---

**Derivative**: what is thsi mean,actually in it we calculate the change by changing in one and seeing in other,i.e. delta L/delta W ,thsi shows that change in weight how much reflection in Loss. but this is not directly calculate the change or derivative of ***delta L/delta W=delta L/delta y^ x delta y^/delta W***, but indirectly it reflects by calculating the dependent factors first then we can calculate them as in thsi image we can see first we have to calculate the the y^ over weight (mean changing in weights how much change in y^ and so thus change in y^ how much change occur in loss) and then through thsi we will calculate loss over y^.thsi is how **chainging Rule works**.

---

## Understanding Derivative:

**What is derivative?**
- Calculate the change by changing in one variable and seeing the effect in another
- Example: `∂L/∂W` shows how much change in Weight reflects in Loss

---

## The Chain Rule:

**Formula:**
```
∂L/∂W = (∂L/∂ŷ) × (∂ŷ/∂W)
```

**Why Chain Rule?**
- We can NOT directly calculate `∂L/∂W`
- We must calculate the DEPENDENT FACTORS first:
  1. First calculate: `∂ŷ/∂W` (changing in weights → how much change in ŷ)
  2. Then calculate: `∂L/∂ŷ` (change in ŷ → how much change in Loss)
  3. Multiply them together

---

## How We Calculate the Derivative:

***How we calcualte teh derivative***: for this we put the values of the given variables like y^ and W and then by solvig those values we will finally get the derivative results.

**Process:**
1. Put the values of given variables (like ŷ and W)
2. Solve those values
3. Finally get the derivative results

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 8: DERIVATIVE VS GRADIENT
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** Important distinction - derivative is for one variable, gradient is for multiple variables. Neural networks have MANY variables (weights), so we use gradients.

---

**Derivative vs Gradient**: if we do calculate the chagne with respect to one variable then we say it is derivative and if we have multiple variables and then we calcualte the derivatives using del or partial derivative for each variable then we say it is Gradient.

---

## Key Difference:

| Concept | Variables | Description |
|---------|-----------|-------------|
| **Derivative** | ONE variable | Calculate change with respect to ONE variable |
| **Gradient** | MULTIPLE variables | Calculate partial derivatives for EACH variable |

---

**Gradient** = Vector of all partial derivatives

```
∇L = [∂L/∂w1, ∂L/∂w2, ∂L/∂w3, ..., ∂L/∂wn]
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 9: MEMOIZATION IN BACKPROPAGATION
# ═══════════════════════════════════════════════════════════════════════════════

**Why Memoization comes here:** Backpropagation involves calculating many derivatives. Memoization makes this EFFICIENT by storing and reusing calculations.

---

**Memoization** whcih is basically store the calculation of derivatived result for other neuron entering or path,mean if we calcuate the derivative for one path of the neuron ,since multiple inputs are being passed to the next neurons and hence we have multiple paths or inputs and we have to calcualte the derivative for each path here we can use the memoization concept as it store the result of once path calculated derivative for the other path which has the same input just with differnt weight.

---

## Understanding Memoization:

**What is it?**
- Store the calculation of derivative results for other neuron paths

**Why needed?**
- Multiple inputs are passed to next neurons
- We have multiple paths or inputs
- We have to calculate derivative for EACH path

**How it helps:**
- Calculate derivative for one path
- STORE the result
- REUSE the stored result for other paths that have:
  - Same input
  - Different weight

**Without memoization:** Recalculate same derivatives many times (inefficient)
**With memoization:** Calculate once, reuse many times (efficient)

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 10: SGD VS BGD (GRADIENT DESCENT VARIANTS)
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** Gradient descent tells us HOW MUCH to adjust weights. Different variants trade off speed vs accuracy.

---

**SGD vs BGD**: in sgd weights updated at each epocs or row and in bgd the weights are updated after complete visiting the batch ,and hence weights will be updated of this current batch upto the number of epochs.

---

## Comparison:

| Aspect | SGD (Stochastic Gradient Descent) | BGD (Batch Gradient Descent) |
|--------|-----------------------------------|------------------------------|
| **When weights updated** | At each epoch/row | After complete batch |
| **Frequency** | After every single data point | After all data points in batch |
| **Speed** | Faster updates | Slower updates |
| **Stability** | More noisy | More stable |
| **Memory** | Less memory | More memory |

---

## Visual Understanding:

**SGD:**
```
Data point 1 → Update weights
Data point 2 → Update weights
Data point 3 → Update weights
...
```

**BGD:**
```
Data point 1 → 
Data point 2 →  Process entire batch
Data point 3 →
...
Data point n → Update weights (once)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 11: WAYS TO SOLVE OVERFITTING
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** After learning how to train neural networks, we need to know how to prevent them from memorizing training data instead of learning patterns.

---

## Overfitting Solutions:

1. **Early Stopping** - Stop training when validation loss starts increasing

2. **Dropout** - Randomly "drop" neurons during training

3. **Regularization**:
   - **L1 Regularization** (Lasso) - Adds absolute value of weights to loss
   - **L2 Regularization** (Ridge) - Adds squared weights to loss

4. **Data Augmentation** - Create more training data by transforming existing data

5. **Cross-Validation** - Validate on different subsets of data

6. **Reduce Model Complexity** - Use fewer layers/neurons

---

# ═══════════════════════════════════════════════════════════════════════════════
# LEARNING SEQUENCE FOR LEVEL 1
# ═══════════════════════════════════════════════════════════════════════════════

```
LEVEL 1: DEEP LEARNING FOUNDATIONS
══════════════════════════════════

Section 1:  Perceptron (the atom of neural networks)
                ↓
Section 2:  MLP (stack perceptrons into layers)
                ↓
Section 3:  Types of Models in Keras (how to build in code)
                ↓
Section 4:  Loss Functions (measure how wrong predictions are)
                ↓
Section 5:  Forward Propagation (make predictions)
                ↓
Section 6:  Backpropagation (learn from errors)
                ↓
Section 7:  Derivative and Chain Rule (the math behind backprop)
                ↓
Section 8:  Derivative vs Gradient (one variable vs many)
                ↓
Section 9:  Memoization (make backprop efficient)
                ↓
Section 10: SGD vs BGD (how to update weights)
                ↓
Section 11: Overfitting Solutions (prevent memorization)

══════════════════════════════════
LEVEL 1 COMPLETE - READY FOR LEVEL 2
══════════════════════════════════
```

---

# WHAT'S NEXT?

**LEVEL 2: CONVOLUTIONAL NEURAL NETWORKS (CNN)**
- ANN vs CNN
- CNN Architecture
- Backpropagation in CNN
- Transfer Learning
- Keras ImageDataGenerator

**LEVEL 3: RECURRENT NEURAL NETWORKS (RNN Family)**
- RNN (Why, How, Architectures)
- LSTM (Gates, Cell State)
- GRU (Simplified LSTM)
- Stacked and Bidirectional

**LEVEL 4: SEQUENCE-TO-SEQUENCE & ATTENTION**
- Seq2Seq Model
- Attention Mechanism (Bahdanau, Luong)
- Self-Attention
- Transformers

**LEVEL 5: NLP APPLICATIONS**
- NLP Introduction
- NLP Pipelines
- Preprocessing
- Text Representation (BoW, N-grams, TF-IDF)
- Word2Vec
- POS Tagging
- Text Classification
- End-to-End Project

---

*This is LEVEL 1 containing ALL verbatim content from the repository for Deep Learning Foundations. Each concept builds on the previous one.*

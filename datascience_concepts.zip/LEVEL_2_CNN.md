# ═══════════════════════════════════════════════════════════════════════════════
# LEVEL 2: CONVOLUTIONAL NEURAL NETWORKS (CNN)
# Complete Verbatim Content from DataScienceCourseMaterial Repository
# ═══════════════════════════════════════════════════════════════════════════════

**Prerequisites:** Complete LEVEL 1 (Perceptron, MLP, Forward/Backward Propagation, Loss Functions, Gradient Descent)

**Why LEVEL 2 Now:** CNNs use the SAME principles from LEVEL 1 (forward prop, backprop, loss, activation) but add CONVOLUTION operations. CNNs are specialized for grid-like data (images). Understanding LEVEL 1 first makes CNN architecture intuitive.

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 1: ANN VS CNN
# ═══════════════════════════════════════════════════════════════════════════════

**Why this is FIRST in CNN:** Before learning CNN, you need to understand HOW it differs from ANN (what we learned in LEVEL 1). This comparison shows why CNN exists and what problem it solves.

---

In **ANN** we calculate the dot product of input with weights and it is **dependent on input** that's why it's more computational than CNN and the data dtype in it is used is **tabular type data**.

While **CNN** is similar to the ANN but there is little bit difference it calculate the dot product or convolution by sliding filter on input image and it is **independent of input** that is why it is less computational and is used for the image processing and the data is used in it is **grid type data** such as images.

---

## Comparison Table:

| Aspect | ANN | CNN |
|--------|-----|-----|
| **Calculation** | Dot product of input with weights | Dot product/convolution by sliding filter on image |
| **Dependency** | DEPENDENT on input | INDEPENDENT of input |
| **Computation** | More computational | Less computational |
| **Data Type** | Tabular type data | Grid type data (images) |
| **Use Case** | General purpose | Image processing |

---

## Key Insight:

- **ANN**: Every input is connected to every neuron (fully connected) → Computation grows with input size
- **CNN**: Filter slides across input → Same filter reused → Computation independent of input size

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 2: HOW TO MAKE THE ARCHITECTURE OF CNN
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** After understanding the difference, we need to know HOW to build a CNN architecture.

---

**How to Make the Architechure of CNN**: in it we do it in three ways:
1. diagrams of layers
2. logical flow of the architechure
3. equations for the architechure

---

## Three Ways to Represent CNN Architecture:

### 1. Diagrams of Layers
- Visual representation
- Shows layer connections
- Easy to understand at a glance

### 2. Logical Flow of the Architecture
- Step-by-step process
- Input → Convolution → Pooling → Flatten → Dense → Output
- Shows data transformation

### 3. Equations for the Architecture
- Mathematical representation
- Precise calculations
- Used for implementation

---

## Typical CNN Flow:

```
Input Image
    ↓
Convolution Layer (extract features)
    ↓
Activation Function (ReLU)
    ↓
Pooling Layer (reduce dimensions)
    ↓
[Repeat Convolution + Pooling]
    ↓
Flatten Layer (convert to 1D)
    ↓
Dense/Fully Connected Layer
    ↓
Output Layer
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 3: BACKPROPAGATION IN CNN
# ═══════════════════════════════════════════════════════════════════════════════

**Why this comes here:** We learned backpropagation in LEVEL 1. Now we need to understand how it works specifically in CNN with its unique layers (convolution, pooling, flatten).

---

**Backpropagation in (flatten,maxpooling,convolution)**-->backpropagation in cnn as i come to know that the last part of the cnn which is basically the ann and i come to know till the maxpooling layer which is the part of cnn but from maxpooling to activtion function and from this to input i confused how propagaion occur here ,if we split the cnn architechure into cnn and ann part just explain me in descriptive way like we have to minimize the loss using gradient by backpropagation ,if we start from the loss it depends on y^ and it dpends on flatten layer which is 2x2 matrix and now it is 4x4 sicne we are dong backpropagation and this now depends on maxpooling which is 4x4 matrix and again maxpooling depends on activation function

---

## Understanding Backpropagation in CNN:

### Split CNN into Two Parts:

1. **CNN Part**: Convolution → Activation → Pooling layers
2. **ANN Part**: Flatten → Dense → Output layers

### Backpropagation Flow (Backward):

```
Loss
  ↓ depends on
ŷ (predicted value)
  ↓ depends on
Flatten Layer (2x2 matrix → becomes 4x4 in backprop)
  ↓ depends on
MaxPooling (4x4 matrix)
  ↓ depends on
Activation Function
  ↓ depends on
Convolution Layer
  ↓ depends on
Input
```

### Key Points:

1. **Start from Loss**: We have to minimize loss using gradient by backpropagation

2. **Loss depends on ŷ**: Predicted value from final layer

3. **ŷ depends on Flatten**: 
   - Forward: 4x4 → 2x2 (flatten)
   - Backward: 2x2 → 4x4 (unflatten)

4. **Flatten depends on MaxPooling**: 4x4 matrix

5. **MaxPooling depends on Activation Function**: ReLU typically

6. **Activation depends on Convolution**: Feature maps

7. **Convolution depends on Input**: Original image

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 4: TRANSFER LEARNING
# ═══════════════════════════════════════════════════════════════════════════════

**Why Transfer Learning comes here:** After understanding CNN architecture and training, transfer learning shows how to REUSE pre-trained models instead of training from scratch.

---

**Transfer learning** means keeping the CNN part as-is (since it already knows how to "see" images), and replacing the ANN part so the model can make predictions for your specific labels, even if they weren't part of the original model's training.

We keep the CNN part (also called the feature extractor) of the model — it has already learned to detect useful patterns like edges, textures, and shapes from millions of images. We usually freeze these layers so they don't get updated during training. This saves time and avoids overfitting, especially if your dataset is small. We remove or ignore those FC (fully connected) layers and add new ones suited to your task.

---

## Understanding Transfer Learning:

### What We Keep (CNN Part = Feature Extractor):
- Already learned to detect:
  - Edges
  - Textures
  - Shapes
- Trained on millions of images
- **FREEZE** these layers (don't update during training)

### What We Replace (ANN Part = Classifier):
- Remove or ignore FC (fully connected) layers
- Add NEW FC layers suited to YOUR task
- Train these new layers on YOUR data

### Benefits:
- **Saves time**: Don't train from scratch
- **Avoids overfitting**: Especially with small datasets
- **Better performance**: Starts with strong base

---

## Two Ways to Apply Transfer Learning:

**Ways to Apply**:
1. **feature extraction** which is basically apply in which labels are similar on which pretrained model already trained and above we have seen its implementation.
2. **Fine Tuning** in whcih some convolutional layers are unfreezed and FC layers are trained and this is apply when we are working which is different from the pretrained labels dataset.

---

### 1. Feature Extraction
- **When to use**: Labels are SIMILAR to pretrained model's training data
- **How**: 
  - Keep ALL CNN layers frozen
  - Only train new FC layers
- **Example**: Pretrained on ImageNet (1000 classes), your task is dog breeds

### 2. Fine Tuning
- **When to use**: Labels are DIFFERENT from pretrained model's training data
- **How**:
  - UNFREEZE some convolutional layers
  - Train FC layers AND some conv layers
- **Example**: Pretrained on ImageNet, your task is medical X-ray classification

---

# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 5: KERAS IMAGEDATAGENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

**Why ImageDataGenerator comes here:** After learning CNN and transfer learning, we need to know how to AUGMENT data to improve training and prevent overfitting.

---

**Keras ImageDataGenerator**: The Keras ImageDataGenerator is a powerful tool that generates transformed images in real-time, enabling data augmentation to combat overfitting during training.

---

## What ImageDataGenerator Does:

1. **Generates transformed images in REAL-TIME**
   - Don't need to store augmented images
   - Creates on-the-fly during training

2. **Data Augmentation techniques**:
   - Rotation
   - Width/Height shift
   - Zoom
   - Horizontal/Vertical flip
   - Shear
   - Brightness adjustment

3. **Combats Overfitting**
   - Creates more training data from existing data
   - Model sees different versions of same image
   - Learns more robust features

---

## Example Transformations:

| Transformation | What it does |
|----------------|--------------|
| Rotation | Rotate image by degrees |
| Width Shift | Move image horizontally |
| Height Shift | Move image vertically |
| Zoom | Zoom in or out |
| Horizontal Flip | Mirror image horizontally |
| Vertical Flip | Mirror image vertically |
| Shear | Slant the image |

---

# ═══════════════════════════════════════════════════════════════════════════════
# LEARNING SEQUENCE FOR LEVEL 2
# ═══════════════════════════════════════════════════════════════════════════════

```
LEVEL 2: CONVOLUTIONAL NEURAL NETWORKS (CNN)
════════════════════════════════════════════

Section 1:  ANN vs CNN (understand the difference)
                ↓
Section 2:  CNN Architecture (three ways to represent)
                ↓
Section 3:  Backpropagation in CNN (how gradients flow)
                ↓
Section 4:  Transfer Learning (reuse pretrained models)
                ↓
Section 5:  Keras ImageDataGenerator (data augmentation)

════════════════════════════════════════════
LEVEL 2 COMPLETE - READY FOR LEVEL 3 (RNN)
════════════════════════════════════════════
```

---

## Key Takeaways from LEVEL 2:

1. **CNN vs ANN**: CNN uses convolution (filter sliding), independent of input size, used for grid data (images)

2. **CNN Architecture**: Can be represented as diagrams, logical flow, or equations

3. **Backpropagation in CNN**: Split into CNN part and ANN part, gradients flow backward through flatten, pooling, activation, convolution

4. **Transfer Learning**: Keep CNN part (feature extractor), replace ANN part (classifier)
   - Feature Extraction: Similar labels, freeze all CNN
   - Fine Tuning: Different labels, unfreeze some CNN

5. **ImageDataGenerator**: Real-time data augmentation to combat overfitting

---

*This is LEVEL 2 containing ALL verbatim content from the repository for CNN. Each concept builds on LEVEL 1 and prepares for LEVEL 3 (RNN).*

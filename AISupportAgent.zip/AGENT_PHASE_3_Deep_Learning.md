# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 AI CUSTOMER SUPPORT AGENT PROJECT
# PHASE 3: DEEP LEARNING INTENT CLASSIFIER
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Build neural network-based intent classifiers for better generalization.

## 📚 CONCEPTS COVERED
- Feed-forward Neural Networks for Classification
- Embedding Layers
- Multi-class Cross-Entropy Loss
- Dropout and Regularization
- Model Comparison

## 📊 EXPECTED ACCURACY: ~88-92%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: PREPARE DATA FOR DEEP LEARNING
# ═══════════════════════════════════════════════════════════════════════════════

```python
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load data
train_df = pd.read_csv('data/processed/intent_train.csv')
test_df = pd.read_csv('data/processed/intent_test.csv')

# Get unique labels
labels = train_df['label'].unique()
label_to_idx = {label: idx for idx, label in enumerate(labels)}
idx_to_label = {idx: label for label, idx in label_to_idx.items()}
num_classes = len(labels)

print(f"Number of intent classes: {num_classes}")

# Prepare data
X_train = train_df['text'].values
y_train = train_df['label'].map(label_to_idx).values
X_test = test_df['text'].values
y_test = test_df['label'].map(label_to_idx).values

# Tokenization
vocab_size = 10000
max_length = 50
embedding_dim = 128

tokenizer = Tokenizer(num_words=vocab_size, oov_token='<OOV>')
tokenizer.fit_on_texts(X_train)

X_train_seq = tokenizer.texts_to_sequences(X_train)
X_test_seq = tokenizer.texts_to_sequences(X_test)

X_train_pad = pad_sequences(X_train_seq, maxlen=max_length, padding='post')
X_test_pad = pad_sequences(X_test_seq, maxlen=max_length, padding='post')

print(f"Training shape: {X_train_pad.shape}")
print(f"Test shape: {X_test_pad.shape}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: SIMPLE MLP CLASSIFIER
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# MODEL 1: MLP WITH EMBEDDING
# ============================================

def build_mlp_model(vocab_size, embedding_dim, max_length, num_classes):
    """Simple MLP with embedding layer"""
    
    model = keras.Sequential([
        # Embedding layer
        layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
        
        # Flatten or Global Average Pooling
        layers.GlobalAveragePooling1D(),
        
        # Hidden layers
        layers.Dense(256, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(128, activation='relu'),
        layers.Dropout(0.3),
        layers.Dense(64, activation='relu'),
        
        # Output layer (multi-class)
        layers.Dense(num_classes, activation='softmax')
    ])
    
    return model

# Build and compile
model_mlp = build_mlp_model(vocab_size, embedding_dim, max_length, num_classes)

model_mlp.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

model_mlp.summary()

# Train
history_mlp = model_mlp.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=20,
    batch_size=64,
    callbacks=[
        EarlyStopping(patience=3, restore_best_weights=True),
        ModelCheckpoint('models/intent_mlp.h5', save_best_only=True)
    ],
    verbose=1
)

# Evaluate
mlp_loss, mlp_acc = model_mlp.evaluate(X_test_pad, y_test)
print(f"\nMLP Test Accuracy: {mlp_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: DEEPER NETWORK WITH BATCH NORMALIZATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# MODEL 2: DEEP MLP WITH BATCH NORM
# ============================================

def build_deep_mlp(vocab_size, embedding_dim, max_length, num_classes):
    """Deeper MLP with batch normalization"""
    
    model = keras.Sequential([
        layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
        layers.GlobalAveragePooling1D(),
        
        # Deep layers with batch norm
        layers.Dense(512),
        layers.BatchNormalization(),
        layers.Activation('relu'),
        layers.Dropout(0.5),
        
        layers.Dense(256),
        layers.BatchNormalization(),
        layers.Activation('relu'),
        layers.Dropout(0.4),
        
        layers.Dense(128),
        layers.BatchNormalization(),
        layers.Activation('relu'),
        layers.Dropout(0.3),
        
        layers.Dense(64),
        layers.BatchNormalization(),
        layers.Activation('relu'),
        
        layers.Dense(num_classes, activation='softmax')
    ])
    
    return model

model_deep = build_deep_mlp(vocab_size, embedding_dim, max_length, num_classes)

model_deep.compile(
    optimizer=keras.optimizers.Adam(learning_rate=0.001),
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

history_deep = model_deep.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=20,
    batch_size=64,
    callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
    verbose=1
)

deep_loss, deep_acc = model_deep.evaluate(X_test_pad, y_test)
print(f"\nDeep MLP Test Accuracy: {deep_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: MULTI-LABEL INTENT (FOR COMPLEX QUERIES)
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# MULTI-LABEL CLASSIFICATION
# ============================================

print("""
MULTI-LABEL INTENT CLASSIFICATION:

Why multi-label?
- "I want to return this and track my refund" → [return, track_order, refund]
- Complex queries may have multiple intents

Changes from multi-class:
- Output: Sigmoid instead of Softmax
- Loss: Binary cross-entropy
- Each intent is independent
""")

def build_multilabel_model(vocab_size, embedding_dim, max_length, num_classes):
    """Multi-label intent classifier"""
    
    model = keras.Sequential([
        layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
        layers.GlobalAveragePooling1D(),
        
        layers.Dense(256, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(128, activation='relu'),
        layers.Dropout(0.3),
        
        # Sigmoid for multi-label (each output is independent 0-1)
        layers.Dense(num_classes, activation='sigmoid')
    ])
    
    return model

# Note: For multi-label, you'd need multi-hot encoded labels
# Example: [1, 0, 0, 1, 0, ...] for intents 0 and 3

print("Multi-label model structure defined")
print("Use binary_crossentropy loss and sigmoid activation")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: VISUALIZE TRAINING
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# TRAINING VISUALIZATION
# ============================================

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Accuracy
axes[0].plot(history_mlp.history['accuracy'], label='MLP Train')
axes[0].plot(history_mlp.history['val_accuracy'], label='MLP Val')
axes[0].plot(history_deep.history['accuracy'], label='Deep MLP Train', linestyle='--')
axes[0].plot(history_deep.history['val_accuracy'], label='Deep MLP Val', linestyle='--')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('Accuracy')
axes[0].set_title('Training Accuracy')
axes[0].legend()
axes[0].grid(True)

# Loss
axes[1].plot(history_mlp.history['loss'], label='MLP Train')
axes[1].plot(history_mlp.history['val_loss'], label='MLP Val')
axes[1].plot(history_deep.history['loss'], label='Deep MLP Train', linestyle='--')
axes[1].plot(history_deep.history['val_loss'], label='Deep MLP Val', linestyle='--')
axes[1].set_xlabel('Epoch')
axes[1].set_ylabel('Loss')
axes[1].set_title('Training Loss')
axes[1].legend()
axes[1].grid(True)

plt.tight_layout()
plt.savefig('models/dl_intent_training.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: INFERENCE CLASS FOR AGENT
# ═══════════════════════════════════════════════════════════════════════════════

```python
import pickle

# ============================================
# SAVE COMPONENTS
# ============================================

# Save tokenizer
with open('models/intent_tokenizer.pkl', 'wb') as f:
    pickle.dump(tokenizer, f)

# Save label mappings
with open('models/intent_label_mappings.pkl', 'wb') as f:
    pickle.dump({'label_to_idx': label_to_idx, 'idx_to_label': idx_to_label}, f)

# Save best model
model_deep.save('models/intent_deep_mlp.h5')

# ============================================
# INFERENCE CLASS
# ============================================

class DeepIntentClassifier:
    """Deep learning intent classifier for agent"""
    
    def __init__(self, model_path='models/intent_deep_mlp.h5',
                 tokenizer_path='models/intent_tokenizer.pkl',
                 mappings_path='models/intent_label_mappings.pkl'):
        
        self.model = keras.models.load_model(model_path)
        
        with open(tokenizer_path, 'rb') as f:
            self.tokenizer = pickle.load(f)
        
        with open(mappings_path, 'rb') as f:
            mappings = pickle.load(f)
            self.label_to_idx = mappings['label_to_idx']
            self.idx_to_label = mappings['idx_to_label']
        
        self.max_length = 50
    
    def predict(self, text, top_k=3):
        """Predict intent with confidence scores"""
        # Tokenize and pad
        seq = self.tokenizer.texts_to_sequences([text])
        padded = pad_sequences(seq, maxlen=self.max_length, padding='post')
        
        # Predict
        proba = self.model.predict(padded, verbose=0)[0]
        
        # Get top k predictions
        top_indices = proba.argsort()[-top_k:][::-1]
        
        results = {
            'top_intent': self.idx_to_label[top_indices[0]],
            'confidence': float(proba[top_indices[0]]),
            'top_k': [(self.idx_to_label[i], float(proba[i])) for i in top_indices]
        }
        
        return results
    
    def predict_batch(self, texts):
        """Batch prediction"""
        seqs = self.tokenizer.texts_to_sequences(texts)
        padded = pad_sequences(seqs, maxlen=self.max_length, padding='post')
        probas = self.model.predict(padded, verbose=0)
        
        results = []
        for proba in probas:
            top_idx = proba.argmax()
            results.append({
                'intent': self.idx_to_label[top_idx],
                'confidence': float(proba[top_idx])
            })
        
        return results

# Test
print("\nTesting Deep Intent Classifier:")
classifier = DeepIntentClassifier()

test_queries = [
    "How do I get a refund?",
    "Track my order please",
    "I need technical support"
]

for query in test_queries:
    result = classifier.predict(query)
    print(f"\nQuery: {query}")
    print(f"  Intent: {result['top_intent']} ({result['confidence']:.2%})")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 3 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ MLP Intent Classifier
   └── Embedding + Dense layers
   └── GlobalAveragePooling
   └── ~88-90% accuracy

✅ Deep MLP with Batch Norm
   └── 5 dense layers
   └── Batch normalization
   └── Progressive dropout

✅ Multi-label Understanding
   └── Sigmoid output
   └── Binary cross-entropy
   └── Independent intent scores

✅ Production Inference Class
   └── DeepIntentClassifier
   └── Top-k predictions
   └── Batch support

✅ Model Artifacts Saved
   └── Keras model (.h5)
   └── Tokenizer (.pkl)
   └── Label mappings (.pkl)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY: ~88-92%
# NEXT: PHASE 4 - CNN FOR TEXT CLASSIFICATION
# ═══════════════════════════════════════════════════════════════════════════════

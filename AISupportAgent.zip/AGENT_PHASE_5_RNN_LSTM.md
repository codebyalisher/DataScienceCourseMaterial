# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 AI CUSTOMER SUPPORT AGENT PROJECT
# PHASE 5: RNN/LSTM FOR CONTEXT UNDERSTANDING
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Use recurrent networks to understand conversation context and sequential patterns.

## 📚 CONCEPTS COVERED
- LSTM for Intent Classification
- Bidirectional LSTM
- Context-Aware Classification
- Multi-turn Conversation Understanding

## 📊 EXPECTED ACCURACY: ~91-93%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: LSTM INTENT CLASSIFIER
# ═══════════════════════════════════════════════════════════════════════════════

```python
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np

print("""
WHY LSTM FOR AGENTS?

1. SEQUENTIAL UNDERSTANDING:
   - Word order matters: "not good" vs "good not"
   - LSTM processes words in sequence

2. CONTEXT MEMORY:
   - Remembers earlier parts of query
   - "After I ordered the SmartWatch, I realized I wanted the Pro version"
   - LSTM connects "SmartWatch" to "Pro version"

3. MULTI-TURN CONVERSATIONS:
   - Can process entire conversation history
   - Maintains context across turns
""")

# ============================================
# LSTM MODEL
# ============================================

def build_lstm_model(vocab_size, embedding_dim, max_length, num_classes):
    """LSTM for intent classification"""
    
    model = keras.Sequential([
        layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
        
        # LSTM layers
        layers.LSTM(128, return_sequences=True),
        layers.Dropout(0.3),
        layers.LSTM(64),
        layers.Dropout(0.3),
        
        # Classification
        layers.Dense(64, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation='softmax')
    ])
    
    return model

vocab_size = 10000
embedding_dim = 128
max_length = 50
num_classes = 77

model_lstm = build_lstm_model(vocab_size, embedding_dim, max_length, num_classes)
model_lstm.summary()

model_lstm.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

# Train
from tensorflow.keras.callbacks import EarlyStopping

history_lstm = model_lstm.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=15,
    batch_size=64,
    callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
    verbose=1
)

lstm_acc = model_lstm.evaluate(X_test_pad, y_test)[1]
print(f"\nLSTM Accuracy: {lstm_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: BIDIRECTIONAL LSTM
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# BIDIRECTIONAL LSTM
# ============================================

print("""
BIDIRECTIONAL LSTM:

Regular LSTM: "I want to [track] my order"
              → Only knows "I want to" before "track"

BiLSTM: Processes both directions
        → Forward: "I want to" → [track]
        → Backward: "my order" ← [track]
        
Agent benefit: Better understanding of full query context
""")

def build_bilstm_model(vocab_size, embedding_dim, max_length, num_classes):
    """Bidirectional LSTM"""
    
    model = keras.Sequential([
        layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
        
        # Bidirectional LSTM
        layers.Bidirectional(layers.LSTM(128, return_sequences=True)),
        layers.Dropout(0.3),
        layers.Bidirectional(layers.LSTM(64)),
        layers.Dropout(0.3),
        
        layers.Dense(64, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation='softmax')
    ])
    
    return model

model_bilstm = build_bilstm_model(vocab_size, embedding_dim, max_length, num_classes)

model_bilstm.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

history_bilstm = model_bilstm.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=15,
    batch_size=64,
    callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
    verbose=1
)

bilstm_acc = model_bilstm.evaluate(X_test_pad, y_test)[1]
print(f"\nBiLSTM Accuracy: {bilstm_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: CONTEXT-AWARE MULTI-TURN CLASSIFIER
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# MULTI-TURN CONTEXT MODEL
# ============================================

print("""
MULTI-TURN CONVERSATION UNDERSTANDING:

Turn 1: "I ordered something yesterday"
Turn 2: "It hasn't arrived yet"
Turn 3: "Can you check on it?"

Without context: "Can you check on it?" → Ambiguous
With context: "Can you check on [order from yesterday]?" → track_order
""")

def build_context_model(vocab_size, embedding_dim, max_turns, max_length, num_classes):
    """
    Context-aware model that processes conversation history
    
    Input shape: (max_turns, max_length)
    Each turn is processed, then combined
    """
    
    # Input for multiple turns
    inputs = keras.Input(shape=(max_turns, max_length))
    
    # Shared embedding for all turns
    embedding = layers.Embedding(vocab_size, embedding_dim)
    
    # Process each turn with shared LSTM
    turn_lstm = layers.LSTM(64)
    
    # Use TimeDistributed to apply to each turn
    embedded = layers.TimeDistributed(embedding)(inputs)
    # Reshape for processing
    # (batch, turns, length, embed) -> process each turn
    
    turn_outputs = layers.TimeDistributed(
        layers.LSTM(64)
    )(embedded)
    
    # Process turn sequence
    context_lstm = layers.LSTM(64)(turn_outputs)
    
    # Classification
    x = layers.Dense(64, activation='relu')(context_lstm)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(num_classes, activation='softmax')(x)
    
    return keras.Model(inputs=inputs, outputs=outputs)

# Alternative: Concatenate context with current query

def build_context_concat_model(vocab_size, embedding_dim, max_length, num_classes):
    """
    Simpler approach: Concatenate context + current query
    """
    
    # Context input (previous turns concatenated)
    context_input = keras.Input(shape=(max_length * 2,), name='context')
    # Current query input
    query_input = keras.Input(shape=(max_length,), name='query')
    
    # Shared embedding
    embedding = layers.Embedding(vocab_size, embedding_dim)
    
    # Embed both
    context_embedded = embedding(context_input)
    query_embedded = embedding(query_input)
    
    # Process context
    context_lstm = layers.Bidirectional(layers.LSTM(64))(context_embedded)
    
    # Process query
    query_lstm = layers.Bidirectional(layers.LSTM(64))(query_embedded)
    
    # Combine
    combined = layers.Concatenate()([context_lstm, query_lstm])
    
    # Classification
    x = layers.Dense(128, activation='relu')(combined)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(64, activation='relu')(x)
    outputs = layers.Dense(num_classes, activation='softmax')(x)
    
    return keras.Model(inputs=[context_input, query_input], outputs=outputs)

print("Context-aware models defined")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: GRU ALTERNATIVE
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# GRU MODEL (FASTER ALTERNATIVE)
# ============================================

def build_gru_model(vocab_size, embedding_dim, max_length, num_classes):
    """GRU - faster than LSTM with similar performance"""
    
    model = keras.Sequential([
        layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
        
        layers.Bidirectional(layers.GRU(128, return_sequences=True)),
        layers.Dropout(0.3),
        layers.Bidirectional(layers.GRU(64)),
        layers.Dropout(0.3),
        
        layers.Dense(64, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation='softmax')
    ])
    
    return model

model_gru = build_gru_model(vocab_size, embedding_dim, max_length, num_classes)

model_gru.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

history_gru = model_gru.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=15,
    batch_size=64,
    callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
    verbose=1
)

gru_acc = model_gru.evaluate(X_test_pad, y_test)[1]
print(f"\nBiGRU Accuracy: {gru_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: CONVERSATION STATE TRACKER
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# CONVERSATION STATE TRACKER FOR AGENT
# ============================================

class ConversationStateTracker:
    """
    Tracks conversation state for the agent
    
    Maintains:
    - Conversation history
    - Detected intents per turn
    - Extracted entities
    - Current focus/topic
    """
    
    def __init__(self, max_history=10):
        self.max_history = max_history
        self.history = []
        self.intent_history = []
        self.entities = {}
        self.current_topic = None
    
    def add_turn(self, role, content, intent=None, entities=None):
        """Add a conversation turn"""
        turn = {
            'role': role,
            'content': content,
            'intent': intent,
            'entities': entities or {}
        }
        
        self.history.append(turn)
        
        if intent:
            self.intent_history.append(intent)
        
        if entities:
            self.entities.update(entities)
        
        # Keep only recent history
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]
    
    def get_context(self, num_turns=3):
        """Get recent conversation context"""
        recent = self.history[-num_turns:]
        return ' '.join([t['content'] for t in recent])
    
    def get_state(self):
        """Get current conversation state"""
        return {
            'num_turns': len(self.history),
            'current_intent': self.intent_history[-1] if self.intent_history else None,
            'intent_flow': self.intent_history[-5:],
            'entities': self.entities,
            'topic': self.current_topic
        }
    
    def reset(self):
        """Reset conversation state"""
        self.history = []
        self.intent_history = []
        self.entities = {}
        self.current_topic = None

# Example usage
tracker = ConversationStateTracker()

# Simulate conversation
tracker.add_turn('user', "Hi, I need help with my order", intent='greeting')
tracker.add_turn('agent', "Hello! I'd be happy to help. What's your order number?")
tracker.add_turn('user', "It's ORD-12345", intent='track_order', entities={'order_id': 'ORD-12345'})

print("Conversation State:")
print(tracker.get_state())
print(f"\nContext: {tracker.get_context()}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: SAVE AND COMPARE
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# MODEL COMPARISON
# ============================================

print("\n" + "=" * 60)
print("RNN MODEL COMPARISON")
print("=" * 60)

results = {
    'LSTM': lstm_acc,
    'BiLSTM': bilstm_acc,
    'BiGRU': gru_acc
}

for name, acc in sorted(results.items(), key=lambda x: x[1], reverse=True):
    print(f"{name}: {acc:.2%}")

# Save best model
best_name = max(results, key=results.get)
if best_name == 'BiLSTM':
    model_bilstm.save('models/intent_bilstm.h5')
elif best_name == 'BiGRU':
    model_gru.save('models/intent_bigru.h5')
else:
    model_lstm.save('models/intent_lstm.h5')

print(f"\nBest model ({best_name}) saved!")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 5 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ LSTM Intent Classifier
   └── Sequential processing
   └── ~90-91% accuracy

✅ Bidirectional LSTM
   └── Forward + backward context
   └── ~91-93% accuracy

✅ BiGRU Alternative
   └── Faster training
   └── Similar performance

✅ Context-Aware Models
   └── Multi-turn processing
   └── Conversation history

✅ Conversation State Tracker
   └── History management
   └── Entity tracking
   └── Intent flow
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY: ~91-93%
# NEXT: PHASE 6 - SEQ2SEQ FOR RESPONSE GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 AI CUSTOMER SUPPORT AGENT PROJECT
# PHASE 6: SEQ2SEQ FOR RESPONSE GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Build encoder-decoder models to generate agent responses from customer queries.

## 📚 CONCEPTS COVERED
- Seq2Seq for Response Generation
- Teacher Forcing
- Attention for Response Generation
- Template-based vs Generative Responses

## 📊 EXPECTED: Coherent response generation

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: RESPONSE GENERATION APPROACHES
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
RESPONSE GENERATION FOR AGENTS
═══════════════════════════════════════════════════════════════════════════════

THREE APPROACHES:

1️⃣ RETRIEVAL-BASED (Simple)
   - Store predefined responses for each intent
   - Retrieve best matching response
   - Pro: Consistent, controllable
   - Con: Limited flexibility

2️⃣ TEMPLATE-BASED (Hybrid)
   - Templates with slots for entities
   - "Your order {order_id} will arrive by {date}"
   - Pro: Flexible yet controlled
   - Con: Requires template design

3️⃣ GENERATIVE (Seq2Seq/Transformer)
   - Generate responses word by word
   - Most flexible
   - Pro: Natural, varied responses
   - Con: May generate incorrect info

RECOMMENDATION FOR CUSTOMER SUPPORT:
→ Hybrid approach: Templates + Generative for small talk
→ Critical info (prices, dates) from templates
→ Conversational parts can be generative
═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: RETRIEVAL-BASED RESPONSES
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# RETRIEVAL-BASED RESPONSE SYSTEM
# ============================================

class RetrievalResponseGenerator:
    """Simple retrieval-based response generator"""
    
    def __init__(self):
        self.responses = {
            'track_order': [
                "I'd be happy to help you track your order. Could you please provide your order number?",
                "Sure! Let me look up your order. What's your order number?",
                "I can help with that! Please share your order number so I can check the status."
            ],
            'refund_request': [
                "I understand you'd like a refund. I'll help you with that. What's your order number?",
                "I can process that refund for you. May I have your order number?",
                "Of course, I'll assist with your refund. Could you provide the order number?"
            ],
            'technical_support': [
                "I'm sorry you're experiencing technical issues. Let me help troubleshoot. What specific problem are you facing?",
                "I'd be happy to help with your technical issue. Can you describe what's happening?",
                "Let's get this sorted out. What exactly is the problem you're encountering?"
            ],
            'billing_inquiry': [
                "I can help with your billing question. What would you like to know?",
                "Sure, I'll look into your billing. What's the issue?",
                "I'd be happy to assist with billing. What's your concern?"
            ],
            'greeting': [
                "Hello! How can I help you today?",
                "Hi there! What can I assist you with?",
                "Welcome! How may I help you?"
            ],
            'goodbye': [
                "Thank you for contacting us! Have a great day!",
                "You're welcome! Is there anything else I can help with?",
                "Glad I could help! Take care!"
            ],
            'default': [
                "I'd be happy to help. Could you tell me more about what you need?",
                "I'm here to assist. What can I help you with?",
                "Let me help you with that. Could you provide more details?"
            ]
        }
    
    def get_response(self, intent, context=None):
        """Get response for given intent"""
        import random
        
        responses = self.responses.get(intent, self.responses['default'])
        return random.choice(responses)
    
    def add_responses(self, intent, responses):
        """Add new responses for an intent"""
        if intent in self.responses:
            self.responses[intent].extend(responses)
        else:
            self.responses[intent] = responses

# Test
retrieval_gen = RetrievalResponseGenerator()

test_intents = ['track_order', 'refund_request', 'greeting']
for intent in test_intents:
    print(f"\nIntent: {intent}")
    print(f"Response: {retrieval_gen.get_response(intent)}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: TEMPLATE-BASED RESPONSES
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# TEMPLATE-BASED RESPONSE SYSTEM
# ============================================

class TemplateResponseGenerator:
    """Template-based response generator with slot filling"""
    
    def __init__(self):
        self.templates = {
            'track_order': {
                'ask_order_id': "I'd be happy to help track your order. Could you provide your order number?",
                'found': "Great! I found your order {order_id}. It was shipped on {ship_date} and is expected to arrive by {delivery_date}. The current status is: {status}.",
                'not_found': "I couldn't find order {order_id} in our system. Could you double-check the order number?",
                'in_transit': "Your order {order_id} is currently in transit. Tracking number: {tracking_number}. Expected delivery: {delivery_date}."
            },
            'refund_request': {
                'initiated': "I've initiated a refund for order {order_id}. The amount of {amount} will be credited to your {payment_method} within {days} business days.",
                'ineligible': "I'm sorry, but order {order_id} is not eligible for a refund because {reason}.",
                'already_refunded': "Order {order_id} was already refunded on {refund_date}. The amount of {amount} should reflect in your account."
            },
            'account_info': {
                'email_updated': "Your email has been updated to {new_email}. A confirmation has been sent to both your old and new email addresses.",
                'password_reset': "A password reset link has been sent to {email}. Please check your inbox and follow the instructions."
            },
            'product_inquiry': {
                'in_stock': "{product_name} is currently in stock! Price: {price}. Would you like me to add it to your cart?",
                'out_of_stock': "I'm sorry, {product_name} is currently out of stock. Expected back in stock: {restock_date}. Would you like to be notified when it's available?",
                'specs': "Here are the specifications for {product_name}:\\n{specifications}"
            }
        }
    
    def fill_template(self, template, **kwargs):
        """Fill template with provided values"""
        try:
            return template.format(**kwargs)
        except KeyError as e:
            return f"Missing information: {e}"
    
    def generate_response(self, intent, template_key, **kwargs):
        """Generate response from template"""
        if intent not in self.templates:
            return "I'm not sure how to help with that. Could you rephrase?"
        
        if template_key not in self.templates[intent]:
            return "I need more information to help you."
        
        template = self.templates[intent][template_key]
        return self.fill_template(template, **kwargs)

# Test
template_gen = TemplateResponseGenerator()

# Example: Order found
response = template_gen.generate_response(
    'track_order', 
    'found',
    order_id='ORD-12345',
    ship_date='Dec 20',
    delivery_date='Dec 25',
    status='In Transit'
)
print(f"Template Response:\n{response}")

# Example: Refund initiated
response = template_gen.generate_response(
    'refund_request',
    'initiated',
    order_id='ABC-99999',
    amount='$149.99',
    payment_method='credit card',
    days='3-5'
)
print(f"\nRefund Response:\n{response}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: SEQ2SEQ RESPONSE GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

```python
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np

# ============================================
# SEQ2SEQ WITH ATTENTION
# ============================================

class Encoder(keras.Model):
    """Encoder for Seq2Seq"""
    
    def __init__(self, vocab_size, embedding_dim, enc_units):
        super(Encoder, self).__init__()
        self.enc_units = enc_units
        self.embedding = layers.Embedding(vocab_size, embedding_dim)
        self.lstm = layers.LSTM(enc_units, return_sequences=True, return_state=True)
    
    def call(self, x):
        x = self.embedding(x)
        output, state_h, state_c = self.lstm(x)
        return output, state_h, state_c


class BahdanauAttention(layers.Layer):
    """Attention for Seq2Seq"""
    
    def __init__(self, units):
        super(BahdanauAttention, self).__init__()
        self.W1 = layers.Dense(units)
        self.W2 = layers.Dense(units)
        self.V = layers.Dense(1)
    
    def call(self, query, values):
        query_expanded = tf.expand_dims(query, 1)
        score = self.V(tf.nn.tanh(self.W1(query_expanded) + self.W2(values)))
        attention_weights = tf.nn.softmax(score, axis=1)
        context = tf.reduce_sum(attention_weights * values, axis=1)
        return context, attention_weights


class Decoder(keras.Model):
    """Decoder with Attention"""
    
    def __init__(self, vocab_size, embedding_dim, dec_units):
        super(Decoder, self).__init__()
        self.dec_units = dec_units
        self.embedding = layers.Embedding(vocab_size, embedding_dim)
        self.lstm = layers.LSTM(dec_units, return_sequences=True, return_state=True)
        self.attention = BahdanauAttention(dec_units)
        self.fc = layers.Dense(vocab_size)
    
    def call(self, x, hidden, enc_output):
        context, attention_weights = self.attention(hidden, enc_output)
        x = self.embedding(x)
        x = tf.concat([tf.expand_dims(context, 1), x], axis=-1)
        output, state_h, state_c = self.lstm(x)
        output = tf.reshape(output, (-1, output.shape[2]))
        x = self.fc(output)
        return x, state_h, attention_weights


# ============================================
# SEQ2SEQ MODEL CLASS
# ============================================

class Seq2SeqResponseGenerator:
    """Seq2Seq model for response generation"""
    
    def __init__(self, vocab_size=10000, embedding_dim=256, units=512):
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.units = units
        
        self.encoder = Encoder(vocab_size, embedding_dim, units)
        self.decoder = Decoder(vocab_size, embedding_dim, units)
        
        self.tokenizer = None
        self.max_length = 50
    
    def train_step(self, inp, targ, enc_hidden):
        """Single training step with teacher forcing"""
        loss = 0
        
        with tf.GradientTape() as tape:
            enc_output, enc_h, enc_c = self.encoder(inp)
            dec_hidden = enc_h
            
            # Teacher forcing: feed target as next input
            for t in range(1, targ.shape[1]):
                dec_input = tf.expand_dims(targ[:, t-1], 1)
                predictions, dec_hidden, _ = self.decoder(dec_input, dec_hidden, enc_output)
                loss += self.loss_function(targ[:, t], predictions)
        
        return loss / int(targ.shape[1])
    
    def loss_function(self, real, pred):
        """Masked loss function"""
        mask = tf.math.logical_not(tf.math.equal(real, 0))
        loss = tf.keras.losses.sparse_categorical_crossentropy(real, pred, from_logits=True)
        mask = tf.cast(mask, dtype=loss.dtype)
        return tf.reduce_mean(loss * mask)
    
    def generate_response(self, input_text, max_length=50):
        """Generate response for input text"""
        # This would use the trained model for inference
        # Simplified placeholder
        pass

print("Seq2Seq Response Generator defined")
print("Note: Full training requires substantial conversation data")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: HYBRID RESPONSE SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# HYBRID RESPONSE SYSTEM FOR AGENT
# ============================================

class HybridResponseGenerator:
    """
    Combines retrieval, templates, and generative approaches
    
    Strategy:
    - Critical info (orders, refunds) → Templates
    - Conversational (greetings, clarifications) → Retrieval
    - Complex/novel queries → Generative (LLM)
    """
    
    def __init__(self):
        self.retrieval = RetrievalResponseGenerator()
        self.templates = TemplateResponseGenerator()
        
        # Intent to strategy mapping
        self.strategy_map = {
            'track_order': 'template',
            'refund_request': 'template',
            'billing_inquiry': 'template',
            'product_inquiry': 'template',
            'technical_support': 'retrieval',
            'greeting': 'retrieval',
            'goodbye': 'retrieval',
            'complaint': 'retrieval',
            'default': 'retrieval'
        }
    
    def generate(self, intent, entities=None, context=None):
        """Generate response based on intent and strategy"""
        
        strategy = self.strategy_map.get(intent, 'retrieval')
        entities = entities or {}
        
        if strategy == 'template' and entities:
            # Use template with entities
            return self._template_response(intent, entities)
        else:
            # Use retrieval
            return self.retrieval.get_response(intent, context)
    
    def _template_response(self, intent, entities):
        """Generate template-based response"""
        
        # Determine which template to use based on available entities
        if intent == 'track_order':
            if 'status' in entities:
                return self.templates.generate_response(
                    'track_order', 'found', **entities
                )
            else:
                return self.templates.generate_response(
                    'track_order', 'ask_order_id'
                )
        
        elif intent == 'refund_request':
            if 'amount' in entities:
                return self.templates.generate_response(
                    'refund_request', 'initiated', **entities
                )
            else:
                return self.retrieval.get_response('refund_request')
        
        # Default to retrieval
        return self.retrieval.get_response(intent)

# Test hybrid system
hybrid_gen = HybridResponseGenerator()

# Test with entities
print("With entities (template):")
response = hybrid_gen.generate(
    'track_order',
    entities={
        'order_id': 'ORD-12345',
        'status': 'Shipped',
        'ship_date': 'Dec 20',
        'delivery_date': 'Dec 25'
    }
)
print(response)

# Test without entities (retrieval)
print("\nWithout entities (retrieval):")
response = hybrid_gen.generate('technical_support')
print(response)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 6 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ Retrieval-Based Responses
   └── Predefined responses per intent
   └── Random selection for variety

✅ Template-Based Responses
   └── Slot filling with entities
   └── Dynamic content insertion

✅ Seq2Seq with Attention
   └── Encoder-Decoder architecture
   └── Teacher forcing training
   └── Attention mechanism

✅ Hybrid Response System
   └── Strategy selection per intent
   └── Templates for critical info
   └── Retrieval for conversational
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# NEXT: PHASE 7 - TRANSFORMERS & LLM INTEGRATION
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 AI CUSTOMER SUPPORT AGENT PROJECT
# PHASE 1: DATA FUNDAMENTALS FOR AGENT TRAINING
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PROJECT OVERVIEW

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║   🤖 INTELLIGENT CUSTOMER SUPPORT AGENT                                       ║
║                                                                               ║
║   An AI agent that can:                                                       ║
║   ✓ Understand customer queries (NLP)                                         ║
║   ✓ Classify intent (ML/DL)                                                   ║
║   ✓ Extract entities (NER)                                                    ║
║   ✓ Retrieve relevant knowledge (RAG)                                         ║
║   ✓ Generate helpful responses (LLM)                                          ║
║   ✓ Execute actions/tools (Function Calling)                                  ║
║   ✓ Maintain conversation memory                                              ║
║   ✓ Learn from feedback (RLHF concepts)                                       ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║   PHASES:                                                                     ║
║   1. Data Fundamentals      → Customer support data analysis                  ║
║   2. Machine Learning       → Intent classification, clustering               ║
║   3. Deep Learning          → Neural intent classifier                        ║
║   4. CNN                    → Text CNN for multi-label classification         ║
║   5. RNN/LSTM               → Context-aware understanding                     ║
║   6. Seq2Seq & Attention    → Response generation                             ║
║   7. Transformers           → BERT + GPT for understanding & generation       ║
║   8. NLP Basics             → Entity extraction, preprocessing                ║
║   9. Text Representation    → Embeddings for RAG, similarity search           ║
║   10. Agent Architecture    → Tools, memory, reasoning, deployment            ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

## 📊 DATASETS FOR AGENT TRAINING

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
DATASETS FOR CUSTOMER SUPPORT AGENT
═══════════════════════════════════════════════════════════════════════════════

We'll use multiple datasets to train different components of our agent:

1. INTENT CLASSIFICATION:
   • Dataset: "Customer Support Intent Dataset"
   • Source: Kaggle / HuggingFace
   • Size: ~25,000 queries with 27 intent categories
   • Example intents: refund_request, track_order, technical_support

2. ENTITY EXTRACTION (NER):
   • Dataset: "E-commerce NER Dataset"
   • Entities: PRODUCT, ORDER_ID, DATE, AMOUNT, PERSON

3. CONVERSATION DATA:
   • Dataset: "Customer Service Conversations"
   • Multi-turn dialogues with agent responses
   • Used for response generation training

4. KNOWLEDGE BASE:
   • Company FAQ documents
   • Product documentation
   • Policy documents
   • Used for RAG (Retrieval Augmented Generation)

5. FEEDBACK DATA:
   • Customer satisfaction ratings
   • Response quality labels
   • Used for RLHF-style fine-tuning

═══════════════════════════════════════════════════════════════════════════════
""")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: DOWNLOAD AND LOAD DATASETS
# ═══════════════════════════════════════════════════════════════════════════════

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import re
import os

# Create project structure
os.makedirs('data/raw', exist_ok=True)
os.makedirs('data/processed', exist_ok=True)
os.makedirs('data/knowledge_base', exist_ok=True)
os.makedirs('models', exist_ok=True)
os.makedirs('agent', exist_ok=True)

print("Project structure created!")

# ============================================
# DATASET 1: INTENT CLASSIFICATION
# ============================================

# Option A: Download from HuggingFace
from datasets import load_dataset

# Banking77 - 77 intent classes for banking domain
intent_dataset = load_dataset("banking77")
print(f"Banking77 Dataset loaded:")
print(f"  Train: {len(intent_dataset['train'])} samples")
print(f"  Test: {len(intent_dataset['test'])} samples")

# Convert to DataFrame
train_intent = pd.DataFrame(intent_dataset['train'])
test_intent = pd.DataFrame(intent_dataset['test'])

# View sample
print("\nSample intent data:")
print(train_intent.head())
print(f"\nNumber of intent classes: {train_intent['label'].nunique()}")

# Option B: Use CLINC150 dataset (150 intents + out-of-scope)
# clinc_dataset = load_dataset("clinc_oos", "plus")

# Option C: Create synthetic dataset for demonstration
def create_synthetic_intent_data():
    """Create synthetic customer support intent data"""
    
    intents = {
        'track_order': [
            "Where is my order?",
            "I want to track my package",
            "When will my order arrive?",
            "Can you tell me the status of my order?",
            "My order hasn't arrived yet",
            "Track order number 12345",
            "Where's my stuff?",
            "Delivery status please",
            "How long until my package arrives?",
            "Is my order on the way?"
        ],
        'refund_request': [
            "I want a refund",
            "Can I get my money back?",
            "How do I return this for a refund?",
            "I need to cancel and get refunded",
            "Request refund for order",
            "Return and refund please",
            "I want to return this product",
            "Money back guarantee?",
            "Refund policy question",
            "How long does refund take?"
        ],
        'technical_support': [
            "My product isn't working",
            "I need help with setup",
            "The device won't turn on",
            "Getting an error message",
            "How do I configure this?",
            "Technical issue with my account",
            "App keeps crashing",
            "Can't connect to WiFi",
            "Software not installing",
            "Need technical assistance"
        ],
        'billing_inquiry': [
            "I was charged twice",
            "Why is my bill so high?",
            "Question about my invoice",
            "Payment not going through",
            "Update billing information",
            "I see an unauthorized charge",
            "When is payment due?",
            "Change my payment method",
            "Billing cycle question",
            "Invoice download"
        ],
        'account_management': [
            "How do I reset my password?",
            "I can't log into my account",
            "Update my email address",
            "Delete my account",
            "Change my username",
            "Account security question",
            "Two-factor authentication help",
            "Forgot my password",
            "Link another email",
            "Account settings"
        ],
        'product_inquiry': [
            "Do you have this in stock?",
            "What colors are available?",
            "Is this compatible with iPhone?",
            "Product specifications please",
            "Compare these two products",
            "When will this be back in stock?",
            "What's the warranty?",
            "Product dimensions?",
            "Is this waterproof?",
            "Material information"
        ],
        'shipping_info': [
            "What are the shipping options?",
            "Do you ship internationally?",
            "How much is express shipping?",
            "Change my shipping address",
            "Shipping to Canada?",
            "Free shipping threshold?",
            "Expedited shipping cost",
            "Shipping time estimate",
            "What carrier do you use?",
            "Same day delivery available?"
        ],
        'complaint': [
            "I'm very unhappy with my purchase",
            "This is unacceptable service",
            "I want to speak to a manager",
            "Worst experience ever",
            "Filing a formal complaint",
            "Your service is terrible",
            "I'm extremely disappointed",
            "This is fraud",
            "I will never buy from you again",
            "Escalate this issue"
        ],
        'greeting': [
            "Hello",
            "Hi there",
            "Hey",
            "Good morning",
            "Good afternoon",
            "Hi, I need help",
            "Hello, anyone there?",
            "Hey, quick question",
            "Howdy",
            "Greetings"
        ],
        'goodbye': [
            "Thanks, bye",
            "That's all I needed",
            "Goodbye",
            "Thank you for your help",
            "Have a nice day",
            "Take care",
            "Thanks so much",
            "Appreciate your help",
            "All done, thanks",
            "Bye bye"
        ],
        'out_of_scope': [
            "What's the weather today?",
            "Tell me a joke",
            "Who won the game last night?",
            "What's 2+2?",
            "Can you recommend a movie?",
            "What time is it?",
            "Who is the president?",
            "Random question here",
            "Do you like pizza?",
            "Sing me a song"
        ]
    }
    
    data = []
    for intent, queries in intents.items():
        for query in queries:
            data.append({'text': query, 'intent': intent})
    
    return pd.DataFrame(data)

# Create synthetic data
synthetic_df = create_synthetic_intent_data()
print(f"\nSynthetic intent data created: {len(synthetic_df)} samples")
print(synthetic_df['intent'].value_counts())
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: CREATE KNOWLEDGE BASE
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# KNOWLEDGE BASE DOCUMENTS
# ============================================

knowledge_base = {
    'refund_policy': """
    REFUND POLICY
    
    We offer a 30-day money-back guarantee on all products.
    
    Eligibility:
    - Items must be unused and in original packaging
    - Request must be made within 30 days of purchase
    - Proof of purchase (order confirmation or receipt) required
    
    Process:
    1. Contact customer support with order number
    2. We'll send a prepaid return label
    3. Ship the item back within 7 days
    4. Refund processed within 3-5 business days after receipt
    
    Exceptions:
    - Digital products are non-refundable
    - Personalized items cannot be returned
    - Sale items are final sale
    
    Refund Methods:
    - Original payment method
    - Store credit (instant)
    """,
    
    'shipping_info': """
    SHIPPING INFORMATION
    
    Domestic Shipping (USA):
    - Standard: 5-7 business days ($5.99, free over $50)
    - Express: 2-3 business days ($12.99)
    - Overnight: Next business day ($24.99)
    
    International Shipping:
    - Canada: 7-14 business days ($15.99)
    - Europe: 10-21 business days ($24.99)
    - Asia/Australia: 14-28 business days ($29.99)
    
    Order Processing:
    - Orders placed before 2 PM EST ship same day
    - Weekend orders ship Monday
    - Tracking number sent via email
    
    Carriers:
    - UPS, FedEx, USPS (domestic)
    - DHL (international)
    """,
    
    'technical_support': """
    TECHNICAL SUPPORT GUIDE
    
    Common Issues:
    
    1. Device Won't Turn On:
       - Check battery/power connection
       - Try a different outlet
       - Hold power button for 10 seconds
       - Contact support if issue persists
    
    2. App Crashes:
       - Update to latest version
       - Clear cache and data
       - Reinstall the app
       - Check device compatibility
    
    3. Connection Issues:
       - Restart your router
       - Check WiFi password
       - Move closer to router
       - Try forgetting and reconnecting
    
    4. Account Access:
       - Use "Forgot Password" link
       - Check spam folder for emails
       - Clear browser cookies
       - Try incognito mode
    
    Support Hours:
    - Phone: 9 AM - 9 PM EST
    - Chat: 24/7
    - Email: support@company.com
    """,
    
    'product_catalog': """
    PRODUCT CATALOG
    
    Electronics:
    - SmartWatch Pro ($299) - Water-resistant, GPS, heart monitor
    - Wireless Earbuds X ($149) - 30hr battery, noise cancellation
    - Portable Charger 20K ($49) - Fast charging, USB-C
    
    Home:
    - Smart Thermostat ($199) - WiFi enabled, energy saving
    - Robot Vacuum V3 ($399) - Auto-empty, mapping
    - Air Purifier ($179) - HEPA filter, quiet mode
    
    Accessories:
    - Phone Case Premium ($29) - Drop protection
    - Screen Protector ($19) - Tempered glass
    - Charging Cable 6ft ($15) - Braided, durable
    
    Warranty:
    - Electronics: 2 years
    - Home: 1 year
    - Accessories: 90 days
    """
}

# Save knowledge base
for doc_name, content in knowledge_base.items():
    with open(f'data/knowledge_base/{doc_name}.txt', 'w') as f:
        f.write(content)
    print(f"Saved: {doc_name}.txt")

print(f"\nKnowledge base created with {len(knowledge_base)} documents")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: ENTITY EXTRACTION DATA
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# NER TRAINING DATA
# ============================================

ner_examples = [
    {
        "text": "I ordered the SmartWatch Pro on December 15th and haven't received it",
        "entities": [
            {"start": 14, "end": 28, "label": "PRODUCT", "text": "SmartWatch Pro"},
            {"start": 32, "end": 44, "label": "DATE", "text": "December 15th"}
        ]
    },
    {
        "text": "My order number is ORD-12345 and I paid $299",
        "entities": [
            {"start": 19, "end": 28, "label": "ORDER_ID", "text": "ORD-12345"},
            {"start": 40, "end": 44, "label": "AMOUNT", "text": "$299"}
        ]
    },
    {
        "text": "Please ship to John Smith at 123 Main Street, New York",
        "entities": [
            {"start": 15, "end": 25, "label": "PERSON", "text": "John Smith"},
            {"start": 29, "end": 54, "label": "ADDRESS", "text": "123 Main Street, New York"}
        ]
    },
    {
        "text": "I need help with the Wireless Earbuds X that I bought last Monday",
        "entities": [
            {"start": 21, "end": 38, "label": "PRODUCT", "text": "Wireless Earbuds X"},
            {"start": 54, "end": 65, "label": "DATE", "text": "last Monday"}
        ]
    },
    {
        "text": "Contact me at john@email.com regarding order ABC-99999",
        "entities": [
            {"start": 14, "end": 28, "label": "EMAIL", "text": "john@email.com"},
            {"start": 45, "end": 54, "label": "ORDER_ID", "text": "ABC-99999"}
        ]
    }
]

# Convert to DataFrame for training
ner_data = []
for example in ner_examples:
    for entity in example['entities']:
        ner_data.append({
            'sentence': example['text'],
            'entity_text': entity['text'],
            'entity_label': entity['label'],
            'start': entity['start'],
            'end': entity['end']
        })

ner_df = pd.DataFrame(ner_data)
print("NER Training Data:")
print(ner_df)
print(f"\nEntity distribution:")
print(ner_df['entity_label'].value_counts())
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: CONVERSATION DATA
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# MULTI-TURN CONVERSATION DATA
# ============================================

conversations = [
    {
        "id": "conv_001",
        "turns": [
            {"role": "user", "content": "Hi, I need help with my order"},
            {"role": "agent", "content": "Hello! I'd be happy to help you with your order. Could you please provide your order number?"},
            {"role": "user", "content": "It's ORD-12345"},
            {"role": "agent", "content": "Thank you! I found your order ORD-12345 for a SmartWatch Pro. It was shipped yesterday and should arrive by Friday. Is there anything specific you'd like to know?"},
            {"role": "user", "content": "Can I change the delivery address?"},
            {"role": "agent", "content": "Since your order is already in transit, I cannot change the delivery address. However, you can contact UPS directly with tracking number 1Z999AA10123456784 to request a delivery change. Would you like me to help with anything else?"},
            {"role": "user", "content": "No that's all, thanks"},
            {"role": "agent", "content": "You're welcome! If you have any other questions, feel free to reach out. Have a great day!"}
        ],
        "intent_flow": ["greeting", "track_order", "shipping_info", "goodbye"],
        "resolution": "resolved",
        "satisfaction": 5
    },
    {
        "id": "conv_002",
        "turns": [
            {"role": "user", "content": "I want a refund for my purchase"},
            {"role": "agent", "content": "I understand you'd like a refund. I'll be happy to help with that. May I have your order number and the reason for the refund?"},
            {"role": "user", "content": "Order ABC-99999, the product is defective"},
            {"role": "agent", "content": "I'm sorry to hear your product is defective. I've initiated a refund for order ABC-99999. You'll receive a prepaid return label via email within 2 hours. Once we receive the item, your refund of $149 will be processed within 3-5 business days."},
            {"role": "user", "content": "Can I get store credit instead? It's faster right?"},
            {"role": "agent", "content": "Great choice! Store credit is instant. I've converted your refund to a $149 store credit, which is now available in your account. You can use it on your next purchase. Is there anything else I can help you with?"},
            {"role": "user", "content": "Perfect, thanks!"},
            {"role": "agent", "content": "You're welcome! Thank you for your patience. Have a wonderful day!"}
        ],
        "intent_flow": ["refund_request", "refund_request", "account_management", "goodbye"],
        "resolution": "resolved",
        "satisfaction": 5
    },
    {
        "id": "conv_003",
        "turns": [
            {"role": "user", "content": "My smart thermostat won't connect to WiFi"},
            {"role": "agent", "content": "I'm sorry to hear you're having connection issues. Let's troubleshoot this together. First, have you tried restarting both your thermostat and router?"},
            {"role": "user", "content": "Yes I did that already"},
            {"role": "agent", "content": "Good. Let's try resetting the WiFi settings on the thermostat. Go to Settings > Network > Reset WiFi. Then, make sure your router is broadcasting on 2.4GHz (the thermostat doesn't support 5GHz). Can you try that?"},
            {"role": "user", "content": "Oh I think my router is on 5GHz only, let me check"},
            {"role": "agent", "content": "That's likely the issue! Most smart home devices require 2.4GHz for better range and compatibility. You should be able to enable 2.4GHz in your router settings. Let me know once you've done that."},
            {"role": "user", "content": "It works now! Thanks so much!"},
            {"role": "agent", "content": "Excellent! I'm glad we got it working! If you have any other questions about your Smart Thermostat, don't hesitate to reach out. Enjoy your smart home!"}
        ],
        "intent_flow": ["technical_support", "technical_support", "technical_support", "goodbye"],
        "resolution": "resolved",
        "satisfaction": 5
    }
]

# Convert to training format
conversation_df = []
for conv in conversations:
    for i, turn in enumerate(conv['turns']):
        context = conv['turns'][:i] if i > 0 else []
        conversation_df.append({
            'conversation_id': conv['id'],
            'turn_number': i,
            'role': turn['role'],
            'content': turn['content'],
            'context': str(context),
            'resolution': conv['resolution'],
            'satisfaction': conv['satisfaction']
        })

conversation_df = pd.DataFrame(conversation_df)
print("Conversation Data:")
print(conversation_df.head(10))
print(f"\nTotal turns: {len(conversation_df)}")
print(f"Conversations: {conversation_df['conversation_id'].nunique()}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: EXPLORATORY DATA ANALYSIS
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# EDA FOR INTENT DATA
# ============================================

# Using Banking77 dataset
print("=" * 60)
print("INTENT DATA EDA")
print("=" * 60)

# Intent distribution
plt.figure(figsize=(14, 8))
intent_counts = train_intent['label'].value_counts()
plt.barh(range(len(intent_counts)), intent_counts.values)
plt.yticks(range(len(intent_counts)), [f"Intent {i}" for i in intent_counts.index])
plt.xlabel('Number of Samples')
plt.title('Intent Distribution (Banking77)')
plt.tight_layout()
plt.savefig('data/processed/intent_distribution.png', dpi=150)
plt.show()

print(f"Total intents: {train_intent['label'].nunique()}")
print(f"Samples per intent: {train_intent['label'].value_counts().describe()}")

# Text length analysis
train_intent['text_length'] = train_intent['text'].str.len()
train_intent['word_count'] = train_intent['text'].str.split().str.len()

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

axes[0].hist(train_intent['text_length'], bins=50, edgecolor='black')
axes[0].set_xlabel('Character Count')
axes[0].set_ylabel('Frequency')
axes[0].set_title('Text Length Distribution')

axes[1].hist(train_intent['word_count'], bins=30, edgecolor='black')
axes[1].set_xlabel('Word Count')
axes[1].set_ylabel('Frequency')
axes[1].set_title('Word Count Distribution')

plt.tight_layout()
plt.savefig('data/processed/text_length_analysis.png', dpi=150)
plt.show()

print(f"\nText length stats:")
print(f"  Mean: {train_intent['text_length'].mean():.1f} chars")
print(f"  Max: {train_intent['text_length'].max()} chars")
print(f"  Min: {train_intent['text_length'].min()} chars")

# ============================================
# WORD FREQUENCY ANALYSIS
# ============================================

from collections import Counter
import re

def get_words(text):
    return re.findall(r'\b[a-z]+\b', text.lower())

all_words = []
for text in train_intent['text']:
    all_words.extend(get_words(text))

word_freq = Counter(all_words)
top_words = word_freq.most_common(30)

plt.figure(figsize=(12, 6))
words, counts = zip(*top_words)
plt.barh(range(len(words)), counts)
plt.yticks(range(len(words)), words)
plt.xlabel('Frequency')
plt.title('Top 30 Most Common Words')
plt.gca().invert_yaxis()
plt.tight_layout()
plt.savefig('data/processed/word_frequency.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: DATA PREPROCESSING PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# TEXT PREPROCESSING FOR AGENT
# ============================================

class AgentPreprocessor:
    """Text preprocessing pipeline for customer support agent"""
    
    def __init__(self):
        self.contractions = {
            "won't": "will not",
            "can't": "cannot",
            "n't": " not",
            "'re": " are",
            "'s": " is",
            "'d": " would",
            "'ll": " will",
            "'ve": " have",
            "'m": " am"
        }
    
    def expand_contractions(self, text):
        """Expand contractions"""
        for contraction, expansion in self.contractions.items():
            text = text.replace(contraction, expansion)
        return text
    
    def normalize_text(self, text):
        """Basic text normalization"""
        # Lowercase
        text = text.lower()
        
        # Expand contractions
        text = self.expand_contractions(text)
        
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        return text
    
    def extract_order_id(self, text):
        """Extract order IDs from text"""
        patterns = [
            r'ORD-\d+',
            r'ORDER-\d+',
            r'[A-Z]{3}-\d{5}',
            r'#\d{6,}'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group().upper()
        return None
    
    def extract_email(self, text):
        """Extract email addresses"""
        pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        match = re.search(pattern, text)
        return match.group() if match else None
    
    def extract_amount(self, text):
        """Extract monetary amounts"""
        pattern = r'\$[\d,]+\.?\d*'
        match = re.search(pattern, text)
        return match.group() if match else None
    
    def preprocess(self, text):
        """Full preprocessing pipeline"""
        normalized = self.normalize_text(text)
        
        return {
            'original': text,
            'normalized': normalized,
            'order_id': self.extract_order_id(text),
            'email': self.extract_email(text),
            'amount': self.extract_amount(text)
        }

# Test preprocessor
preprocessor = AgentPreprocessor()

test_texts = [
    "I can't find my order ORD-12345",
    "Please contact me at john@email.com about my $299 refund",
    "Where's my package? I ordered it last week!"
]

print("Preprocessing Examples:")
for text in test_texts:
    result = preprocessor.preprocess(text)
    print(f"\nOriginal: {result['original']}")
    print(f"Normalized: {result['normalized']}")
    print(f"Order ID: {result['order_id']}")
    print(f"Email: {result['email']}")
    print(f"Amount: {result['amount']}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: SAVE PROCESSED DATA
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# SAVE ALL PROCESSED DATA
# ============================================

# Save intent data
train_intent.to_csv('data/processed/intent_train.csv', index=False)
test_intent.to_csv('data/processed/intent_test.csv', index=False)
synthetic_df.to_csv('data/processed/intent_synthetic.csv', index=False)

# Save NER data
ner_df.to_csv('data/processed/ner_data.csv', index=False)

# Save conversation data
conversation_df.to_csv('data/processed/conversations.csv', index=False)

# Save conversations as JSON for better structure
import json
with open('data/processed/conversations.json', 'w') as f:
    json.dump(conversations, f, indent=2)

print("All data saved to data/processed/")
print(f"\nFiles created:")
for f in os.listdir('data/processed'):
    print(f"  - {f}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8: DATA QUALITY REPORT
# ═══════════════════════════════════════════════════════════════════════════════

```python
print("""
═══════════════════════════════════════════════════════════════════════════════
DATA QUALITY REPORT
═══════════════════════════════════════════════════════════════════════════════
""")

# Intent Data Quality
print("1. INTENT DATA:")
print(f"   - Training samples: {len(train_intent)}")
print(f"   - Test samples: {len(test_intent)}")
print(f"   - Intent classes: {train_intent['label'].nunique()}")
print(f"   - Missing values: {train_intent.isnull().sum().sum()}")
print(f"   - Duplicate texts: {train_intent['text'].duplicated().sum()}")

# NER Data Quality
print("\n2. NER DATA:")
print(f"   - Total annotations: {len(ner_df)}")
print(f"   - Entity types: {ner_df['entity_label'].nunique()}")
print(f"   - Unique sentences: {ner_df['sentence'].nunique()}")

# Conversation Data Quality
print("\n3. CONVERSATION DATA:")
print(f"   - Total conversations: {len(conversations)}")
print(f"   - Total turns: {len(conversation_df)}")
print(f"   - Avg turns/conversation: {len(conversation_df)/len(conversations):.1f}")

# Knowledge Base Quality
print("\n4. KNOWLEDGE BASE:")
print(f"   - Documents: {len(knowledge_base)}")
total_words = sum(len(doc.split()) for doc in knowledge_base.values())
print(f"   - Total words: {total_words}")

print("\n" + "=" * 60)
print("DATA READY FOR AGENT TRAINING!")
print("=" * 60)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 1 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ Project Structure Created
   └── data/raw, data/processed, data/knowledge_base
   └── models/, agent/

✅ Intent Classification Data
   └── Banking77 dataset loaded
   └── 77 intent classes
   └── ~10,000 training samples

✅ Synthetic Intent Data
   └── 11 intent categories
   └── Customer support specific

✅ Knowledge Base Created
   └── Refund policy
   └── Shipping information
   └── Technical support guide
   └── Product catalog

✅ NER Training Data
   └── PRODUCT, ORDER_ID, DATE, AMOUNT, PERSON, EMAIL, ADDRESS

✅ Conversation Data
   └── Multi-turn dialogues
   └── Intent flows
   └── Resolution status

✅ EDA Completed
   └── Intent distribution
   └── Text length analysis
   └── Word frequency

✅ Preprocessing Pipeline
   └── Text normalization
   └── Entity extraction
   └── Contraction expansion
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# NEXT: PHASE 2 - MACHINE LEARNING FOR INTENT CLASSIFICATION
# ═══════════════════════════════════════════════════════════════════════════════

```
🚀 In Phase 2, we'll build:
   • TF-IDF based intent classifier
   • Multi-class classification models
   • Confusion matrix analysis
   • Intent clustering for discovery
```

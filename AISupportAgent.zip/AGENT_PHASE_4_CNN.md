# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 AI CUSTOMER SUPPORT AGENT PROJECT
# PHASE 4: CNN FOR INTENT CLASSIFICATION
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Use Convolutional Neural Networks to capture n-gram patterns in customer queries.

## 📚 CONCEPTS COVERED
- 1D Convolution for Text
- TextCNN Architecture
- Multi-filter Sizes for N-gram Detection
- Feature Map Visualization

## 📊 EXPECTED ACCURACY: ~90-92%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: 1D CNN FOR TEXT
# ═══════════════════════════════════════════════════════════════════════════════

```python
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np
import pandas as pd

# Load preprocessed data (from Phase 3)
# X_train_pad, X_test_pad, y_train, y_test already prepared

print("""
1D CNN FOR TEXT:

Why CNN for intent classification?
- Captures LOCAL patterns (n-grams)
- "track order" as a pattern → track_order intent
- "refund request" as a pattern → refund intent
- Filters learn to detect these phrase patterns!
""")

# ============================================
# SIMPLE 1D CNN
# ============================================

def build_cnn_model(vocab_size, embedding_dim, max_length, num_classes):
    """Simple 1D CNN for intent classification"""
    
    model = keras.Sequential([
        # Embedding
        layers.Embedding(vocab_size, embedding_dim, input_length=max_length),
        
        # Conv block 1
        layers.Conv1D(128, 3, activation='relu', padding='same'),
        layers.MaxPooling1D(2),
        
        # Conv block 2
        layers.Conv1D(64, 3, activation='relu', padding='same'),
        layers.MaxPooling1D(2),
        
        # Conv block 3
        layers.Conv1D(64, 3, activation='relu', padding='same'),
        layers.GlobalMaxPooling1D(),
        
        # Dense layers
        layers.Dense(128, activation='relu'),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation='softmax')
    ])
    
    return model

# Build model
vocab_size = 10000
embedding_dim = 128
max_length = 50
num_classes = 77  # Banking77 dataset

model_cnn = build_cnn_model(vocab_size, embedding_dim, max_length, num_classes)
model_cnn.summary()

model_cnn.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

# Train
from tensorflow.keras.callbacks import EarlyStopping

history_cnn = model_cnn.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=15,
    batch_size=64,
    callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
    verbose=1
)

cnn_loss, cnn_acc = model_cnn.evaluate(X_test_pad, y_test)
print(f"\nSimple CNN Accuracy: {cnn_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: TEXTCNN (KIM'S ARCHITECTURE)
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# TEXTCNN WITH MULTIPLE FILTER SIZES
# ============================================

print("""
TEXTCNN ARCHITECTURE:

Multiple filter sizes capture different n-grams:
- Filter size 2: Bigrams ("track order", "refund request")
- Filter size 3: Trigrams ("how to track", "need a refund")
- Filter size 4: 4-grams ("I want to return")
- Filter size 5: 5-grams ("can you help me with")

All features concatenated for final classification!
""")

def build_textcnn(vocab_size, embedding_dim, max_length, num_classes, 
                  filter_sizes=[2, 3, 4, 5], num_filters=128):
    """TextCNN with multiple filter sizes"""
    
    # Input
    inputs = keras.Input(shape=(max_length,))
    
    # Embedding
    embedding = layers.Embedding(vocab_size, embedding_dim)(inputs)
    
    # Multiple convolutions with different filter sizes
    conv_outputs = []
    
    for filter_size in filter_sizes:
        # Conv layer
        conv = layers.Conv1D(num_filters, filter_size, activation='relu')(embedding)
        # Global max pooling
        pooled = layers.GlobalMaxPooling1D()(conv)
        conv_outputs.append(pooled)
    
    # Concatenate all filter outputs
    concatenated = layers.Concatenate()(conv_outputs)
    
    # Dense layers
    x = layers.Dense(256, activation='relu')(concatenated)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(128, activation='relu')(x)
    x = layers.Dropout(0.3)(x)
    
    # Output
    outputs = layers.Dense(num_classes, activation='softmax')(x)
    
    model = keras.Model(inputs=inputs, outputs=outputs)
    return model

# Build TextCNN
model_textcnn = build_textcnn(
    vocab_size=vocab_size,
    embedding_dim=embedding_dim,
    max_length=max_length,
    num_classes=num_classes,
    filter_sizes=[2, 3, 4, 5],
    num_filters=128
)

model_textcnn.summary()

model_textcnn.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

history_textcnn = model_textcnn.fit(
    X_train_pad, y_train,
    validation_split=0.2,
    epochs=15,
    batch_size=64,
    callbacks=[EarlyStopping(patience=3, restore_best_weights=True)],
    verbose=1
)

textcnn_loss, textcnn_acc = model_textcnn.evaluate(X_test_pad, y_test)
print(f"\nTextCNN Accuracy: {textcnn_acc:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: CNN WITH ATTENTION
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# CNN + ATTENTION FOR INTERPRETABILITY
# ============================================

class AttentionLayer(layers.Layer):
    """Attention layer for CNN outputs"""
    
    def __init__(self, **kwargs):
        super(AttentionLayer, self).__init__(**kwargs)
    
    def build(self, input_shape):
        self.W = self.add_weight(
            shape=(input_shape[-1], 1),
            initializer='glorot_uniform',
            trainable=True,
            name='attention_weight'
        )
        super(AttentionLayer, self).build(input_shape)
    
    def call(self, x):
        # x shape: (batch, seq_len, features)
        attention_scores = tf.nn.softmax(tf.matmul(x, self.W), axis=1)
        weighted = x * attention_scores
        return tf.reduce_sum(weighted, axis=1), attention_scores

def build_cnn_attention(vocab_size, embedding_dim, max_length, num_classes):
    """CNN with attention for interpretable intent classification"""
    
    inputs = keras.Input(shape=(max_length,))
    embedding = layers.Embedding(vocab_size, embedding_dim)(inputs)
    
    # CNN
    conv = layers.Conv1D(128, 3, activation='relu', padding='same')(embedding)
    conv = layers.Conv1D(128, 3, activation='relu', padding='same')(conv)
    
    # Attention
    attention_layer = AttentionLayer()
    attended, attention_weights = attention_layer(conv)
    
    # Classification
    x = layers.Dense(128, activation='relu')(attended)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(num_classes, activation='softmax')(x)
    
    model = keras.Model(inputs=inputs, outputs=outputs)
    return model

model_cnn_attn = build_cnn_attention(vocab_size, embedding_dim, max_length, num_classes)
model_cnn_attn.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

print("CNN + Attention model built")
print("This allows us to see which words the model focuses on!")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: VISUALIZE CNN FILTERS
# ═══════════════════════════════════════════════════════════════════════════════

```python
import matplotlib.pyplot as plt

# ============================================
# FILTER VISUALIZATION
# ============================================

def visualize_filters(model, layer_name, num_filters=16):
    """Visualize learned CNN filters"""
    
    # Get the layer
    for layer in model.layers:
        if layer.name == layer_name or isinstance(layer, layers.Conv1D):
            weights = layer.get_weights()[0]
            break
    
    # Plot filters
    fig, axes = plt.subplots(4, 4, figsize=(12, 12))
    axes = axes.flatten()
    
    for i in range(min(num_filters, len(axes))):
        axes[i].imshow(weights[:, :, i].T, cmap='viridis', aspect='auto')
        axes[i].set_title(f'Filter {i+1}')
        axes[i].axis('off')
    
    plt.suptitle('Learned CNN Filters')
    plt.tight_layout()
    plt.savefig('models/cnn_filters.png', dpi=150)
    plt.show()

# Visualize
# visualize_filters(model_textcnn, 'conv1d')

# ============================================
# FEATURE MAP ANALYSIS
# ============================================

def get_feature_maps(model, text, tokenizer, max_length):
    """Get intermediate feature maps for a text"""
    
    # Preprocess
    seq = tokenizer.texts_to_sequences([text])
    padded = pad_sequences(seq, maxlen=max_length, padding='post')
    
    # Create feature extraction model
    layer_outputs = [layer.output for layer in model.layers if isinstance(layer, layers.Conv1D)]
    feature_model = keras.Model(inputs=model.input, outputs=layer_outputs)
    
    # Get features
    features = feature_model.predict(padded, verbose=0)
    
    return features

print("Feature extraction functions defined")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: MODEL COMPARISON
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# COMPARE ALL CNN MODELS
# ============================================

print("\n" + "=" * 60)
print("CNN MODEL COMPARISON")
print("=" * 60)

results = {
    'Simple CNN': cnn_acc,
    'TextCNN': textcnn_acc,
}

for name, acc in sorted(results.items(), key=lambda x: x[1], reverse=True):
    print(f"{name}: {acc:.2%}")

# Plot comparison
plt.figure(figsize=(10, 6))
plt.bar(results.keys(), results.values(), color=['#3498db', '#2ecc71'])
plt.ylabel('Accuracy')
plt.title('CNN Models Comparison')
plt.ylim(0.85, 0.95)

for i, (name, acc) in enumerate(results.items()):
    plt.text(i, acc + 0.005, f'{acc:.2%}', ha='center', fontsize=12)

plt.tight_layout()
plt.savefig('models/cnn_comparison.png', dpi=150)
plt.show()

# Save best model
model_textcnn.save('models/intent_textcnn.h5')
print("\nBest model saved: models/intent_textcnn.h5")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: CNN INTENT CLASSIFIER CLASS
# ═══════════════════════════════════════════════════════════════════════════════

```python
import pickle

class CNNIntentClassifier:
    """CNN-based intent classifier for agent"""
    
    def __init__(self, model_path='models/intent_textcnn.h5',
                 tokenizer_path='models/intent_tokenizer.pkl',
                 mappings_path='models/intent_label_mappings.pkl'):
        
        self.model = keras.models.load_model(model_path)
        
        with open(tokenizer_path, 'rb') as f:
            self.tokenizer = pickle.load(f)
        
        with open(mappings_path, 'rb') as f:
            mappings = pickle.load(f)
            self.idx_to_label = mappings['idx_to_label']
        
        self.max_length = 50
    
    def predict(self, text):
        """Predict intent"""
        seq = self.tokenizer.texts_to_sequences([text])
        padded = pad_sequences(seq, maxlen=self.max_length, padding='post')
        
        proba = self.model.predict(padded, verbose=0)[0]
        top_idx = proba.argmax()
        
        return {
            'intent': self.idx_to_label[top_idx],
            'confidence': float(proba[top_idx]),
            'all_scores': {self.idx_to_label[i]: float(p) for i, p in enumerate(proba)}
        }

print("CNNIntentClassifier class defined")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 4 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ 1D CNN for Text
   └── Conv1D + MaxPooling
   └── ~88-90% accuracy

✅ TextCNN (Kim's Architecture)
   └── Multiple filter sizes [2,3,4,5]
   └── Parallel convolutions
   └── ~90-92% accuracy

✅ CNN + Attention
   └── Interpretable predictions
   └── Word importance visualization

✅ Filter Visualization
   └── Learned patterns
   └── Feature maps

✅ Production Classifier
   └── CNNIntentClassifier class
   └── Easy inference
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY: ~90-92%
# NEXT: PHASE 5 - RNN/LSTM FOR CONTEXT UNDERSTANDING
# ═══════════════════════════════════════════════════════════════════════════════

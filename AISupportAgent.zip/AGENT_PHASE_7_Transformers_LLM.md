# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 AI CUSTOMER SUPPORT AGENT PROJECT
# PHASE 7: TRANSFORMERS & LLM INTEGRATION
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Integrate BERT for understanding and GPT/LLMs for response generation.

## 📚 CONCEPTS COVERED
- BERT for Intent & Entity Extraction
- GPT for Response Generation
- LLM API Integration (OpenAI, Anthropic)
- Prompt Engineering for Agents

## 📊 EXPECTED ACCURACY: ~95%+ with LLMs

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: BERT FOR INTENT CLASSIFICATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from transformers import Trainer, TrainingArguments, pipeline
import torch
import pandas as pd
from datasets import Dataset

print("""
BERT FOR CUSTOMER SUPPORT AGENT:

1. INTENT CLASSIFICATION
   - Fine-tune BERT on intent data
   - 95%+ accuracy
   - Handles out-of-domain queries

2. ENTITY EXTRACTION (NER)
   - Extract ORDER_ID, PRODUCT, DATE, etc.
   - Use BERT-NER or fine-tuned model

3. SEMANTIC SIMILARITY
   - Find similar past queries
   - Knowledge retrieval
""")

# ============================================
# FINE-TUNE BERT FOR INTENT
# ============================================

model_name = "bert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(model_name)

# Load data
train_df = pd.read_csv('data/processed/intent_train.csv')
test_df = pd.read_csv('data/processed/intent_test.csv')

# Create datasets
train_dataset = Dataset.from_pandas(train_df[['text', 'label']])
test_dataset = Dataset.from_pandas(test_df[['text', 'label']])

# Tokenize
def tokenize_function(examples):
    return tokenizer(examples['text'], padding='max_length', truncation=True, max_length=64)

train_dataset = train_dataset.map(tokenize_function, batched=True)
test_dataset = test_dataset.map(tokenize_function, batched=True)

# Load model
num_labels = train_df['label'].nunique()
model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)

# Training arguments
training_args = TrainingArguments(
    output_dir='./models/bert_intent',
    num_train_epochs=3,
    per_device_train_batch_size=32,
    evaluation_strategy='epoch',
    save_strategy='epoch',
    load_best_model_at_end=True
)

# Train
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset
)

trainer.train()

# Save
trainer.save_model('./models/bert_intent_final')
tokenizer.save_pretrained('./models/bert_intent_final')

print("BERT intent classifier trained and saved!")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: BERT FOR NAMED ENTITY RECOGNITION
# ═══════════════════════════════════════════════════════════════════════════════

```python
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline

# ============================================
# BERT NER FOR ENTITY EXTRACTION
# ============================================

# Use pre-trained NER model
ner_model_name = "dslim/bert-base-NER"
ner_tokenizer = AutoTokenizer.from_pretrained(ner_model_name)
ner_model = AutoModelForTokenClassification.from_pretrained(ner_model_name)

ner_pipeline = pipeline("ner", model=ner_model, tokenizer=ner_tokenizer, aggregation_strategy="simple")

# Test NER
test_texts = [
    "My order ORD-12345 was supposed to arrive on December 15th",
    "Please contact John Smith at john@email.com",
    "I bought the SmartWatch Pro for $299"
]

print("Entity Extraction Examples:")
for text in test_texts:
    entities = ner_pipeline(text)
    print(f"\nText: {text}")
    print(f"Entities: {entities}")

# ============================================
# CUSTOM ENTITY EXTRACTOR FOR AGENT
# ============================================

import re

class AgentEntityExtractor:
    """Extract customer support specific entities"""
    
    def __init__(self):
        self.ner_pipeline = ner_pipeline
        
        # Custom patterns
        self.patterns = {
            'ORDER_ID': r'(?:ORD|ORDER|order)?[-#]?\s*([A-Z]{2,3}[-]?\d{4,6}|\d{5,8})',
            'EMAIL': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            'PHONE': r'(?:\+1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',
            'AMOUNT': r'\$[\d,]+\.?\d*',
            'DATE': r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s*\d{1,2}(?:st|nd|rd|th)?(?:,?\s*\d{4})?',
            'PRODUCT': r'(?:SmartWatch|Earbuds|Charger|Thermostat|Vacuum|Purifier)\s*(?:Pro|X|V\d)?'
        }
    
    def extract(self, text):
        """Extract all entities from text"""
        entities = {}
        
        # Pattern-based extraction
        for entity_type, pattern in self.patterns.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                entities[entity_type] = matches[0] if len(matches) == 1 else matches
        
        # BERT NER for names, locations, etc.
        ner_results = self.ner_pipeline(text)
        for entity in ner_results:
            entity_type = entity['entity_group']
            if entity_type not in entities:
                entities[entity_type] = []
            entities[entity_type] = entity['word']
        
        return entities

# Test
extractor = AgentEntityExtractor()

test = "I'm John Smith, my order ORD-12345 for $299 hasn't arrived since Dec 15th. Email: john@email.com"
entities = extractor.extract(test)
print(f"\nExtracted entities from: {test}")
print(entities)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: LLM INTEGRATION FOR RESPONSE GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# LLM API INTEGRATION
# ============================================

import os

class LLMResponseGenerator:
    """Generate responses using LLM APIs"""
    
    def __init__(self, provider='openai'):
        self.provider = provider
        
        # System prompt for customer support agent
        self.system_prompt = """You are a helpful customer support agent for an e-commerce company.
        
Your responsibilities:
- Help customers with orders, refunds, and technical issues
- Be polite, professional, and empathetic
- Provide accurate information based on the context provided
- Ask clarifying questions when needed
- Never make up information about orders or policies

Guidelines:
- Keep responses concise but helpful
- Use the customer's name if provided
- Acknowledge their frustration if they're upset
- Provide specific next steps when possible
"""
    
    def generate_openai(self, user_message, context=None):
        """Generate response using OpenAI API"""
        import openai
        
        messages = [
            {"role": "system", "content": self.system_prompt}
        ]
        
        if context:
            messages.append({"role": "system", "content": f"Context: {context}"})
        
        messages.append({"role": "user", "content": user_message})
        
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            max_tokens=200,
            temperature=0.7
        )
        
        return response.choices[0].message.content
    
    def generate_anthropic(self, user_message, context=None):
        """Generate response using Anthropic API"""
        import anthropic
        
        client = anthropic.Anthropic()
        
        prompt = f"{self.system_prompt}\n\n"
        if context:
            prompt += f"Context: {context}\n\n"
        prompt += f"Customer: {user_message}\n\nAgent:"
        
        response = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=200,
            messages=[{"role": "user", "content": prompt}]
        )
        
        return response.content[0].text
    
    def generate(self, user_message, context=None, intent=None, entities=None):
        """Generate response with full context"""
        
        # Build context string
        context_parts = []
        if context:
            context_parts.append(f"Previous conversation: {context}")
        if intent:
            context_parts.append(f"Detected intent: {intent}")
        if entities:
            context_parts.append(f"Extracted information: {entities}")
        
        full_context = "\n".join(context_parts) if context_parts else None
        
        if self.provider == 'openai':
            return self.generate_openai(user_message, full_context)
        elif self.provider == 'anthropic':
            return self.generate_anthropic(user_message, full_context)
        else:
            return "LLM provider not configured"

print("LLM Response Generator configured")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: PROMPT ENGINEERING FOR AGENTS
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# PROMPT TEMPLATES FOR DIFFERENT SCENARIOS
# ============================================

class AgentPromptManager:
    """Manage prompts for different agent scenarios"""
    
    def __init__(self):
        self.prompts = {
            'track_order': """You are helping a customer track their order.
            
Order Information:
- Order ID: {order_id}
- Status: {status}
- Shipped: {ship_date}
- Expected Delivery: {delivery_date}
- Tracking: {tracking_number}

Provide a helpful response about the order status.""",

            'refund_request': """You are processing a refund request.
            
Order Information:
- Order ID: {order_id}
- Amount: {amount}
- Reason: {reason}
- Refund Policy: 30-day money-back guarantee

Help the customer with their refund. If eligible, confirm the refund. If not, explain why politely.""",

            'technical_support': """You are providing technical support.
            
Product: {product}
Issue: {issue}
Steps Already Tried: {steps_tried}

Guide the customer through troubleshooting steps. Be patient and clear.""",

            'complaint_handling': """You are handling a customer complaint.
            
Complaint: {complaint}
Customer History: {history}

Acknowledge their frustration, apologize sincerely, and offer a resolution.""",

            'general': """You are a customer support agent.
            
Customer Query: {query}
Detected Intent: {intent}
Available Information: {context}

Provide a helpful, accurate response."""
        }
    
    def get_prompt(self, scenario, **kwargs):
        """Get formatted prompt for scenario"""
        template = self.prompts.get(scenario, self.prompts['general'])
        return template.format(**kwargs)
    
    def build_conversation_prompt(self, history, current_query, context=None):
        """Build prompt from conversation history"""
        prompt = "Previous conversation:\n"
        for turn in history[-5:]:  # Last 5 turns
            role = "Customer" if turn['role'] == 'user' else "Agent"
            prompt += f"{role}: {turn['content']}\n"
        
        prompt += f"\nCurrent query: {current_query}\n"
        
        if context:
            prompt += f"\nRelevant context: {context}\n"
        
        prompt += "\nProvide a helpful response:"
        
        return prompt

# Test
prompt_manager = AgentPromptManager()

order_prompt = prompt_manager.get_prompt(
    'track_order',
    order_id='ORD-12345',
    status='In Transit',
    ship_date='Dec 20',
    delivery_date='Dec 25',
    tracking_number='1Z999AA10123456784'
)

print("Generated Prompt:")
print(order_prompt)
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: COMPLETE TRANSFORMER-BASED AGENT
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# TRANSFORMER-POWERED AGENT
# ============================================

class TransformerAgent:
    """Complete agent using Transformers"""
    
    def __init__(self):
        # Intent classifier (BERT)
        self.intent_classifier = pipeline(
            "text-classification",
            model="./models/bert_intent_final"
        )
        
        # Entity extractor
        self.entity_extractor = AgentEntityExtractor()
        
        # Response generator
        self.response_generator = LLMResponseGenerator(provider='openai')
        
        # Prompt manager
        self.prompt_manager = AgentPromptManager()
        
        # Conversation history
        self.history = []
    
    def process(self, user_message):
        """Process user message and generate response"""
        
        # Step 1: Classify intent
        intent_result = self.intent_classifier(user_message)[0]
        intent = intent_result['label']
        confidence = intent_result['score']
        
        # Step 2: Extract entities
        entities = self.entity_extractor.extract(user_message)
        
        # Step 3: Generate response
        if confidence < 0.5:
            # Low confidence - ask for clarification
            response = "I want to make sure I understand correctly. Could you please rephrase or provide more details?"
        else:
            # Generate with context
            response = self.response_generator.generate(
                user_message,
                context=self._get_context(),
                intent=intent,
                entities=entities
            )
        
        # Update history
        self.history.append({'role': 'user', 'content': user_message})
        self.history.append({'role': 'agent', 'content': response})
        
        return {
            'response': response,
            'intent': intent,
            'confidence': confidence,
            'entities': entities
        }
    
    def _get_context(self):
        """Get conversation context"""
        if not self.history:
            return None
        return " | ".join([f"{t['role']}: {t['content'][:50]}" for t in self.history[-4:]])
    
    def reset(self):
        """Reset conversation"""
        self.history = []

print("TransformerAgent class defined")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 7 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ BERT Intent Classification
   └── Fine-tuned on intent data
   └── ~95% accuracy

✅ BERT NER for Entity Extraction
   └── Pre-trained + custom patterns
   └── ORDER_ID, PRODUCT, AMOUNT, etc.

✅ LLM Integration
   └── OpenAI API
   └── Anthropic API
   └── System prompts

✅ Prompt Engineering
   └── Scenario-specific prompts
   └── Conversation context
   └── Entity injection

✅ Complete Transformer Agent
   └── Intent → Entities → Response
   └── Conversation history
   └── Confidence thresholding
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY: ~95%+ with LLMs
# NEXT: PHASE 8 - NLP PREPROCESSING FOR AGENTS
# ═══════════════════════════════════════════════════════════════════════════════

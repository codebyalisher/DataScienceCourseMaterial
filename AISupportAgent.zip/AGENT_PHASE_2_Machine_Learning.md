# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 AI CUSTOMER SUPPORT AGENT PROJECT
# PHASE 2: MACHINE LEARNING FOR INTENT CLASSIFICATION
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Build traditional ML models to classify customer intents - the foundation of our agent.

## 📚 CONCEPTS COVERED
- Multi-class Text Classification
- TF-IDF Vectorization
- Logistic Regression, SVM, Random Forest
- Confusion Matrix Analysis
- Intent Clustering for Discovery

## 📊 EXPECTED ACCURACY: ~85-90%

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: LOAD AND PREPARE DATA
# ═══════════════════════════════════════════════════════════════════════════════

```python
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns
import re

# Load intent data
train_df = pd.read_csv('data/processed/intent_train.csv')
test_df = pd.read_csv('data/processed/intent_test.csv')

print(f"Training samples: {len(train_df)}")
print(f"Test samples: {len(test_df)}")
print(f"Intent classes: {train_df['label'].nunique()}")

# Preprocessing
def preprocess_text(text):
    text = str(text).lower()
    text = re.sub(r'[^a-z\s]', '', text)
    return ' '.join(text.split())

train_df['processed_text'] = train_df['text'].apply(preprocess_text)
test_df['processed_text'] = test_df['text'].apply(preprocess_text)

# Encode labels
label_encoder = LabelEncoder()
train_df['label_encoded'] = label_encoder.fit_transform(train_df['label'])
test_df['label_encoded'] = label_encoder.transform(test_df['label'])

X_train = train_df['processed_text']
y_train = train_df['label_encoded']
X_test = test_df['processed_text']
y_test = test_df['label_encoded']

print(f"\nLabel classes: {len(label_encoder.classes_)}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: TF-IDF VECTORIZATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# TF-IDF VECTORIZER
# ============================================

print("""
TF-IDF FOR INTENT CLASSIFICATION:
- Captures important words for each intent
- N-grams capture phrases like "track order", "refund request"
- Max features limits vocabulary size
""")

tfidf = TfidfVectorizer(
    max_features=5000,
    ngram_range=(1, 2),  # Unigrams + Bigrams
    min_df=2,            # Minimum document frequency
    max_df=0.95,         # Maximum document frequency
    sublinear_tf=True    # Apply log scaling
)

X_train_tfidf = tfidf.fit_transform(X_train)
X_test_tfidf = tfidf.transform(X_test)

print(f"TF-IDF matrix shape: {X_train_tfidf.shape}")
print(f"Vocabulary size: {len(tfidf.vocabulary_)}")

# Top features
feature_names = tfidf.get_feature_names_out()
print(f"\nSample features: {feature_names[:20]}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: TRAIN MULTIPLE CLASSIFIERS
# ═══════════════════════════════════════════════════════════════════════════════

```python
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import time

# ============================================
# MODEL TRAINING
# ============================================

models = {
    'Logistic Regression': LogisticRegression(max_iter=1000, multi_class='multinomial'),
    'Linear SVM': LinearSVC(max_iter=2000),
    'Naive Bayes': MultinomialNB(),
    'Random Forest': RandomForestClassifier(n_estimators=100, n_jobs=-1),
    'KNN': KNeighborsClassifier(n_neighbors=5)
}

results = {}

print("=" * 60)
print("TRAINING INTENT CLASSIFIERS")
print("=" * 60)

for name, model in models.items():
    print(f"\nTraining {name}...")
    start_time = time.time()
    
    model.fit(X_train_tfidf, y_train)
    train_time = time.time() - start_time
    
    # Predict
    y_pred = model.predict(X_test_tfidf)
    accuracy = accuracy_score(y_test, y_pred)
    
    results[name] = {
        'model': model,
        'accuracy': accuracy,
        'train_time': train_time,
        'predictions': y_pred
    }
    
    print(f"  Accuracy: {accuracy:.2%}")
    print(f"  Training time: {train_time:.2f}s")

# Summary
print("\n" + "=" * 60)
print("RESULTS SUMMARY")
print("=" * 60)

for name, result in sorted(results.items(), key=lambda x: x[1]['accuracy'], reverse=True):
    print(f"{name}: {result['accuracy']:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: DETAILED EVALUATION
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# BEST MODEL ANALYSIS
# ============================================

best_model_name = max(results, key=lambda x: results[x]['accuracy'])
best_model = results[best_model_name]['model']
best_predictions = results[best_model_name]['predictions']

print(f"\nBest Model: {best_model_name}")
print(f"Accuracy: {results[best_model_name]['accuracy']:.2%}")

# Classification Report
print("\n" + "=" * 60)
print("CLASSIFICATION REPORT (Top 10 Classes)")
print("=" * 60)

report = classification_report(y_test, best_predictions, 
                               target_names=[str(i) for i in range(len(label_encoder.classes_))],
                               output_dict=True)

# Show top performing intents
intent_performance = []
for i, intent_name in enumerate(label_encoder.classes_):
    if str(i) in report:
        intent_performance.append({
            'intent': intent_name,
            'precision': report[str(i)]['precision'],
            'recall': report[str(i)]['recall'],
            'f1': report[str(i)]['f1-score'],
            'support': report[str(i)]['support']
        })

perf_df = pd.DataFrame(intent_performance)
print(perf_df.sort_values('f1', ascending=False).head(10))

# ============================================
# CONFUSION MATRIX
# ============================================

plt.figure(figsize=(16, 14))
cm = confusion_matrix(y_test, best_predictions)

# Normalize
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

sns.heatmap(cm_normalized, cmap='Blues', fmt='.2f')
plt.title(f'Confusion Matrix - {best_model_name}')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.tight_layout()
plt.savefig('models/intent_confusion_matrix.png', dpi=150)
plt.show()
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: CONFIDENCE SCORES AND THRESHOLDING
# ═══════════════════════════════════════════════════════════════════════════════

```python
# ============================================
# CONFIDENCE-BASED PREDICTIONS
# ============================================

print("""
CONFIDENCE THRESHOLDING FOR AGENTS:

Why it matters:
- Low confidence → Ask for clarification
- Medium confidence → Provide answer with disclaimer
- High confidence → Direct answer

This prevents the agent from giving wrong answers confidently!
""")

# Use Logistic Regression for probability scores
lr_model = results['Logistic Regression']['model']

# Get probability scores
y_proba = lr_model.predict_proba(X_test_tfidf)
y_pred_labels = lr_model.predict(X_test_tfidf)
confidence_scores = y_proba.max(axis=1)

# Analyze confidence distribution
print("Confidence Score Distribution:")
print(f"  Mean: {confidence_scores.mean():.3f}")
print(f"  Median: {np.median(confidence_scores):.3f}")
print(f"  Min: {confidence_scores.min():.3f}")
print(f"  Max: {confidence_scores.max():.3f}")

# Plot confidence distribution
plt.figure(figsize=(10, 5))
plt.hist(confidence_scores, bins=50, edgecolor='black')
plt.axvline(x=0.5, color='r', linestyle='--', label='Threshold 0.5')
plt.axvline(x=0.7, color='g', linestyle='--', label='Threshold 0.7')
plt.xlabel('Confidence Score')
plt.ylabel('Frequency')
plt.title('Prediction Confidence Distribution')
plt.legend()
plt.savefig('models/confidence_distribution.png', dpi=150)
plt.show()

# ============================================
# THRESHOLD-BASED ACCURACY
# ============================================

thresholds = [0.3, 0.5, 0.7, 0.9]

print("\nAccuracy at Different Confidence Thresholds:")
for threshold in thresholds:
    mask = confidence_scores >= threshold
    if mask.sum() > 0:
        acc = accuracy_score(y_test[mask], y_pred_labels[mask])
        coverage = mask.mean()
        print(f"  Threshold {threshold}: Accuracy={acc:.2%}, Coverage={coverage:.2%}")

# ============================================
# AGENT DECISION FUNCTION
# ============================================

def get_intent_with_confidence(text, vectorizer, model, label_encoder, 
                                high_threshold=0.7, low_threshold=0.3):
    """
    Get intent prediction with confidence-based response strategy
    """
    # Preprocess and vectorize
    processed = preprocess_text(text)
    vectorized = vectorizer.transform([processed])
    
    # Predict
    proba = model.predict_proba(vectorized)[0]
    predicted_class = proba.argmax()
    confidence = proba.max()
    
    # Get top 3 predictions
    top_3_idx = proba.argsort()[-3:][::-1]
    top_3 = [(label_encoder.classes_[i], proba[i]) for i in top_3_idx]
    
    # Determine response strategy
    if confidence >= high_threshold:
        strategy = "DIRECT_ANSWER"
    elif confidence >= low_threshold:
        strategy = "ANSWER_WITH_CONFIRMATION"
    else:
        strategy = "ASK_CLARIFICATION"
    
    return {
        'intent': label_encoder.classes_[predicted_class],
        'confidence': confidence,
        'strategy': strategy,
        'top_3': top_3
    }

# Test
test_queries = [
    "I want to track my order",
    "Something something blah blah",
    "Help me with my account"
]

print("\nIntent Prediction Examples:")
for query in test_queries:
    result = get_intent_with_confidence(query, tfidf, lr_model, label_encoder)
    print(f"\nQuery: {query}")
    print(f"  Intent: {result['intent']}")
    print(f"  Confidence: {result['confidence']:.2%}")
    print(f"  Strategy: {result['strategy']}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: INTENT CLUSTERING FOR DISCOVERY
# ═══════════════════════════════════════════════════════════════════════════════

```python
from sklearn.cluster import KMeans
from sklearn.decomposition import TruncatedSVD
from sklearn.manifold import TSNE

# ============================================
# UNSUPERVISED INTENT DISCOVERY
# ============================================

print("""
INTENT CLUSTERING:
- Discover NEW intents from unlabeled data
- Group similar queries together
- Helpful for expanding intent taxonomy
""")

# Reduce dimensionality first
svd = TruncatedSVD(n_components=50, random_state=42)
X_train_reduced = svd.fit_transform(X_train_tfidf)

print(f"Explained variance: {svd.explained_variance_ratio_.sum():.2%}")

# K-Means clustering
n_clusters = 20
kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
cluster_labels = kmeans.fit_predict(X_train_reduced)

# Analyze clusters
print(f"\nCluster Distribution:")
cluster_counts = pd.Series(cluster_labels).value_counts().sort_index()
print(cluster_counts)

# ============================================
# VISUALIZE CLUSTERS WITH t-SNE
# ============================================

# Use subset for faster t-SNE
sample_size = 2000
indices = np.random.choice(len(X_train_reduced), sample_size, replace=False)

tsne = TSNE(n_components=2, random_state=42, perplexity=30)
X_tsne = tsne.fit_transform(X_train_reduced[indices])

plt.figure(figsize=(12, 10))
scatter = plt.scatter(X_tsne[:, 0], X_tsne[:, 1], 
                      c=cluster_labels[indices], cmap='tab20', 
                      alpha=0.6, s=10)
plt.colorbar(scatter, label='Cluster')
plt.title('Intent Clusters (t-SNE Visualization)')
plt.xlabel('t-SNE 1')
plt.ylabel('t-SNE 2')
plt.savefig('models/intent_clusters.png', dpi=150)
plt.show()

# ============================================
# ANALYZE CLUSTER CONTENT
# ============================================

def get_cluster_keywords(cluster_id, n_keywords=10):
    """Get top keywords for a cluster"""
    cluster_mask = cluster_labels == cluster_id
    cluster_texts = X_train[cluster_mask]
    
    # Get word frequencies
    from collections import Counter
    all_words = []
    for text in cluster_texts:
        all_words.extend(text.split())
    
    word_freq = Counter(all_words)
    return word_freq.most_common(n_keywords)

print("\nCluster Keywords (Sample):")
for i in range(min(5, n_clusters)):
    keywords = get_cluster_keywords(i, 5)
    print(f"\nCluster {i}: {[w for w, _ in keywords]}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: SAVE MODELS
# ═══════════════════════════════════════════════════════════════════════════════

```python
import pickle

# ============================================
# SAVE TRAINED MODELS
# ============================================

# Save best model
with open('models/intent_classifier.pkl', 'wb') as f:
    pickle.dump(best_model, f)

# Save Logistic Regression (for probabilities)
with open('models/intent_classifier_proba.pkl', 'wb') as f:
    pickle.dump(lr_model, f)

# Save vectorizer
with open('models/intent_tfidf_vectorizer.pkl', 'wb') as f:
    pickle.dump(tfidf, f)

# Save label encoder
with open('models/intent_label_encoder.pkl', 'wb') as f:
    pickle.dump(label_encoder, f)

print("Models saved:")
print("  - models/intent_classifier.pkl")
print("  - models/intent_classifier_proba.pkl")
print("  - models/intent_tfidf_vectorizer.pkl")
print("  - models/intent_label_encoder.pkl")

# ============================================
# CREATE INTENT CLASSIFIER CLASS
# ============================================

class IntentClassifier:
    """Production-ready intent classifier for agent"""
    
    def __init__(self, model_path='models/intent_classifier_proba.pkl',
                 vectorizer_path='models/intent_tfidf_vectorizer.pkl',
                 encoder_path='models/intent_label_encoder.pkl'):
        
        with open(model_path, 'rb') as f:
            self.model = pickle.load(f)
        with open(vectorizer_path, 'rb') as f:
            self.vectorizer = pickle.load(f)
        with open(encoder_path, 'rb') as f:
            self.label_encoder = pickle.load(f)
    
    def predict(self, text, return_proba=False):
        """Predict intent for a single text"""
        processed = preprocess_text(text)
        vectorized = self.vectorizer.transform([processed])
        
        if return_proba:
            proba = self.model.predict_proba(vectorized)[0]
            predicted_idx = proba.argmax()
            return {
                'intent': self.label_encoder.classes_[predicted_idx],
                'confidence': proba.max(),
                'all_probabilities': dict(zip(self.label_encoder.classes_, proba))
            }
        else:
            predicted = self.model.predict(vectorized)[0]
            return self.label_encoder.classes_[predicted]
    
    def predict_batch(self, texts):
        """Predict intents for multiple texts"""
        return [self.predict(text) for text in texts]

# Test the class
classifier = IntentClassifier()
test_result = classifier.predict("I want to track my package", return_proba=True)
print(f"\nTest prediction:")
print(f"  Intent: {test_result['intent']}")
print(f"  Confidence: {test_result['confidence']:.2%}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# PHASE 2 CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════════

```
✅ TF-IDF Vectorization
   └── Unigrams + Bigrams
   └── 5000 max features
   └── Sublinear TF scaling

✅ Multi-class Classification
   └── Logistic Regression: ~87%
   └── Linear SVM: ~88%
   └── Random Forest: ~82%
   └── Naive Bayes: ~84%

✅ Confidence Thresholding
   └── High confidence → Direct answer
   └── Medium → Answer with confirmation
   └── Low → Ask clarification

✅ Intent Clustering
   └── K-Means for discovery
   └── t-SNE visualization
   └── Cluster keyword analysis

✅ Production-Ready Classifier
   └── IntentClassifier class
   └── Batch prediction support
   └── Probability scores
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY: ~87-90%
# NEXT: PHASE 3 - DEEP LEARNING INTENT CLASSIFIER
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 AI CUSTOMER SUPPORT AGENT PROJECT
# PHASE 8: NLP PREPROCESSING FOR AGENTS
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Build robust NLP preprocessing pipeline for agent input understanding.

---

```python
import re
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import spacy

nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# ============================================
# AGENT PREPROCESSING PIPELINE
# ============================================

class AgentNLPProcessor:
    """Complete NLP preprocessing for agent"""
    
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
        
        # Keep important words for customer support
        self.keep_words = {'not', 'no', 'never', 'cannot', "can't", "won't", 
                          'refund', 'return', 'help', 'order', 'track'}
        self.stop_words -= self.keep_words
        
        # Spelling corrections common in support
        self.corrections = {
            'recieve': 'receive', 'refud': 'refund', 'ordr': 'order',
            'shippng': 'shipping', 'delivry': 'delivery', 'plz': 'please',
            'thx': 'thanks', 'asap': 'as soon as possible'
        }
        
        # Sentiment indicators
        self.urgency_words = ['urgent', 'asap', 'immediately', 'emergency', 'critical']
        self.frustration_words = ['frustrated', 'angry', 'upset', 'disappointed', 'terrible']
    
    def correct_spelling(self, text):
        words = text.split()
        return ' '.join([self.corrections.get(w.lower(), w) for w in words])
    
    def normalize(self, text):
        text = text.lower()
        text = re.sub(r'<[^>]+>', '', text)  # Remove HTML
        text = re.sub(r'https?://\S+', '', text)  # Remove URLs
        text = self.correct_spelling(text)
        return ' '.join(text.split())
    
    def detect_sentiment_signals(self, text):
        """Detect urgency and frustration"""
        text_lower = text.lower()
        return {
            'is_urgent': any(w in text_lower for w in self.urgency_words),
            'is_frustrated': any(w in text_lower for w in self.frustration_words),
            'has_question': '?' in text,
            'is_all_caps': text.isupper() and len(text) > 10
        }
    
    def process(self, text):
        """Full processing pipeline"""
        normalized = self.normalize(text)
        signals = self.detect_sentiment_signals(text)
        
        return {
            'original': text,
            'normalized': normalized,
            'signals': signals
        }

# Test
processor = AgentNLPProcessor()
result = processor.process("HELP!! My ordr hasn't arrived and I need it ASAP!!!")
print(f"Original: {result['original']}")
print(f"Normalized: {result['normalized']}")
print(f"Signals: {result['signals']}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 PHASE 9: TEXT REPRESENTATION & RAG
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Build RAG (Retrieval Augmented Generation) system for knowledge-based responses.

---

```python
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss

# ============================================
# EMBEDDING-BASED KNOWLEDGE RETRIEVAL (RAG)
# ============================================

class KnowledgeBase:
    """Vector-based knowledge retrieval for RAG"""
    
    def __init__(self, model_name='all-MiniLM-L6-v2'):
        self.encoder = SentenceTransformer(model_name)
        self.documents = []
        self.embeddings = None
        self.index = None
    
    def add_documents(self, documents):
        """Add documents to knowledge base"""
        self.documents.extend(documents)
        
        # Create embeddings
        new_embeddings = self.encoder.encode(documents)
        
        if self.embeddings is None:
            self.embeddings = new_embeddings
        else:
            self.embeddings = np.vstack([self.embeddings, new_embeddings])
        
        # Build FAISS index
        self._build_index()
    
    def _build_index(self):
        """Build FAISS index for fast retrieval"""
        dimension = self.embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dimension)
        self.index.add(self.embeddings.astype('float32'))
    
    def search(self, query, top_k=3):
        """Search for relevant documents"""
        query_embedding = self.encoder.encode([query])
        distances, indices = self.index.search(query_embedding.astype('float32'), top_k)
        
        results = []
        for idx, dist in zip(indices[0], distances[0]):
            results.append({
                'document': self.documents[idx],
                'score': 1 / (1 + dist)  # Convert distance to similarity
            })
        
        return results

# ============================================
# RAG AGENT
# ============================================

class RAGAgent:
    """Agent with Retrieval Augmented Generation"""
    
    def __init__(self, knowledge_base):
        self.kb = knowledge_base
        self.llm = LLMResponseGenerator()  # From Phase 7
    
    def answer(self, query):
        """Answer query using RAG"""
        
        # Step 1: Retrieve relevant knowledge
        relevant_docs = self.kb.search(query, top_k=3)
        
        # Step 2: Build context from retrieved docs
        context = "\n".join([f"- {doc['document']}" for doc in relevant_docs])
        
        # Step 3: Generate response with context
        prompt = f"""Based on the following knowledge:
{context}

Answer this customer query: {query}

Provide a helpful, accurate response based only on the information provided."""
        
        response = self.llm.generate(prompt)
        
        return {
            'response': response,
            'sources': relevant_docs
        }

# Initialize knowledge base
kb = KnowledgeBase()

# Add FAQ documents
faqs = [
    "Refunds are processed within 3-5 business days after we receive the returned item.",
    "Standard shipping takes 5-7 business days. Express shipping takes 2-3 business days.",
    "You can track your order using the tracking number sent to your email.",
    "Our return policy allows returns within 30 days of purchase.",
    "To reset your password, click 'Forgot Password' on the login page.",
    "We accept Visa, Mastercard, American Express, and PayPal.",
    "Customer support is available 24/7 via chat, or by phone from 9 AM to 9 PM EST."
]

kb.add_documents(faqs)

# Test RAG
rag_agent = RAGAgent(kb)
result = rag_agent.answer("How long does shipping take?")
print(f"Response: {result['response']}")
print(f"Sources: {result['sources']}")
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 PHASE 10: COMPLETE AGENT ARCHITECTURE & DEPLOYMENT
# ═══════════════════════════════════════════════════════════════════════════════

## 🎯 PHASE OBJECTIVE
Build the complete agent with tools, memory, reasoning, and deployment.

---

```python
from typing import Dict, List, Any, Callable
from dataclasses import dataclass
from enum import Enum
import json

# ============================================
# TOOL DEFINITIONS FOR AGENT
# ============================================

class AgentTool:
    """Base class for agent tools"""
    
    def __init__(self, name: str, description: str, func: Callable):
        self.name = name
        self.description = description
        self.func = func
    
    def execute(self, **kwargs):
        return self.func(**kwargs)

class ToolRegistry:
    """Registry of available tools"""
    
    def __init__(self):
        self.tools = {}
    
    def register(self, tool: AgentTool):
        self.tools[tool.name] = tool
    
    def get(self, name: str):
        return self.tools.get(name)
    
    def list_tools(self):
        return [{"name": t.name, "description": t.description} for t in self.tools.values()]

# Define tools
def lookup_order(order_id: str) -> Dict:
    """Simulate order lookup"""
    # In production, this would query a database
    return {
        "order_id": order_id,
        "status": "shipped",
        "tracking": "1Z999AA10123456784",
        "delivery_date": "Dec 25, 2024"
    }

def process_refund(order_id: str, reason: str) -> Dict:
    """Simulate refund processing"""
    return {
        "success": True,
        "refund_id": f"REF-{order_id}",
        "amount": "$149.99",
        "eta": "3-5 business days"
    }

def search_knowledge(query: str) -> List[str]:
    """Search knowledge base"""
    # Uses RAG from Phase 9
    return kb.search(query, top_k=3)

# Register tools
registry = ToolRegistry()
registry.register(AgentTool("lookup_order", "Look up order status by order ID", lookup_order))
registry.register(AgentTool("process_refund", "Process a refund for an order", process_refund))
registry.register(AgentTool("search_knowledge", "Search FAQ and knowledge base", search_knowledge))

# ============================================
# AGENT MEMORY
# ============================================

class AgentMemory:
    """Short-term and long-term memory for agent"""
    
    def __init__(self, short_term_limit=10):
        self.short_term = []  # Current conversation
        self.long_term = {}   # User preferences, past issues
        self.limit = short_term_limit
    
    def add_message(self, role: str, content: str, metadata: Dict = None):
        self.short_term.append({
            "role": role,
            "content": content,
            "metadata": metadata or {}
        })
        if len(self.short_term) > self.limit:
            self.short_term = self.short_term[-self.limit:]
    
    def get_context(self, num_turns: int = 5) -> str:
        recent = self.short_term[-num_turns:]
        return "\n".join([f"{m['role']}: {m['content']}" for m in recent])
    
    def store_user_info(self, user_id: str, info: Dict):
        if user_id not in self.long_term:
            self.long_term[user_id] = {}
        self.long_term[user_id].update(info)
    
    def get_user_info(self, user_id: str) -> Dict:
        return self.long_term.get(user_id, {})

# ============================================
# COMPLETE AGENT
# ============================================

class CustomerSupportAgent:
    """
    Complete AI Customer Support Agent
    
    Components:
    - Intent Classification (BERT)
    - Entity Extraction (NER)
    - Knowledge Retrieval (RAG)
    - Response Generation (LLM)
    - Tool Execution
    - Conversation Memory
    """
    
    def __init__(self):
        # Core components
        self.nlp_processor = AgentNLPProcessor()
        self.intent_classifier = None  # Load BERT model
        self.entity_extractor = AgentEntityExtractor()
        self.knowledge_base = KnowledgeBase()
        self.response_generator = HybridResponseGenerator()
        self.llm = LLMResponseGenerator()
        
        # Tools and memory
        self.tools = registry
        self.memory = AgentMemory()
        
        # State
        self.current_user = None
        self.awaiting_info = None
    
    def process_message(self, user_message: str, user_id: str = None) -> Dict:
        """Main message processing pipeline"""
        
        # Step 1: Preprocess
        processed = self.nlp_processor.process(user_message)
        
        # Step 2: Classify intent
        intent, confidence = self._classify_intent(processed['normalized'])
        
        # Step 3: Extract entities
        entities = self.entity_extractor.extract(user_message)
        
        # Step 4: Determine action
        action = self._determine_action(intent, confidence, entities, processed['signals'])
        
        # Step 5: Execute action
        result = self._execute_action(action, entities, user_message)
        
        # Step 6: Generate response
        response = self._generate_response(intent, entities, result, processed['signals'])
        
        # Step 7: Update memory
        self.memory.add_message('user', user_message, {'intent': intent, 'entities': entities})
        self.memory.add_message('assistant', response)
        
        return {
            'response': response,
            'intent': intent,
            'confidence': confidence,
            'entities': entities,
            'action': action,
            'signals': processed['signals']
        }
    
    def _classify_intent(self, text):
        """Classify user intent"""
        # Use BERT classifier from Phase 7
        # Placeholder for now
        return 'track_order', 0.92
    
    def _determine_action(self, intent, confidence, entities, signals):
        """Determine what action to take"""
        
        if confidence < 0.5:
            return {'type': 'clarify', 'reason': 'low_confidence'}
        
        if signals['is_frustrated']:
            return {'type': 'escalate_tone', 'empathy': True}
        
        # Map intents to actions
        action_map = {
            'track_order': {'type': 'tool', 'tool': 'lookup_order', 'required': ['order_id']},
            'refund_request': {'type': 'tool', 'tool': 'process_refund', 'required': ['order_id']},
            'technical_support': {'type': 'rag', 'search': True},
            'greeting': {'type': 'respond', 'template': 'greeting'},
            'goodbye': {'type': 'respond', 'template': 'goodbye'}
        }
        
        action = action_map.get(intent, {'type': 'rag', 'search': True})
        
        # Check if required entities are present
        if action.get('required'):
            missing = [e for e in action['required'] if e.upper() not in entities]
            if missing:
                action['type'] = 'ask'
                action['missing'] = missing
        
        return action
    
    def _execute_action(self, action, entities, original_message):
        """Execute the determined action"""
        
        if action['type'] == 'tool':
            tool = self.tools.get(action['tool'])
            if tool:
                # Prepare arguments
                kwargs = {}
                if 'order_id' in action.get('required', []):
                    kwargs['order_id'] = entities.get('ORDER_ID', 'UNKNOWN')
                return tool.execute(**kwargs)
        
        elif action['type'] == 'rag':
            return self.knowledge_base.search(original_message)
        
        return None
    
    def _generate_response(self, intent, entities, action_result, signals):
        """Generate final response"""
        
        # Handle frustrated customers
        empathy = ""
        if signals['is_frustrated']:
            empathy = "I'm really sorry to hear about this frustrating experience. "
        
        if signals['is_urgent']:
            empathy += "I understand this is urgent. "
        
        # Generate based on action result
        if action_result:
            if isinstance(action_result, dict) and 'status' in action_result:
                response = f"I found your order. Status: {action_result['status']}. "
                response += f"Expected delivery: {action_result.get('delivery_date', 'soon')}."
            else:
                response = self.llm.generate(
                    f"Based on: {action_result}, respond to intent: {intent}"
                )
        else:
            response = self.response_generator.generate(intent, entities)
        
        return empathy + response

# ============================================
# FLASK API FOR DEPLOYMENT
# ============================================

from flask import Flask, request, jsonify

app = Flask(__name__)
agent = CustomerSupportAgent()

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    user_message = data.get('message', '')
    user_id = data.get('user_id', 'anonymous')
    
    result = agent.process_message(user_message, user_id)
    
    return jsonify(result)

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'agent': 'CustomerSupportAgent'})

# Run: flask run --port 5000
```

---

# ═══════════════════════════════════════════════════════════════════════════════
# 🎉 PROJECT COMPLETE - FINAL SUMMARY
# ═══════════════════════════════════════════════════════════════════════════════

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║   🤖 AI CUSTOMER SUPPORT AGENT - PROJECT SUMMARY                              ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║   PHASES COMPLETED:                                                           ║
║   ─────────────────                                                           ║
║   ✅ Phase 1:  Data Fundamentals (Intent data, Knowledge Base)                ║
║   ✅ Phase 2:  Machine Learning (TF-IDF, Multi-class classifiers)             ║
║   ✅ Phase 3:  Deep Learning (MLP intent classifier)                          ║
║   ✅ Phase 4:  CNN (TextCNN for intent)                                       ║
║   ✅ Phase 5:  RNN/LSTM (Context understanding)                               ║
║   ✅ Phase 6:  Seq2Seq (Response generation)                                  ║
║   ✅ Phase 7:  Transformers (BERT + LLM integration)                          ║
║   ✅ Phase 8:  NLP Preprocessing (Normalization, signals)                     ║
║   ✅ Phase 9:  RAG (Knowledge retrieval with embeddings)                      ║
║   ✅ Phase 10: Agent Architecture (Tools, Memory, Deployment)                 ║
║                                                                               ║
║   AGENT CAPABILITIES:                                                         ║
║   ───────────────────                                                         ║
║   🎯 Intent Classification (95%+ accuracy with BERT)                          ║
║   📋 Entity Extraction (ORDER_ID, PRODUCT, AMOUNT, etc.)                      ║
║   🔍 Knowledge Retrieval (RAG with vector search)                             ║
║   💬 Response Generation (Templates + LLM)                                    ║
║   🔧 Tool Execution (Order lookup, Refunds, etc.)                             ║
║   🧠 Conversation Memory (Short-term + Long-term)                             ║
║   😊 Sentiment Detection (Urgency, Frustration)                               ║
║                                                                               ║
║   ARCHITECTURE:                                                               ║
║   ─────────────                                                               ║
║                                                                               ║
║   User Message                                                                ║
║        │                                                                      ║
║        ▼                                                                      ║
║   ┌─────────────┐                                                             ║
║   │ Preprocessor │ → Normalize, Detect Signals                                ║
║   └──────┬──────┘                                                             ║
║          │                                                                    ║
║          ▼                                                                    ║
║   ┌─────────────┐     ┌─────────────┐                                         ║
║   │   Intent    │     │   Entity    │                                         ║
║   │ Classifier  │     │ Extractor   │                                         ║
║   │   (BERT)    │     │   (NER)     │                                         ║
║   └──────┬──────┘     └──────┬──────┘                                         ║
║          │                   │                                                ║
║          └─────────┬─────────┘                                                ║
║                    │                                                          ║
║                    ▼                                                          ║
║            ┌──────────────┐                                                   ║
║            │Action Planner│ → Decide: Tool/RAG/Template                       ║
║            └──────┬───────┘                                                   ║
║                   │                                                           ║
║      ┌────────────┼────────────┐                                              ║
║      ▼            ▼            ▼                                              ║
║   ┌──────┐   ┌────────┐   ┌──────┐                                            ║
║   │Tools │   │  RAG   │   │ LLM  │                                            ║
║   │      │   │        │   │      │                                            ║
║   └──┬───┘   └───┬────┘   └──┬───┘                                            ║
║      │           │           │                                                ║
║      └───────────┼───────────┘                                                ║
║                  │                                                            ║
║                  ▼                                                            ║
║         ┌───────────────┐                                                     ║
║         │   Response    │                                                     ║
║         │  Generator    │                                                     ║
║         └───────┬───────┘                                                     ║
║                 │                                                             ║
║                 ▼                                                             ║
║            Agent Response                                                     ║
║                                                                               ║
║   SKILLS LEARNED:                                                             ║
║   ───────────────                                                             ║
║   • ML/DL for NLP (Classification, NER)                                       ║
║   • Transformer models (BERT, GPT)                                            ║
║   • RAG architecture                                                          ║
║   • Prompt engineering                                                        ║
║   • Agent design patterns                                                     ║
║   • Tool/Function calling                                                     ║
║   • Memory management                                                         ║
║   • API deployment                                                            ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝

🎉 CONGRATULATIONS! You've built a complete AI Agent from scratch!

NEXT STEPS:
1. Deploy to cloud (AWS/GCP/Azure)
2. Add more tools (CRM integration, Payment processing)
3. Implement feedback loop for continuous learning
4. Add multi-language support
5. Build analytics dashboard
```
